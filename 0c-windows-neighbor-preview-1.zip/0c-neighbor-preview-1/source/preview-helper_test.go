package main

import (
	"encoding/json"
	"github.com/0c-biggo/0c-ime/internal/update"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func fixture(t *testing.T) (string, string, *update.Release, *update.Receipt) {
	t.Helper()
	base := t.TempDir()
	source := filepath.Join(base, "versions", "0.2.7-fixture")
	r := &update.Release{Schema: 1, Product: "0c", Version: "0.2.7", Channel: "public-beta", OS: "windows", Arch: "amd64", Files: map[string]string{}}
	for _, name := range []string{"0c-update.exe", "0c-server.exe", "0c-ui.exe", "0c_tsf.dll", "x86/0c_tsf.dll", "data/manifest.json", "data/lexicon.bin", "data/lm.bin", "data/NOTICE.txt", "data/report.txt"} {
		p := filepath.Join(source, filepath.FromSlash(name))
		if err := os.MkdirAll(filepath.Dir(p), 0700); err != nil {
			t.Fatal(err)
		}
		if err := os.WriteFile(p, []byte("fixture: "+name), 0600); err != nil {
			t.Fatal(err)
		}
		h, err := update.Hash(p)
		if err != nil {
			t.Fatal(err)
		}
		r.Files[name] = h
	}
	writeJSON(t, filepath.Join(source, "release.json"), r)
	receipt := &update.Receipt{Schema: 1, Product: "0c", Version: "0.2.7", Directory: "versions/0.2.7-fixture", Active: true, Files: r.Files}
	writeJSON(t, filepath.Join(base, "install-receipt.json"), receipt)
	if err := os.WriteFile(filepath.Join(base, "user.json"), []byte("personal data sentinel"), 0600); err != nil {
		t.Fatal(err)
	}
	return base, source, r, receipt
}

func writeJSON(t *testing.T, p string, v any) {
	t.Helper()
	b, err := json.Marshal(v)
	if err != nil {
		t.Fatal(err)
	}
	if err = os.WriteFile(p, b, 0600); err != nil {
		t.Fatal(err)
	}
}

func TestPrepareUsesVerifiedBaseAndPreservesOriginals(t *testing.T) {
	base, source, r, _ := fixture(t)
	dest := t.TempDir()
	receiptBefore, err := os.ReadFile(filepath.Join(base, "install-receipt.json"))
	if err != nil {
		t.Fatal(err)
	}
	if err := prepare(base, dest); err != nil {
		t.Fatal(err)
	}
	made, err := update.Verify(dest, "windows", "amd64")
	if err != nil {
		t.Fatal(err)
	}
	if made.Version != previewVersion || made.Channel != "internal-preview" || made.Files["0c-server.exe"] != engineSHA || made.Files["0c-update.exe"] != updaterSHA {
		t.Fatalf("wrong preview metadata: %+v", made)
	}
	for name, want := range r.Files {
		got, err := update.Hash(filepath.Join(source, filepath.FromSlash(name)))
		if err != nil || got != want {
			t.Fatalf("source changed: %s %v", name, err)
		}
		if name != "0c-server.exe" && name != "0c-update.exe" && made.Files[name] != want {
			t.Fatalf("borrowed component changed: %s", name)
		}
	}
	receiptAfter, _ := os.ReadFile(filepath.Join(base, "install-receipt.json"))
	if string(receiptAfter) != string(receiptBefore) {
		t.Fatal("receipt changed during preparation")
	}
	personal, _ := os.ReadFile(filepath.Join(base, "user.json"))
	if string(personal) != "personal data sentinel" {
		t.Fatal("personal data changed")
	}
	if _, err := os.Stat(filepath.Join(dest, "user.json")); !os.IsNotExist(err) {
		t.Fatal("personal data copied into preview")
	}
}

func TestPrepareRejectsTamperedSource(t *testing.T) {
	base, source, _, _ := fixture(t)
	os.WriteFile(filepath.Join(source, "data", "lm.bin"), []byte("tampered"), 0600)
	if err := prepare(base, t.TempDir()); err == nil || !strings.Contains(err.Error(), "hash mismatch") {
		t.Fatalf("tampered source accepted: %v", err)
	}
}

func TestPrepareUpgradesPreviousMixedPreviewWithoutChangingPreferences(t *testing.T) {
	base, source, r, receipt := fixture(t)
	r.Version, receipt.Version = "0.2.8-preview.mixedpolicy.1", "0.2.8-preview.mixedpolicy.1"
	note := filepath.Join(source, "PREVIEW.txt")
	os.WriteFile(note, []byte("previous mixed preview"), 0600)
	r.Files["PREVIEW.txt"], _ = update.Hash(note)
	writeJSON(t, filepath.Join(source, "release.json"), r)
	writeJSON(t, filepath.Join(base, "install-receipt.json"), receipt)
	settings := []byte(`{"mixed_input":true,"mixed_input_policy":"aggressive"}`)
	os.WriteFile(filepath.Join(base, "settings.json"), settings, 0600)
	dest := t.TempDir()
	if err := prepare(base, dest); err != nil {
		t.Fatal(err)
	}
	made, err := update.Verify(dest, "windows", "amd64")
	if err != nil || made.Version != previewVersion {
		t.Fatalf("upgrade: %+v %v", made, err)
	}
	got, _ := os.ReadFile(filepath.Join(base, "settings.json"))
	if string(got) != string(settings) {
		t.Fatal("existing mixed-input preferences changed")
	}
	if _, err := os.Stat(filepath.Join(dest, "settings.json")); !os.IsNotExist(err) {
		t.Fatal("personal settings copied into bundle")
	}
	if got, _ := os.ReadFile(note); string(got) != "previous mixed preview" {
		t.Fatal("old preview was modified")
	}
}

func TestPrepareRejectsReceiptMismatch(t *testing.T) {
	base, _, r, receipt := fixture(t)
	receipt.Files = map[string]string{}
	for n, h := range r.Files {
		receipt.Files[n] = h
	}
	receipt.Files["0c_tsf.dll"] = strings.Repeat("0", 64)
	writeJSON(t, filepath.Join(base, "install-receipt.json"), receipt)
	if err := prepare(base, t.TempDir()); err == nil {
		t.Fatal("mismatched receipt accepted")
	}
}

func TestPrepareRejectsUnsupportedVersionAndTraversal(t *testing.T) {
	for _, tc := range []struct{ version, dir string }{{"0.2.5", "versions/0.2.7-fixture"}, {"0.2.6", "versions/0.2.7-fixture"}, {"0.2.7", "../outside"}} {
		base, _, _, receipt := fixture(t)
		receipt.Version, receipt.Directory = tc.version, tc.dir
		writeJSON(t, filepath.Join(base, "install-receipt.json"), receipt)
		if err := prepare(base, t.TempDir()); err == nil {
			t.Fatalf("unsafe receipt accepted: %+v", tc)
		}
	}
}

func TestPrepareRejectsExtraFilesAndExistingDestination(t *testing.T) {
	base, source, _, _ := fixture(t)
	os.WriteFile(filepath.Join(source, "unexpected.dll"), []byte("extra"), 0600)
	if err := prepare(base, t.TempDir()); err == nil {
		t.Fatal("unlisted file accepted")
	}
	os.Remove(filepath.Join(source, "unexpected.dll"))
	dest := t.TempDir()
	os.WriteFile(filepath.Join(dest, "0c-server.exe"), []byte("existing"), 0600)
	if err := prepare(base, dest); err == nil {
		t.Fatal("existing destination overwritten")
	}
}
