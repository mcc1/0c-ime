// SPDX-License-Identifier: AGPL-3.0-only
package main

import (
	"bufio"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"

	"github.com/0c-biggo/0c-ime/internal/update"
)

const previewVersion = "0.2.8-preview.neighbor.1"
const sourceRevision = "45701f861d849071bffc94dc2604cd4f63c23731"

var engineSHA = "356e37c807edc7d90cd5630b4ffa44d9bae66e1ce1c505063773667b58d0bf8e"

//go:embed 0c-server.exe
var engine []byte

//go:embed 0c-update.exe
var updater []byte

var updaterSHA = "738f1498a0162f2a4bdf67fe48f6198c528a5c77792b5bb53ddda66e9dd4cad3"

func payloadOK() error {
	for _, p := range []struct {
		name string
		data []byte
		sha  string
	}{{"engine", engine, engineSHA}, {"updater", updater, updaterSHA}} {
		sum := sha256.Sum256(p.data)
		if hex.EncodeToString(sum[:]) != p.sha {
			return fmt.Errorf("embedded %s SHA-256 mismatch", p.name)
		}
		if len(p.data) < 64 || string(p.data[:2]) != "MZ" {
			return fmt.Errorf("embedded %s is not a Windows executable", p.name)
		}
	}
	return nil
}

func installed(base string) (*update.Receipt, string, error) {
	b, err := os.ReadFile(filepath.Join(base, "install-receipt.json"))
	if err != nil {
		return nil, "", err
	}
	var r update.Receipt
	if err = json.Unmarshal(b, &r); err != nil {
		return nil, "", err
	}
	if r.Schema != 1 || r.Product != "0c" || !r.Active || !update.SafeName(r.Directory) || !strings.HasPrefix(r.Directory, "versions/") {
		return nil, "", fmt.Errorf("invalid or inactive installation receipt")
	}
	return &r, filepath.Join(base, filepath.FromSlash(r.Directory)), nil
}

func copyFile(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0700); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	_, err = io.Copy(out, in)
	closeErr := out.Close()
	if err != nil {
		return err
	}
	return closeErr
}

func supportedBase(version string) bool {
	return version == "0.2.7" || version == "0.2.8-preview.mixedpolicy.1"
}

func prepare(base, dest string) error {
	if err := payloadOK(); err != nil {
		return err
	}
	receipt, source, err := installed(base)
	if err != nil {
		return err
	}
	if !supportedBase(receipt.Version) {
		return fmt.Errorf("this preview requires official 0.2.7 or mixedpolicy.1; found %s", receipt.Version)
	}
	release, err := update.Verify(source, "windows", "amd64")
	if err != nil {
		return fmt.Errorf("verify installed bundle: %w", err)
	}
	if release.Version != receipt.Version {
		return fmt.Errorf("receipt and installed bundle versions differ")
	}
	// Anchor source files to the installation receipt as well as release.json.
	if len(receipt.Files) != len(release.Files) {
		return fmt.Errorf("receipt file list differs from installed bundle")
	}
	for name, expected := range release.Files {
		if receipt.Files[name] != expected {
			return fmt.Errorf("receipt hash differs: %s", name)
		}
		target := filepath.Join(dest, filepath.FromSlash(name))
		if err = copyFile(filepath.Join(source, filepath.FromSlash(name)), target); err != nil {
			return err
		}
		actual, e := update.Hash(target)
		if e != nil {
			return e
		}
		if actual != expected {
			return fmt.Errorf("copied file hash differs: %s", name)
		}
	}
	if err = os.WriteFile(filepath.Join(dest, "0c-server.exe"), engine, 0600); err != nil {
		return err
	}
	if err = os.WriteFile(filepath.Join(dest, "0c-update.exe"), updater, 0600); err != nil {
		return err
	}
	note := "mcc1 private test build, not an official upstream release.\nVersion: " + previewVersion + "\nEngine/updater source: https://github.com/mcc1/0c-ime/commit/" + sourceRevision + "\nShell, UI, settings, dictionary and model runtime reused unchanged from this user's verified installation, version " + receipt.Version + ".\n"
	if err = os.WriteFile(filepath.Join(dest, "PREVIEW.txt"), []byte(note), 0600); err != nil {
		return err
	}
	raw, err := os.ReadFile(filepath.Join(source, "release.json"))
	if err != nil {
		return err
	}
	var metadata map[string]any
	if err = json.Unmarshal(raw, &metadata); err != nil {
		return err
	}
	metadata["version"], metadata["channel"], metadata["revision"] = previewVersion, "internal-preview", sourceRevision
	metadata["dirty"], metadata["build_platform"] = false, "Linux cross-compiled engine and updater; verified installed Windows 0.2.7 shell and runtime"
	files := map[string]string{}
	for name := range release.Files {
		h, e := update.Hash(filepath.Join(dest, filepath.FromSlash(name)))
		if e != nil {
			return e
		}
		files[name] = h
	}
	h, err := update.Hash(filepath.Join(dest, "PREVIEW.txt"))
	if err != nil {
		return err
	}
	files["PREVIEW.txt"] = h
	metadata["files"] = files
	data, err := json.MarshalIndent(metadata, "", "  ")
	if err != nil {
		return err
	}
	if err = os.WriteFile(filepath.Join(dest, "release.json"), append(data, '\n'), 0600); err != nil {
		return err
	}
	if _, err = update.Verify(dest, "windows", "amd64"); err != nil {
		return fmt.Errorf("verify prepared preview: %w", err)
	}
	return nil
}

func command(file string, args ...string) error {
	cmd := exec.Command(file, args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func run() error {
	if err := payloadOK(); err != nil {
		return err
	}
	if len(os.Args) == 2 && os.Args[1] == "--verify-payload" {
		fmt.Println(previewVersion, "engine SHA-256:", engineSHA)
		return nil
	}
	if runtime.GOOS != "windows" || runtime.GOARCH != "amd64" {
		return fmt.Errorf("requires Windows x64")
	}
	rollback := len(os.Args) == 2 && os.Args[1] == "--rollback"
	policy := ""
	if len(os.Args) == 3 && os.Args[1] == "--policy" && (os.Args[2] == "conservative" || os.Args[2] == "aggressive") {
		policy = os.Args[2]
	}
	updateMode := ""
	if len(os.Args) == 3 && os.Args[1] == "--updates" && (os.Args[2] == "manual" || os.Args[2] == "auto") {
		updateMode = os.Args[2]
	}
	neighborMode := ""
	if len(os.Args) == 3 && os.Args[1] == "--neighbor" && (os.Args[2] == "on" || os.Args[2] == "off") {
		neighborMode = os.Args[2]
	}
	if len(os.Args) > 1 && !rollback && policy == "" && updateMode == "" && neighborMode == "" {
		return fmt.Errorf("supported arguments: --rollback, --policy conservative|aggressive, --updates manual|auto, --neighbor on|off")
	}
	local := os.Getenv("LOCALAPPDATA")
	if !filepath.IsAbs(local) {
		return fmt.Errorf("missing LOCALAPPDATA")
	}
	base := filepath.Join(local, "Zuin")
	receipt, source, err := installed(base)
	if err != nil {
		return err
	}
	if rollback {
		if receipt.Version != previewVersion {
			return fmt.Errorf("this preview is not the active installed version")
		}
		fmt.Println("Restoring the previous installation; current personal vocabulary is retained.")
		return command(filepath.Join(source, "0c-update.exe"), "rollback")
	}
	if policy != "" {
		if receipt.Version != previewVersion {
			return fmt.Errorf("install this preview before selecting its mixed-input policy")
		}
		return command(filepath.Join(source, "0c-update.exe"), "set", "mixed-input-policy", policy, "-apply", "-notify")
	}
	if neighborMode != "" {
		if receipt.Version != previewVersion {
			return fmt.Errorf("install this preview before toggling neighbor recovery")
		}
		args := []string{"set"}
		if neighborMode == "on" {
			args = append(args, "mixed-input-policy", "aggressive")
		}
		args = append(args, "neighbor-key-recovery", neighborMode, "-apply", "-notify")
		return command(filepath.Join(source, "0c-update.exe"), args...)
	}
	if updateMode != "" {
		// Allow restoring automatic updates after rolling back to the official base.
		if receipt.Version != previewVersion && !supportedBase(receipt.Version) {
			return fmt.Errorf("update-mode helper requires this preview or a supported base")
		}
		if err = command(filepath.Join(source, "0c-update.exe"), "mode", updateMode); err != nil {
			return err
		}
		fmt.Println("Update mode:", updateMode)
		return nil
	}
	fmt.Println("Preparing", previewVersion)
	fmt.Println("Requires an existing Windows x64 official 0.2.7 or mixedpolicy.1 installation. Run as administrator using the same Windows account.")
	dest, err := os.MkdirTemp("", "0c-chinese-preview-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dest)
	if err = prepare(base, dest); err != nil {
		return err
	}
	fmt.Println("Preview and copied components verified. The bundled 0c updater retains the previous installation for rollback.")
	if err = command(filepath.Join(dest, "0c-update.exe"), "install", "-bundle", dest, "-channel", "internal-preview"); err != nil {
		return err
	}
	fmt.Println("Installed. Save your work, SIGN OUT of Windows, then sign in again before testing.")
	fmt.Println("To roll back, run this same program as administrator with --rollback.")
	return nil
}

func main() {
	err := run()
	if err != nil {
		fmt.Fprintln(os.Stderr, "Preview setup:", err)
	}
	if runtime.GOOS == "windows" && !(len(os.Args) == 2 && os.Args[1] == "--verify-payload") {
		fmt.Println("Press Enter to close.")
		_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
	}
	if err != nil {
		os.Exit(1)
	}
}
