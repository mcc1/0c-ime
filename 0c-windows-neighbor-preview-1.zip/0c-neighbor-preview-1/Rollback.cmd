@echo off
"%~dp00c-neighbor-test-setup.exe" --rollback
