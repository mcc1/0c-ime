@echo off
"%~dp00c-neighbor-test-setup.exe" --policy aggressive
