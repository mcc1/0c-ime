@echo off
"%~dp00c-windows-mixed-preview-setup.exe" --updates auto
