// SPDX-License-Identifier: AGPL-3.0-only
package main

import (
	"bufio"
	"crypto/sha256"
	_ "embed"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"io"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"

	"github.com/0c-biggo/0c-ime/internal/update"
)

const previewVersion = "0.2.12-preview.uac.1"
const sourceRevision = "edc07bc3838277d80ecff6403f5b0a61a6a0e929"

var engineSHA = "ffbbba858047cbe2a341712be8657be7758779b7d9893a8f9983f027d8a8adf7"

//go:embed 0c-server.exe
var engine []byte

//go:embed 0c-update.exe
var updater []byte

var updaterSHA = "d6fe040f753322aa07bd5adbc3eaab7f554a3b6d37c20aa11b9f1a707b70b184"

//go:embed 0c-settings.exe
var settingsProgram []byte

//go:embed WebView2Loader.dll
var webviewLoader []byte

//go:embed SETTINGS-NOTICES.txt
var settingsNotices []byte

var settingsSHA = "18603a8ef458332adf749d34420cb940d8af8ba2eaebd9c111b462144de1099b"
var loaderSHA = "86545b66cdb0603bc26b626fb9ad610cb6e71f28d468f5ea66df23b03dda96d5"
var noticesSHA = "bde7f79b06e40d5ff02be8a755e0fe29504e0f25c2061859b68166ca6f0ee174"

//go:embed 0c_tsf.dll
var tsf64 []byte
//go:embed 0c_tsf-x86.dll
var tsf32 []byte
//go:embed NATIVE-NOTICES.txt
var nativeNotices []byte
var tsf64SHA = "db59695c09d2f65443770402e6e9998db750cfbf49c277c7c9cf1e47a4b2adbe"
var tsf32SHA = "7999adc17a6b812102c67ab9e82357d48c02c2f69def05b5263dbb3a7256b991"
var nativeNoticesSHA = "cbb92f8d9c212b7e84b12740a1c71bc1aea09e7cbdda27dba6b425bf7cfcec7d"

type embeddedPayload struct {
	name string
	data []byte
	sha  string
}

func payloads() []embeddedPayload {
	return []embeddedPayload{
		{"0c-server.exe", engine, engineSHA}, {"0c-update.exe", updater, updaterSHA},
		{"0c-settings.exe", settingsProgram, settingsSHA}, {"WebView2Loader.dll", webviewLoader, loaderSHA},
		{"SETTINGS-NOTICES.txt", settingsNotices, noticesSHA},
        {"0c_tsf.dll", tsf64, tsf64SHA}, {"x86/0c_tsf.dll", tsf32, tsf32SHA},
        {"NATIVE-NOTICES.txt", nativeNotices, nativeNoticesSHA},
	}
}
func payloadOK() error {
	for _, p := range payloads() {
		sum := sha256.Sum256(p.data)
		if hex.EncodeToString(sum[:]) != p.sha {
			return fmt.Errorf("embedded %s SHA-256 mismatch", p.name)
		}
		if (strings.HasSuffix(p.name, ".exe") || strings.HasSuffix(p.name, ".dll")) && (len(p.data) < 64 || string(p.data[:2]) != "MZ") {
			return fmt.Errorf("embedded %s is not a Windows executable", p.name)
		}
	}
	return nil
}

func installed(base string) (*update.Receipt, string, error) {
	b, err := os.ReadFile(filepath.Join(base, "install-receipt.json"))
	if err != nil {
		return nil, "", err
	}
	var r update.Receipt
	if err = json.Unmarshal(b, &r); err != nil {
		return nil, "", err
	}
	if r.Schema != 1 || r.Product != "0c" || !r.Active || !update.SafeName(r.Directory) || !strings.HasPrefix(r.Directory, "versions/") {
		return nil, "", fmt.Errorf("invalid or inactive installation receipt")
	}
	return &r, filepath.Join(base, filepath.FromSlash(r.Directory)), nil
}

func copyFile(src, dst string) error {
	if err := os.MkdirAll(filepath.Dir(dst), 0700); err != nil {
		return err
	}
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.OpenFile(dst, os.O_WRONLY|os.O_CREATE|os.O_EXCL, 0600)
	if err != nil {
		return err
	}
	_, err = io.Copy(out, in)
	closeErr := out.Close()
	if err != nil {
		return err
	}
	return closeErr
}

func supportedBase(version string) bool {
	return version == "0.2.11"
}

func prepare(base, dest string) error {
	if err := payloadOK(); err != nil {
		return err
	}
	receipt, source, err := installed(base)
	if err != nil {
		return err
	}
	if !supportedBase(receipt.Version) {
		return fmt.Errorf("this preview requires official Windows x64 0.2.11; found %s. Update to official 0.2.11 first", receipt.Version)
	}
	release, err := update.Verify(source, "windows", "amd64")
	if err != nil {
		return fmt.Errorf("verify installed bundle: %w", err)
	}
	if release.Version != receipt.Version {
		return fmt.Errorf("receipt and installed bundle versions differ")
	}
	// Anchor source files to the installation receipt as well as release.json.
	if len(receipt.Files) != len(release.Files) {
		return fmt.Errorf("receipt file list differs from installed bundle")
	}
	for name, expected := range release.Files {
		if receipt.Files[name] != expected {
			return fmt.Errorf("receipt hash differs: %s", name)
		}
		target := filepath.Join(dest, filepath.FromSlash(name))
		if err = copyFile(filepath.Join(source, filepath.FromSlash(name)), target); err != nil {
			return err
		}
		actual, e := update.Hash(target)
		if e != nil {
			return e
		}
		if actual != expected {
			return fmt.Errorf("copied file hash differs: %s", name)
		}
	}
	for _, p := range payloads() {
		if err = os.WriteFile(filepath.Join(dest, p.name), p.data, 0600); err != nil {
			return err
		}
	}

	note := "mcc1 private test build, not an official upstream release.\nVersion: " + previewVersion + "\nEngine/updater source: https://github.com/mcc1/0c-ime/commit/" + sourceRevision + "\nTSF x64/x86 rebuilt with secure-mode pass-through. Candidate UI, dictionary and model runtime reused unchanged from this user's verified installation, version " + receipt.Version + ".\n"
	if err = os.WriteFile(filepath.Join(dest, "PREVIEW.txt"), []byte(note), 0600); err != nil {
		return err
	}
	raw, err := os.ReadFile(filepath.Join(source, "release.json"))
	if err != nil {
		return err
	}
	var metadata map[string]any
	if err = json.Unmarshal(raw, &metadata); err != nil {
		return err
	}
	metadata["version"], metadata["channel"], metadata["revision"] = previewVersion, "internal-preview", sourceRevision
	metadata["dirty"], metadata["build_platform"] = false, "Linux cross-compiled Go engine/updater and Rust GNU settings/TSF x64+x86; verified installed Windows 0.2.11 candidate UI/data/runtime"
	files := map[string]string{}
	for name := range release.Files {
		h, e := update.Hash(filepath.Join(dest, filepath.FromSlash(name)))
		if e != nil {
			return e
		}
		files[name] = h
	}
	for _, p := range payloads() {
		h, e := update.Hash(filepath.Join(dest, p.name))
		if e != nil {
			return e
		}
		files[p.name] = h
	}
	h, err := update.Hash(filepath.Join(dest, "PREVIEW.txt"))
	if err != nil {
		return err
	}
	files["PREVIEW.txt"] = h
	metadata["files"] = files
	data, err := json.MarshalIndent(metadata, "", "  ")
	if err != nil {
		return err
	}
	if err = os.WriteFile(filepath.Join(dest, "release.json"), append(data, '\n'), 0600); err != nil {
		return err
	}
	if _, err = update.Verify(dest, "windows", "amd64"); err != nil {
		return fmt.Errorf("verify prepared preview: %w", err)
	}
	return nil
}

func command(file string, args ...string) error {
	cmd := exec.Command(file, args...)
	cmd.Stdin = os.Stdin
	cmd.Stdout = os.Stdout
	cmd.Stderr = os.Stderr
	return cmd.Run()
}

func run() error {
	if err := payloadOK(); err != nil {
		return err
	}
	if len(os.Args) == 2 && os.Args[1] == "--verify-payload" {
		fmt.Println(previewVersion, "engine SHA-256:", engineSHA)
		fmt.Println("Settings SHA-256:", settingsSHA, "loader SHA-256:", loaderSHA)
        fmt.Println("TSF x64 SHA-256:", tsf64SHA, "TSF x86 SHA-256:", tsf32SHA)
		return nil
	}
	if runtime.GOOS != "windows" || runtime.GOARCH != "amd64" {
		return fmt.Errorf("requires Windows x64")
	}
	rollback := len(os.Args) == 2 && os.Args[1] == "--rollback"
	policy := ""
	if len(os.Args) == 3 && os.Args[1] == "--policy" && (os.Args[2] == "conservative" || os.Args[2] == "aggressive") {
		policy = os.Args[2]
	}
	updateMode := ""
	if len(os.Args) == 3 && os.Args[1] == "--updates" && (os.Args[2] == "manual" || os.Args[2] == "auto") {
		updateMode = os.Args[2]
	}
	neighborMode := ""
	if len(os.Args) == 3 && os.Args[1] == "--neighbor" && (os.Args[2] == "on" || os.Args[2] == "off") {
		neighborMode = os.Args[2]
	}
	if len(os.Args) > 1 && !rollback && policy == "" && updateMode == "" && neighborMode == "" {
		return fmt.Errorf("supported arguments: --rollback, --policy conservative|aggressive, --updates manual|auto, --neighbor on|off")
	}
	local := os.Getenv("LOCALAPPDATA")
	if !filepath.IsAbs(local) {
		return fmt.Errorf("missing LOCALAPPDATA")
	}
	base := filepath.Join(local, "Zuin")
	receipt, source, err := installed(base)
	if err != nil {
		return err
	}
	if rollback {
		if receipt.Version != previewVersion {
			return fmt.Errorf("this preview is not the active installed version")
		}
		fmt.Println("Restoring the previous installation; current personal vocabulary is retained.")
		return command(filepath.Join(source, "0c-update.exe"), "rollback")
	}
	if policy != "" {
		if receipt.Version != previewVersion {
			return fmt.Errorf("install this preview before selecting its mixed-input policy")
		}
		return command(filepath.Join(source, "0c-update.exe"), "set", "mixed-input-policy", policy, "-apply", "-notify")
	}
	if neighborMode != "" {
		if receipt.Version != previewVersion {
			return fmt.Errorf("install this preview before toggling neighbor recovery")
		}
		args := []string{"set"}
		if neighborMode == "on" {
			args = append(args, "mixed-input-policy", "aggressive")
		}
		args = append(args, "neighbor-key-recovery", neighborMode, "-apply", "-notify")
		return command(filepath.Join(source, "0c-update.exe"), args...)
	}
	if updateMode != "" {
		// Allow restoring automatic updates after rolling back to the official base.
		if receipt.Version != previewVersion && !supportedBase(receipt.Version) {
			return fmt.Errorf("update-mode helper requires this preview or a supported base")
		}
		if err = command(filepath.Join(source, "0c-update.exe"), "mode", updateMode); err != nil {
			return err
		}
		fmt.Println("Update mode:", updateMode)
		return nil
	}
	fmt.Println("Preparing", previewVersion)
	fmt.Println("Requires official Windows x64 0.2.11. Close Settings, finish composition, and run as administrator using the same Windows account.")
	dest, err := os.MkdirTemp("", "0c-chinese-preview-")
	if err != nil {
		return err
	}
	defer os.RemoveAll(dest)
	if err = prepare(base, dest); err != nil {
		return err
	}
	fmt.Println("Preview and copied components verified. The bundled 0c updater retains the previous installation for rollback.")
	if err = command(filepath.Join(dest, "0c-update.exe"), "install", "-bundle", dest, "-channel", "internal-preview"); err != nil {
		return err
	}
	fmt.Println("Installed. Save your work and SIGN OUT, then sign in before testing UAC. TSF DLLs already loaded in applications require a new desktop session; no forced sign-out.")
	fmt.Println("To roll back, run this same program as administrator with --rollback.")
	return nil
}

func main() {
	err := run()
	if err != nil {
		fmt.Fprintln(os.Stderr, "Preview setup:", err)
	}
	if runtime.GOOS == "windows" && !(len(os.Args) == 2 && os.Args[1] == "--verify-payload") {
		fmt.Println("Press Enter to close.")
		_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
	}
	if err != nil {
		os.Exit(1)
	}
}
