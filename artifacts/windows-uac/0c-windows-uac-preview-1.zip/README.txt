﻿靈犀注音 Windows x64 UAC／混打升級測試包
版本：0.2.12-preview.uac.1
來源：https://github.com/mcc1/0c-ime/commit/edc07bc3838277d80ecff6403f5b0a61a6a0e929

需要已安裝正式版 Windows x64 0.2.11。不是全新安裝包，不支援 ARM64。
若目前是舊正式版或先前的測試版，請先安裝正式版 0.2.11。
本包未簽章，是供本次 UAC 問題驗證的候選版；尚未在原生 Windows 驗收。

包含：上游最新版 0.2.11、積極／保守組字、鄰鍵容錯及 UAC 安全模式候選修正。
安全模式僅保留 TSF 啟用並放行按鍵，不讀取輸入內容、不開候選視窗、不連組字引擎。
沒有修改 mode-memory，也沒有背景程式強制切回 0c。Shift 回中文研究排名器未合入。
原生 TSF x64／x86 均重新編譯，含品牌圖示與本版版本資訊。使用 Rust Windows GNU 工具鏈；
執行時不另需 GCC／MinGW DLL。候選窗程式、字典及模型執行環境取自你已驗證的正式版安裝。

安裝：
1. 完整解壓 ZIP，儲存工作、完成組字並關閉設定視窗。
2. 使用原安裝輸入法的同一 Windows 帳號，以系統管理員身分執行
   0c-windows-mixed-preview-setup.exe。
3. 安裝完成後「登出 Windows 再登入」。這次更換 TSF DLL，僅關閉設定視窗不足以
   卸載其他程式裡的舊 DLL；未重新登入可能仍在測試舊版。
   工具不強制登出，避免遺失尚未儲存的工作。

安裝先驗證收據、完整檔案清單及 SHA256，再預備新版本，透過原作者更新工具安裝／註冊。
更新引擎、更新工具、設定介面、WebView2 loader 及兩份 TSF DLL；保留個人詞庫、設定和更新偏好。
本測試包不包含你的私人詞庫或設定。原版本保留以便回復。

UAC 測試：
1. 重新登入後，在記事本選 0c，先確認能正常輸入中文。
2. 開一個需要 UAC 的程式，按「否」取消，再回同一個記事本；觀察是否仍需 Win+Space。
3. 再測按「是」允許後回到記事本。另測提權程式內的輸入，勿與返回原視窗混為一談。
4. 確認手動選 ENG 仍能維持 ENG，原本每程式／共用中英模式仍正常。
本版的核心目標是避免 UAC 後遺失 0c 選取；這仍須實機確認。

混打：確認中英混打已開；內建習慣如不能改，先複製成自訂習慣。
Aggressive.cmd 選積極；Conservative.cmd 選保守。
Neighbor-On.cmd 開鄰鍵容錯並選積極；Neighbor-Off.cmd 只關鄰鍵。
鄰鍵第一版限標準注音／QWERTY／積極模式、單一誤按及明確聲調；不修純數字或合法讀音。
測試 593、microsoft593fmp6、ru,3WQ5j04fu06、ki3、helloki3cl3。
0.2.11 的已知型號（如 gpt4）保留原文；積極模式仍可能轉換其他帳號／型號，需原文時切英文。
安裝不自動開啟新功能。Manual-Updates.cmd 可改手動更新，Auto-Updates.cmd 恢復自動。

回復：完成組字、儲存工作並關閉設定，以同帳號管理員執行 Rollback.cmd，之後登出再登入。
回復保留目前個人詞庫；若已另安裝其他版本會拒絕。

驗證：Go 核心／設定、公開字典、UI、原生安全模式 COM 測試、x64/x86 編譯、PE 匯入／匯出／資源、
升級預備／防竄改／詞庫設定保留／雙 TSF 替換、ZIP 完整性。
Wine 的單元測試不能取代真實 Windows UAC、安全桌面、安裝／註冊與回復驗收。

授權：自有程式 AGPL-3.0-only；對應源碼與 helper 測試附於 source/。
第三方條款見 THIRD_PARTY_NOTICES.txt、SETTINGS-NOTICES.txt、NATIVE-NOTICES.txt。
