@echo off
"%~dp00c-mixed-policy-test-setup.exe" --updates manual
