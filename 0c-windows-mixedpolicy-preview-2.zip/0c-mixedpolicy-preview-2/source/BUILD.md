# Source and rebuild instructions

Application source: https://github.com/mcc1/0c-ime/commit/cc753158f2c4b8fcce95b891ea434d8addb7e7a8
The source archive is a snapshot of that exact commit. The setup helper source and tests are included beside it.

Use Go 1.26.10. In the source root, copy preview-helper.go and preview-helper_test.go to build/windows-preview-027/main.go and main_test.go.

Build ./cmd/0c-server and ./cmd/0c-update with GOOS=windows GOARCH=amd64 CGO_ENABLED=0, -trimpath and -ldflags "-s -w -X main.buildVersion=0.2.8-preview.mixedpolicy.1". Output them as build/windows-preview-027/0c-server.exe and 0c-update.exe.

Verify both SHA-256 values against engineSHA/updaterSHA in the helper. Git metadata and toolchain differences can change rebuilt binary hashes; update those constants only for your own intentionally rebuilt payloads from trusted source, never to accept an unverified download. Run go test ./build/windows-preview-027 for the preparation tests. Build ./build/windows-preview-027 with GOOS=windows GOARCH=amd64 CGO_ENABLED=0, -trimpath -buildvcs=false and -ldflags "-s -w" to produce the setup executable.

The helper uses internal/update verification and the normal 0c-update installation/rollback operations. Original 0.2.7 components are copied and checked on the user's machine, not redistributed in this ZIP. No Rust or Windows SDK is needed for this preview. The existing settings UI renders the additional setting from the new updater's contract; this preview retains the installed UI executable.
