@echo off
"%~dp00c-mixed-policy-test-setup.exe" --policy conservative
