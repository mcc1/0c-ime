# Stage 7 — Design critic

Reviewer `/root/shift_round2_design`, fresh context. Complete returned report follows.

No Blocker or Major findings against the Feature Specification Standard. The mandatory alternatives evaluation is present, and the proposed experiment adequately distinguishes information masks, ownership freezing, final reading success, literal harm, and later product feasibility. The design also limits what synthetic benchmarks and the eventual GO outcome can establish.

Nit — Capacity estimate does not describe the full experiment workload.

Affected scope: `/workspace/scratch/shift-return-egm-review-9fb74f9-r2/review_target.md:39`, with supporting definitions at lines 71, 167, 278–287, and 350–354; authoritative `/workspace/0c-ime/design/shift-return-protocol-v2.md:230`.

The estimate of roughly one million complete decodes corresponds to approximately `6000 × 8 × 20`. The actual contract also includes per-key replay, eight final model/flow conditions, train/dev enumeration and margin selection, and up to four additional variants per prototype. Its required long input strata can have substantially greater candidate and decoding work than the average eight-syllable example. The document does not explain which work is shared or cached, so the estimate cannot currently serve as a full-run capacity estimate.

For example, decoding the same candidates independently for each test condition increases that portion of decoding work eightfold; reusing frozen candidate/render evidence could avoid much of that duplication, but this reuse is not specified. The existing hard caps and INCONCLUSIVE behavior prevent this from silently weakening quality gates, so this is a planning clarification rather than a validity blocker.

Recommendation: Label the current figure as a single-pass estimate and add a workload accounting that includes phases, replay conditions, variants, and intended cache reuse. Include representative long literal and long return cases in the pre-quality capacity calibration.

Actual read inventory:

- Complete design-critic persona and Feature Specification Standard.
- Complete review target, lines 1–414, including the active Feature Specification and supporting Detailed Implementation Plan.
- Packet `manifest.json`, including its 16-source mappings.
- Complete linked `schema.json`; truncated output was recovered through additional reads.
- Complete linked artifacts: `examples.jsonl`, `numerical.json`, `worked-report.json`, `cohort-example.json`, `bank-example.json`, `canonical-model-sample.json`, `seen-example.json`, `occurrences.jsonl`, `lifecycle.json`, and `check_examples.py`.
- Authoritative protocol lines 180–234 were additionally read with source line numbers.

Limits: This was a read-only design audit. I did not run validators, tests, compilation, fitting, or quality experiments, and did not inspect production API implementations. API parity and experimental results therefore remain future evidence as the document itself states. No previous review/resolution reports, scratch experiments, history, memory, or prohibited evaluator/reporting internals were read.
