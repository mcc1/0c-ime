# Stage 9 focused re-audit — Codebase details

Reviewer `/root/shift_round2_reaudit_codebase`, fresh context. Complete returned report follows.

Focused re-audit verdict: all four finding groups are resolved. No remaining Blocker, Major or Nit was found within the authorized scope at snapshot `c512578157607615ed114feba20c8a443f260a19`. This is a contract review, not a claim of evaluator implementation or runtime parity.

1. Resolved — Runtime Snapshot versus training records and handoff.

   `design/shift-return-protocol-v2.md:30` now specifies `Step(State,Event,Policy) (State,Snapshot,error)`. Lines 39 and 62–64 distinguish Snapshot from TrainingObservation, prohibit Step from reading fixture/gold, assign runtime serialization to the runner, and assign gold-labelled record construction to a separate label builder. No-query events explicitly produce Snapshots with null query/selection IDs.

   The schema now has separate closed objects: Snapshot at `schema.json:582–748` and TrainingObservation at `schema.json:2346–2399`. Snapshot requires `handoff`, whose exact shape is defined at `schema.json:2401–2437`. Protocol lines 110–112 specify close/cancel state changes, event preservation, action, target mode and prelude handling. The two records in `runtime-snapshots.jsonl:1–2` demonstrate a no-query opening Snapshot and an Enter closing Snapshot with `commit_only` handoff. `check_examples.py:207–217` checks their shapes and rejects gold fields on runtime output.

   The earlier incompatible Step/Observation requirement and unserializable handoff are removed.

2. Resolved — Complete Row primary metadata.

   Protocol lines 210–212 require an exact `primary_metadata` object containing `id/category/stratum/context_class/contrast_eligible`. They define how variants copy their selected primary’s metadata, how compatibility rows represent no primary, and which duplicated fields validators must cross-check.

   `schema.json:1310–1349` provides that closed metadata object, including required `stratum`; `schema.json:1386–1387` requires both `primary_metadata` and `generators_path` on Row.

   `metadata-fixtures.jsonl:1–2` contains a primary in stratum `1` and a variant in `17-64`. Both corresponding records in `metadata-rows.jsonl:1–2` copy the primary’s stratum `1`, while retaining distinct row fixture IDs. `check_examples.py:219–230` checks the intended distinction.

   The required audit copy is now representable without adding forbidden schema properties.

3. Resolved — Persisted generation, cap and resource evidence.

   Protocol lines 64 and 72–74 now require `generators.jsonl.gz`, with a query-keyed GeneratorDiagnostic for each actual or raw-limit-rejected query attempt. The contract specifies provenance, generation status, uncapped/kept IDs and counts, literal identity, cap pruning, raw overflow, resource status and cumulative counters. It distinguishes completed empty search results from unavailable enumeration using nulls.

   The runner, enumerate/replay persistence, reducer inputs and validation responsibilities are explicit at protocol lines 74, 240 and 259. The reducer must distinguish cap loss, generator miss and unavailable enumeration; Row’s final `gold_survived` no longer substitutes for those diagnostics.

   `schema.json:2438–2661` defines the persisted diagnostic shape and requires its fields. `generator-examples.json:5–673`, `:677–1344` and `:1348–1374` provide constructed cap-loss, generator-miss and resource-exhaustion cases. `check_examples.py:232–249` checks count/list consistency, the retained cap, gold separation, and the distinct grading outcomes.

   The former missing evidence channel is now specified and serializable. These constructed cases explicitly disclaim execution.

4. Resolved — Lookup-counting boundary and preservation of source interfaces.

   Protocol line 259 defines `probe_lex_queries` as evaluator-direct Exact/HasPrefix requests, counting logical requests even on evaluator memo hits. It excludes Decoder-internal and neutral-source secondary lookups, defines external Best request counting, excludes other named operations, and requires checking limits before the next operation.

   It also explicitly keeps Decoder connected to the original `model.Source()` rather than inserting a proxy that loses optional interfaces. This matches the relevant source behavior: `core/decode/decode.go:158–176` uses Long and HasPrefix; `:373–399` uses Layered and its prefix cache; `core/decode/nbest.go:142–160` uses Exact; `core/personal/personal.go:333–336` preserves the neutral-particle system source; and `core/lexicon/neutral.go:31–74` performs fallback lookups and forwards LongestWord.

   The budget now has an explicit measurement boundary. The document correctly says it is not a count of every underlying dictionary operation.

Read inventory and limits:

- Read the complete required persona and implementation-readiness standard.
- Read only the two explicitly authorized round-two reports for prior finding context.
- Read the current protocol and complete `shift-return-source-map-v2.md`. The supplied shorthand `source-map-v2.md` resolves to that linked filename.
- Inspected the relevant schema definitions, runtime Snapshots, metadata fixtures/rows, generator examples and focused checker sections.
- Inspected the relevant production source sections in `core/lexicon/lexicon.go`, `core/lexicon/neutral.go`, `core/decode/decode.go`, `core/decode/nbest.go` and `core/personal/personal.go`.
- The initial generator-example output was truncated because of long identity arrays. Subsequent targeted reads covered case boundaries, counts, statuses, counters and checker logic; I did not independently recompute every identity hash.
- No unrelated prior reports, resolutions, history, memory, scratch experiments or prohibited evaluator directories were read. No broad source search, writes, edits, tests, compilation or subagents were used.
