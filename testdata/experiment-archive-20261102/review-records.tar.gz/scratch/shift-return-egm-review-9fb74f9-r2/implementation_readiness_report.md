# Stage9 combined report

Three unique Major contracts remain; five raw Majors and four Nits across three reviewers, no Blockers. Full reports follow.

---

# Stage 9 — Implementation readiness

Reviewer `/root/shift_round2_readiness`, fresh context. Complete returned report follows.

The plan is not yet ready under the zero-decision standard. I found two Major exchange-contract conflicts and one Major artifact gap. I found no Blocker.

1. **Major — `Step`’s return type conflicts with the exchange schema and its prohibition on reading gold.**

   Affected scope: protocol lines 30, 39, 45 and 47; packet lines 152, 161, 167 and 169; `design/shift-return-v2/schema.json:578` and `:1958`.

   The public signature is `Step(State,Event,Policy) (State,Observation,error)`, and the protocol explicitly says Observation follows the schema. That schema’s Observation is a training record containing one candidate, component/fixture IDs and required `gold_ids`. It is not the per-event Snapshot containing app, prelude, display, commit, eligibility, freeze and safety observations. Step is also forbidden from reading the fixture or gold.

   For example, the first Shift event must produce a lifecycle Snapshot with no query. There is no candidate to put into the required Observation candidate field, and Step cannot populate training gold IDs. An implementer must decide whether “Observation” means a different internal type, whether Step actually returns Snapshot, or whether an external wrapper constructs the exchange Observation.

   Specify the exact event-result type and separate it from the training Observation. State which layer constructs gold-labelled observations and which layer serializes Snapshots, including events that generate no query.

2. **Major — required Row primary metadata cannot be represented by the normative Row schema.**

   Affected scope: protocol line 183, packet line 305; `design/shift-return-v2/schema.json:1134` onward, especially Row properties and required fields.

   The protocol requires Assignment to preserve primary metadata comprising `id/category/stratum/context_class/contrast_eligible` and says Row copies the primary metadata for audit. Assignment has those fields, but Row has only `fixture_id`, `primary_category`, `context_class` and `contrast_eligible`; it has no primary stratum or primary metadata object, and `additionalProperties:false` prevents adding one.

   For a primary return task in stratum `17–64`, a faithful Row writer that copies its stratum fails schema validation; a schema-conforming writer omits metadata the protocol requires. This is a direct contract conflict, which protocol line 3 classifies as a tool error.

   Choose the exact Row representation, update both contracts consistently, and add a positive exchange example covering a primary and a variant from different strata.

3. **Major — the persisted evidence contract drops required generator diagnostics.**

   Affected scope: protocol lines 45–49, 101, 216, 228 and 230; packet lines 167–171, 223, 338, 350 and 352; CandidateOccurrence, Snapshot and Row definitions in `schema.json`.

   Generate returns `uncapped_identities`, call counts, overflow and status. The protocol requires uncapped identity/gold-survival diagnostics and locked resource counts, while explicitly excluding pruned hypotheses from the occurrence stream. The fixed output files contain Report, Row, Snapshot and CandidateOccurrence, but none has a place for the generator Result diagnostics. Row supplies only a final `gold_survived` boolean and broad support status; Snapshot has generate/score call counts, not the specified lexicon/decoder query budget or uncapped identities. `diagnostics_path` describes category/variant metrics, with no generator-result exchange format.

   For example, a final gold hypothesis pruned at position 257 and a gold hypothesis never generated can produce identical persisted candidate streams and identical `gold_survived=false` Rows. A reducer cannot recover the required distinction from those artifacts. Likewise, it cannot audit whether an episode stopped at the lexicon-query budget from the prescribed evidence alone.

   Define a persisted, query-keyed generator diagnostic record and filename, or extend an existing exchange object. Specify uncapped identity/count fields, cap overflow, resource counters/status, and how enumeration and replay write them. Include capped-out-gold and resource-exhaustion examples.

These findings concern the authorized offline evaluator, data exchange and reporting work. I do not treat deferred Windows TSF, native key recovery, composition delay or product packaging as readiness failures. The absence of the proposed evaluator files is also not a finding.

Read inventory: I read the complete implementation-readiness persona and standard; the entire 414-line review packet; its manifest; the complete normative protocol and source map as assembled in the packet; and all eleven linked exchange/worked artifacts: schema, bank example, canonical model example, checker source, cohort example, fixture examples, lifecycle example, numerical example, occurrence examples, seen example and worked report.

Source inspection was limited to permitted files. I read `core/mixedparse/context.go`, `core/lexicon/lexicon.go`, `core/input/input.go` and `core/english/dictionary.go`; inspected `core/decode/decode.go` around `MaxLen`, `spans`, `Best` and forward decoding; and inspected API locations in `core/personal/personal.go`, `core/session/mixed.go`, `core/session/session.go`, `core/mixedparse/guards.go`, `core/vocab/vocab.go` and `internal/datadir/datadir.go`. Some combined source output was truncated, so I do not claim a complete source-level parity audit of those latter files.

I did not read previous reviews, resolution reports, experimental results, history or memory. I made no edits and ran no tests, compiles, experiments or subagents.

---

# Stage 9 — Codebase details

Reviewer `/root/shift_round2_codebase`, fresh context. Complete returned report follows.

No Blocker found in the cited existing APIs. Two Major contract gaps and one Nit remain.

1. **Major — Runtime Step result conflicts with the exchange types.** Packet lines 152, 161 and 167 specify `Step(State,Event,Policy) (State,Observation,error)` and bind Observation to the schema. However, `design/shift-return-v2/schema.json:1958–2012` defines Observation as a training candidate record requiring `candidate`, `raw` and `gold_ids`. Runtime events instead produce the lifecycle fields represented by Snapshot at schema lines 578–733. Packet lines 210–220 also require closed-state handoff events, but Snapshot has no handoff field and rejects additional properties.

   Counterexample: Enter must close the fragment without generating or scoring another candidate, return its final commit, and preserve a handoff event. The specified Observation cannot represent that result without inventing training data, and Snapshot cannot serialize the required handoff.

   Specify a distinct training-observation type and runtime Step-result type; define the Snapshot/handoff relationship and exact serialized handoff shape. This concerns proposed evaluator interfaces, not a nonexistent current API.

2. **Major — Required Row metadata cannot be serialized under the schema.** Packet line 305 says Row copies primary metadata, explicitly including `id/category/stratum/context_class/contrast_eligible`. Assignment’s primary metadata objects contain those fields (`schema.json:896–970`), but Row has only `fixture_id`, `primary_category`, `context_class` and `contrast_eligible`; it lacks primary stratum (`schema.json:1123–1329`) and rejects additional properties.

   Counterexample: a component’s selected primary is in the `1` syllable stratum while another variant is in `17–64`. The required Row audit copy cannot state the selected primary’s stratum without violating the schema. A reducer can recover it from fixtures, but that does not satisfy the documented Row contract.

   Define the precise Row representation of primary metadata, including stratum, or explicitly narrow the copy requirement and require the reducer to recover the omitted fields.

3. **Nit — Define the lookup-budget counting boundary for reused Decoder calls.** Packet line 350 caps “exact/prefix” dictionary queries without specifying whether this includes Decoder’s internal calls, cached hits, or neutral-particle fallback lookups. Those distinctions exist in the reused code: `decode.go:165–183` calls `HasPrefix`, `nbest.go:142–161` calls `Exact`, and `decode.go:370–428` uses the Layered source’s `System()` and cached `Prefixed` results. `personal.go:333–336` exposes a neutral-particle wrapper that itself performs additional lookups.

   Specify which operations increment the counter, whether cache hits count, and how instrumentation preserves the `Layered` and `Long` interfaces. Otherwise independently implemented evaluators can exhaust the same nominal budget at different points.

Verification findings:

- The cited existing APIs exist and their principal described semantics match the inspected source: `datadir.Open`, `personal.NewModel`/`Source`, `SpellExact`, `NumberLike`, `Dictionary.Has`, `Decoder.Best`, `input.Exact.Expand`, lexicon APIs, Session APIs, proto constants/Text, and vocab factories.
- `vocab.Set.Add`’s third argument is indeed a timestamp.
- `Source()` preserves the neutral-particle view; empty Decoder Left resolves to BOS.
- The specified Session factory matches constructor fields and defaults. The old evaluator factory uses the documented vocab construction and excludes spaces from its raw ledger.
- Commit `e754019571573051d8c29e06526802c31d5172e2` exists. HEAD is the requested `9fb74f98828946f06f51a0dde94c4d07e8e49f50`. Within the permitted production/source trees, the production Session difference from that baseline is the insertion-observer hook in `mixed.go`; the remaining listed differences concern mixedparse or evaluator infrastructure. This inspection establishes source differences, not runtime parity.
- The future Create files are explicitly marked. Their absence is not a finding.

Actual read inventory and limits:

- Read the complete reviewer persona, readiness standard, review packet, manifest and source-map section.
- Read relevant schema definitions for events, fixtures, Query, Candidate, Snapshot, Model-adjacent contracts, Assignment/components, locks, Row, training Observation and CandidateOccurrence.
- Read worked fixtures, occurrence examples and lifecycle cases.
- Read complete `internal/datadir/datadir.go`, `core/mixedparse/context.go`, `core/mixedparse/guards.go`, `core/input/input.go`, `core/lexicon/lexicon.go`, `core/lexicon/neutral.go`, `core/proto/proto.go`, `core/session/mixed_policy.go`, and the evaluator observer/adapter.
- Inspected relevant sections of `core/personal/personal.go`, `core/english/dictionary.go`, `core/decode/decode.go`, `core/decode/nbest.go`, `core/decode/bias.go`, `core/decode/personal_mass.go`, `core/session/session.go`, `core/session/mixed.go`, and `core/vocab/vocab.go`. Some initial batched output was truncated; subsequent targeted reads covered the cited APIs and relevant implementation branches.
- No other review/resolution reports, prohibited evaluator directories, history reports, scratch experiments or broad repository searches were read. No writes, tests, compilation or subagents were used.

---

# Stage 9 — Detailed style review

Reviewer `/root/shift_round2_detail_style`, fresh context. Complete returned report follows.

No Blocker or Major style findings. Three Nits remain in the active Detailed scope.

1. Nit — Inconsistent flow names introduce an undefined prefix.

Affected scope: packet lines 225, 230, and 275; source `design/shift-return-protocol-v2.md:103`, lines 103, 108, and 153.

The text switches from `fixed`/`revise` to `O-fixed`/`O-revise` without defining `O`. Elsewhere, the named conditions are `{E0,EL,EW,EC}-{fixed,revise}` (packet line 329), and the feature specification defines only the two unprefixed flows. A fresh reader must infer whether `O` denotes another policy, a family of models, or merely the same flow. Use `fixed`/`revise` consistently, or define the prefix once and explain its relationship to the condition names.

2. Nit — One CLI paragraph combines several unrelated procedural rules.

Affected scope: packet line 165; source `design/shift-return-protocol-v2.md:43`.

This paragraph combines the shared Go invocation, fixed data arguments, output-directory convention, assignment bootstrap exceptions, validation exceptions, lock verification, Python fit invocation, selection invocation, and numerical verification. The individual requirements are concrete, but their presentation makes it difficult to locate a command’s inputs and exceptions. Split this into a shared-invocation block and a short command table. Preserve the explicit distinction that `assign` cannot read its not-yet-created assignment and lock.

3. Nit — Colloquial wording adds an accusation where a neutral requirement would be clearer.

Affected scope: packet lines 350 and 356; source `design/shift-return-protocol-v2.md:228`, lines 228 and 234.

“不能偷偷抽negative” and “不在此偷偷實作” describe covert intent rather than the permitted behavior. The requirements are adequately expressed as “超過則整次fit exit3，不得抽樣negative” and “輸出持有、實際英文延遲、Windows TSF與安裝包另立原生階段，本階段不實作.” This preserves both constraints while making the tone dry and factual.

Actual read inventory:

- Full style persona: `/workspace/.0c-tools/review-skills/vendor/elephant-goldfish-model-403d8881d62022490637d740657b33f01e321ea8/agents/style.md`.
- Full review packet, lines 1–414: `/workspace/scratch/shift-return-egm-review-9fb74f9-r2/review_target.md`. Detailed lines 138–414 were audited; Feature lines 1–137 were used for definitions and terminology.
- Full packet manifest: `/workspace/scratch/shift-return-egm-review-9fb74f9-r2/manifest.json`, identifying commit `9fb74f98828946f06f51a0dde94c4d07e8e49f50` and the source-line mappings.

Limits: This was a read-only editorial review with no additional style standard. I did not open linked exchange artifacts, implementation files, other review or resolution reports, history, or experiments. I ran no tests or builds and made no changes. I did not treat hypothetical examples or worked vectors as implementation or quality results.
