# Stage 8 — Intermediate zoom-out

Reviewer `/root/shift_round2_intermediate`, fresh context with the three authorized current-round reports. Complete returned report follows.

Stage 8 intermediate zoom-out review: no Blocker or Major findings. One existing planning Nit remains. The source is unchanged; none of the preceding reports’ suggested fixes is treated as implemented.

Blocker findings: none.

Major findings: none.

Nit — Capacity estimate understates the scope it appears to describe.

Affected scope: review_target.md lines 350–354, especially line 352; authoritative design/shift-return-protocol-v2.md lines 228–232. Related workload definitions appear at packet lines 71, 165–167, 278–287 and 291.

The estimate of approximately one million complete decodes resembles one pass over 6000 eight-syllable tasks with twenty candidates. The planned work also includes per-key observations, train/dev processing, margin selection, eight final conditions, additional variants, and long-input strata. The document does specify sharing of W and Render’s complete-decode cache within candidate processing at line 222, but does not establish sharing across conditions or phases. Consequently, the estimate does not explain the total experimental workload.

This agrees with the design critic’s capacity concern. Its initial affected reference to packet line 39 is a summary reference; the actual estimate is at line 352. Label that estimate as a single-pass approximation and account for the other phases and conditions. Include representative long cases in pre-quality calibration. Clarifying workload and measuring existing execution should precede adding any broader caching architecture. Existing resource caps and INCONCLUSIVE behavior at line 350 keep this a planning Nit.

Architectural reassessment:

The feature remains focused on the stated root problem: Shift identifies the English start, and the experiment tests the return boundary and revision of uncommitted input. Automatic English entry, general decoder replacement and native product release remain explicitly outside this experiment (packet lines 124–135, 346–356). This aligns with the README’s goal of reducing interruptions during typing.

The four predetermined feature masks and two ownership flows answer separate questions. They do not amount to speculative model-family exploration (lines 49–75, 130–135). The fixed-rule alternative receives an explicit rationale and remains a reasonable next alternative if the probe lacks benefit; the proposal does not claim superiority without comparison.

The extensive serialization, arithmetic and lifecycle rules sit within the Detailed Implementation Plan and provide reproducibility contracts. They do not introduce an architectural altitude problem in the Feature Specification. The independent reducer has a concrete purpose: deriving outcomes from frozen evidence rather than trusting replay-generated correctness flags (lines 329–333).

The comprehension and style Nits remain unresolved editorial concerns. The undefined “H1” reference, ambiguous Wilson wording and abbreviated safety summary do not establish a new simplicity, scope or reuse failure. Their existence does not justify expanding the implementation.

Reuse verification:

- Existing core/mixedparse/context.go:10 supplies SpellExact, and core/mixedparse/guards.go:15 supplies NumberLike. Both are explicitly reused in the source map at packet lines 368–369.
- Existing core/mixedparse/generator.go:27–51 requires complete parses and permits at most two syllables. Its Generate implementation at lines 89–110 rejects spaces, limits raw input to 64 bytes and requires a final non-space tone. These constraints differ materially from the planned pending-prefix, space-tone and longer-fragment contract. Reusing its complete generator would import incompatible behavior.
- Existing core/session/mixed_eval_adapter.go:76–100 provides the disposable baseline factory pattern. Its ledger at lines 105–108 excludes spaces and marks them unsupported. Packet lines 376–382 acknowledge this and preserve the factory pattern while specifying a different ledger.
- Existing internal/mixedeval/fit.py:24–106 is coupled to the previous fixtures, 26 features, estimator and selection criteria. It is not an equivalent implementation of the specified 13-feature probe.
- Existing internal/mixedeval/lock.go:44–85 binds lock generation to mixed-run-lock-v1 and existing mixed-evaluation paths. A separate version-specific lock is proportionate; a new generic lock framework is unnecessary.
- Existing Decoder.Best and lexicon.Source interfaces already provide scoring and exact/prefix lookup. The proposal uses these interfaces instead of replacing the Chinese decoding layer (packet lines 371–373).

Actual read inventory:

- Complete supplied zoom-out persona and zoom-out standard.
- Complete 414-line review_target.md, with focused follow-up reads covering truncated output.
- Complete manifest.json, including source mappings and declared snapshot.
- Complete repository README.md.
- Exactly the three authorized stage-context reports: zoom_out_report.md, comprehension_report.md and critic_report.md.
- Complete linked examples.jsonl, lifecycle.json, cohort-example.json and occurrences.jsonl.
- Selected schema.json portions at lines 600–740 and 2070–2155, covering Snapshot and CandidateOccurrence fields.
- Selected worked-report.json portions at lines 1–35 and 371–548, covering gates, paired entries, qualification and unavailable safety evidence.
- Complete core/mixedparse/generator.go, core/mixedparse/context.go and core/session/mixed_eval_adapter.go.
- Complete internal/mixedeval/fit.py; internal/mixedeval/lock.go lines 30–85.
- Selected core/mixedparse/guards.go lines 1–45, core/decode/decode.go lines 215–250 and core/lexicon/lexicon.go lines 1–55.
- Targeted reuse searches restricted to core/**/*.go, internal/datadir/**/*.go and the explicitly permitted internal/mixedeval/{fit.py,lock.go,replay.go,fixtures.go}. Other matching source files were inspected only through search excerpts.

Limits:

This was an architectural, read-only reassessment. I did not exhaustively validate the schema, numerical examples, checker implementation or all linked artifacts. No writes, edits, tests, builds, compilation, checker execution, experiments or subagents occurred. I read no other review/resolution/scratch reports, history, memory or prohibited reporttools. Suggested changes remain suggestions; authored examples remain hypothetical, and implementation parity and experimental effectiveness remain unproven.
