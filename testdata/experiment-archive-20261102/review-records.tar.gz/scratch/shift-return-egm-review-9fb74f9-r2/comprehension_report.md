## What this proposes

The proposal studies whether an input method can automatically return to Chinese after the user presses Shift to begin English. It compares four independently fitted linear models using initial evidence, subsequent input length, and subsequent word evidence, then tests each with either early ownership freezing or revision of uncommitted input. Success requires accurate boundaries and Chinese readings, measured literal preservation, and preservation of complete output; Chinese surface accuracy is reported separately. Passing permits a later output-holding and user-experience experiment, rather than product release.

## How the existing system works, per this document

Ordinary Shift enters a persistent English mode, so returning to Chinese normally requires another Shift. The existing Chinese decoder, dictionaries, and personal-model interfaces provide spelling checks, word support, and decoding scores that the experiment will reuse without replacing normal Chinese decoding. Real Session baselines cover ordinary manual operation, a gold-assisted return toggle, and the existing conservative and aggressive mixed-input behaviors. The proposed evaluator holds a virtual uncommitted fragment; this does not establish that Windows English pass-through can reclaim keys already delivered to an application.

## Blocker findings

None. I could paraphrase both the feature and implementation plan and connect the candidate generation, feature comparison, revision policies, evaluation units, and release boundary.

## Major findings

None identified within this comprehension review. The packet explains its principal project-specific concepts, distinguishes planned evaluator interfaces from existing APIs, and supplies links for the exchange contracts and reused implementation interfaces. Its examples make the distinctions between pending input, Chinese ownership, reading correctness, surface correctness, and actual output preservation understandable.

## Nit findings

1. Affected scope: Detailed Implementation Plan, §8, packet line 344 — “H1.”

   The paragraph says insufficient discordance or a zero baseline cannot support “H1,” but the packet never introduces a hypothesis with that identifier. The surrounding text makes the intended context-improvement claim understandable, so this does not prevent comprehension. Replace “H1” with the claim it denotes, or explicitly name that hypothesis where the primary context criterion is introduced.

## Actual read inventory

- Read the complete comprehension persona supplied by the caller.
- Read all 414 lines of `review_target.md`, including the portions requiring a second read because the first tool output was truncated.
- Read the packet’s `manifest.json`, including its source-file mappings and feature/implementation ranges.
- Read the linked `design/shift-return-v2/examples.jsonl` and `bank-example.json` completely.
- Read `core/mixedparse/context.go` lines 1–110 to follow the linked spelling API.
- Read the snapshot-related portion of `design/shift-return-v2/schema.json`, lines 600–740.
- Ran narrowly scoped text searches in that schema and the explicitly linked `core/mixedparse/context.go`, `core/session/session.go`, and `core/lexicon/lexicon.go` for definitions and referenced option names. Session and lexicon files were inspected through matching search output only.

## Limits

This was a read-only comprehension audit. I did not execute the example validator, tests, builds, evaluators, or experiments, and did not verify every linked artifact or establish implementation parity. I did not read previous or current review/resolution reports, experiment results, history, memory, or the prohibited evaluator/report-tool areas. The findings concern whether a fresh reader can understand the proposed design, rather than whether every implementation choice has already been specified or proven correct.

---

Reviewer `/root/shift_round2_comprehension`, fresh context. Complete returned report preserved above.
