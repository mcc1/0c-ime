# Stage 9 — Implementation readiness

Reviewer `/root/shift_round2_readiness`, fresh context. Complete returned report follows.

The plan is not yet ready under the zero-decision standard. I found two Major exchange-contract conflicts and one Major artifact gap. I found no Blocker.

1. **Major — `Step`’s return type conflicts with the exchange schema and its prohibition on reading gold.**

   Affected scope: protocol lines 30, 39, 45 and 47; packet lines 152, 161, 167 and 169; `design/shift-return-v2/schema.json:578` and `:1958`.

   The public signature is `Step(State,Event,Policy) (State,Observation,error)`, and the protocol explicitly says Observation follows the schema. That schema’s Observation is a training record containing one candidate, component/fixture IDs and required `gold_ids`. It is not the per-event Snapshot containing app, prelude, display, commit, eligibility, freeze and safety observations. Step is also forbidden from reading the fixture or gold.

   For example, the first Shift event must produce a lifecycle Snapshot with no query. There is no candidate to put into the required Observation candidate field, and Step cannot populate training gold IDs. An implementer must decide whether “Observation” means a different internal type, whether Step actually returns Snapshot, or whether an external wrapper constructs the exchange Observation.

   Specify the exact event-result type and separate it from the training Observation. State which layer constructs gold-labelled observations and which layer serializes Snapshots, including events that generate no query.

2. **Major — required Row primary metadata cannot be represented by the normative Row schema.**

   Affected scope: protocol line 183, packet line 305; `design/shift-return-v2/schema.json:1134` onward, especially Row properties and required fields.

   The protocol requires Assignment to preserve primary metadata comprising `id/category/stratum/context_class/contrast_eligible` and says Row copies the primary metadata for audit. Assignment has those fields, but Row has only `fixture_id`, `primary_category`, `context_class` and `contrast_eligible`; it has no primary stratum or primary metadata object, and `additionalProperties:false` prevents adding one.

   For a primary return task in stratum `17–64`, a faithful Row writer that copies its stratum fails schema validation; a schema-conforming writer omits metadata the protocol requires. This is a direct contract conflict, which protocol line 3 classifies as a tool error.

   Choose the exact Row representation, update both contracts consistently, and add a positive exchange example covering a primary and a variant from different strata.

3. **Major — the persisted evidence contract drops required generator diagnostics.**

   Affected scope: protocol lines 45–49, 101, 216, 228 and 230; packet lines 167–171, 223, 338, 350 and 352; CandidateOccurrence, Snapshot and Row definitions in `schema.json`.

   Generate returns `uncapped_identities`, call counts, overflow and status. The protocol requires uncapped identity/gold-survival diagnostics and locked resource counts, while explicitly excluding pruned hypotheses from the occurrence stream. The fixed output files contain Report, Row, Snapshot and CandidateOccurrence, but none has a place for the generator Result diagnostics. Row supplies only a final `gold_survived` boolean and broad support status; Snapshot has generate/score call counts, not the specified lexicon/decoder query budget or uncapped identities. `diagnostics_path` describes category/variant metrics, with no generator-result exchange format.

   For example, a final gold hypothesis pruned at position 257 and a gold hypothesis never generated can produce identical persisted candidate streams and identical `gold_survived=false` Rows. A reducer cannot recover the required distinction from those artifacts. Likewise, it cannot audit whether an episode stopped at the lexicon-query budget from the prescribed evidence alone.

   Define a persisted, query-keyed generator diagnostic record and filename, or extend an existing exchange object. Specify uncapped identity/count fields, cap overflow, resource counters/status, and how enumeration and replay write them. Include capped-out-gold and resource-exhaustion examples.

These findings concern the authorized offline evaluator, data exchange and reporting work. I do not treat deferred Windows TSF, native key recovery, composition delay or product packaging as readiness failures. The absence of the proposed evaluator files is also not a finding.

Read inventory: I read the complete implementation-readiness persona and standard; the entire 414-line review packet; its manifest; the complete normative protocol and source map as assembled in the packet; and all eleven linked exchange/worked artifacts: schema, bank example, canonical model example, checker source, cohort example, fixture examples, lifecycle example, numerical example, occurrence examples, seen example and worked report.

Source inspection was limited to permitted files. I read `core/mixedparse/context.go`, `core/lexicon/lexicon.go`, `core/input/input.go` and `core/english/dictionary.go`; inspected `core/decode/decode.go` around `MaxLen`, `spans`, `Best` and forward decoding; and inspected API locations in `core/personal/personal.go`, `core/session/mixed.go`, `core/session/session.go`, `core/mixedparse/guards.go`, `core/vocab/vocab.go` and `internal/datadir/datadir.go`. Some combined source output was truncated, so I do not claim a complete source-level parity audit of those latter files.

I did not read previous reviews, resolution reports, experimental results, history or memory. I made no edits and ran no tests, compiles, experiments or subagents.
