# Stage 9 focused re-audit — Implementation readiness

Reviewer `/root/shift_round2_reaudit_readiness`, fresh context, repaired snapshot `c512578`. Complete returned report follows.

The three prior Major conflicts are resolved at the design-contract level. I found no remaining Blocker, Major or Nit in this focused re-audit, and no material readiness contradiction introduced by these repairs.

1. **Closed — Step runtime/training types and handoff.**

   `design/shift-return-protocol-v2.md:30` now explicitly returns `(State,Snapshot,error)`. Lines 39 and 62–64 distinguish Runtime Snapshot from TrainingObservation, prohibit Step from reading fixtures or gold, assign Snapshot serialization to the runner, and assign gold-labelled training-record construction to a separate label builder. Events without queries explicitly use null query/selection IDs.

   `schema.json:582–747` defines the runtime Snapshot without candidate or gold fields; `schema.json:2346–2399` separately defines TrainingObservation with candidate and gold IDs. Snapshot now permits and requires the nullable handoff field (`schema.json:707–746`), whose exact shape is defined at `schema.json:2401–2431`.

   Protocol lines 110–112 specify closing behavior, original-event retention, action, target mode and retained prelude. `runtime-snapshots.jsonl:1–2` demonstrates both a queryless Shift snapshot and an Enter snapshot with a commit-only handoff. The checker’s lines 207–217 check these shapes and reject gold contamination. An implementer no longer needs to invent a runtime return type or serialized handoff representation.

2. **Closed — Row primary metadata.**

   Protocol lines 210–212 define `Row.primary_metadata` as the exact selected primary’s `{id,category,stratum,context_class,contrast_eligible}`. They specify that variants copy the selected primary’s metadata, retain their own fixture IDs, and require cross-checking duplicated scalar metadata. They also define the null case for compatibility rows without a primary.

   `schema.json:1310–1347` represents that object, and lines 1386–1387 make the new metadata and generator-path fields required. Assignment’s primary metadata shapes at `schema.json:911–987` agree with this representation.

   `metadata-fixtures.jsonl:1–2` supplies a primary in stratum `1` and a variant in `17-64`; `metadata-rows.jsonl:1–2` copies the primary’s stratum `1` into both Rows while retaining distinct fixture IDs. Checker lines 219–230 inspect this distinction. The prior schema prohibition against preserving the required stratum is removed.

3. **Closed — Persisted generator diagnostics.**

   Protocol lines 64 and 72–74 now require `generators.jsonl.gz`, with one GeneratorDiagnostic per actual or raw-limit-rejected query attempt. The contract defines query provenance, generation-performed status, uncapped and kept IDs/counts, literal ID, pruning and overflow indicators, status/reason, limit hit, and cumulative generator/lookup/decoder counters. It defines unknown enumeration results as null, preserving the distinction from a completed empty search.

   The runner writes this evidence from `State.last_result` for both enumeration and replay. Independent grading distinguishes cap loss, completed-search miss and unavailable enumeration. Both summarizers must read the diagnostics, validate query joins and counters, and treat missing records as incomplete evidence. The CLI and reducer arguments agree at protocol lines 41, 57 and 240.

   `schema.json:2433–2651` provides the exchange shape and required fields. `generator-examples.json:5`, `:677` and `:1348` provide separate cap-loss, generator-miss and exhausted/unavailable cases; checker lines 232–249 describe validation of those distinctions. Persisted capped candidate streams are no longer expected to reconstruct discarded hypotheses or resource counters.

4. **Closed — Related prior lookup-budget Nit.**

   Protocol line 259 fixes the counting boundary: evaluator-requested Exact/HasPrefix operations count even on local memo hits; decoder and neutral-source internal lookups do not; external Decoder.Best requests count separately. It specifies checking before executing an over-budget operation and preserving the original Source interfaces. This removes the previously identified implementation choice.

Read inventory and limits: I read the complete readiness persona and standard, both explicitly authorized prior reports, the complete current 265-line protocol, the complete actual linked source map (`design/shift-return-source-map-v2.md`), complete runtime snapshots and metadata fixtures/Rows, the complete 278-line checker, and the complete lifecycle example. I inspected the schema’s exchange dispatch, event definitions relevant to handoff, Snapshot, Assignment metadata, lock limits, Row metadata/required fields, CandidateOccurrence, TrainingObservation, handoff and GeneratorDiagnostic definitions. I inspected the generator examples’ case structure, diagnostic fields and outcomes; a full numbered dump was truncated within the long identity arrays, so I do not claim an independent exhaustive audit of every example ID.

This was a document-level focused re-audit, not executable validation or source parity verification. I did not inspect production source, other review/resolution reports, history, memory or experimental output. I made no edits or writes and ran no checker, tests, builds, experiments or subagents. Future evaluator absence and deferred native implementation are not findings.
