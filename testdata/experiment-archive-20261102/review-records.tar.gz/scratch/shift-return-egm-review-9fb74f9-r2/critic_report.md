# Stage 7 — Combined critic report

No Blocker or Major findings; three Nits. Source design has not changed. Full reports follow.

---

# Stage 7 — Design critic

Reviewer `/root/shift_round2_design`, fresh context. Complete returned report follows.

No Blocker or Major findings against the Feature Specification Standard. The mandatory alternatives evaluation is present, and the proposed experiment adequately distinguishes information masks, ownership freezing, final reading success, literal harm, and later product feasibility. The design also limits what synthetic benchmarks and the eventual GO outcome can establish.

Nit — Capacity estimate does not describe the full experiment workload.

Affected scope: `/workspace/scratch/shift-return-egm-review-9fb74f9-r2/review_target.md:39`, with supporting definitions at lines 71, 167, 278–287, and 350–354; authoritative `/workspace/0c-ime/design/shift-return-protocol-v2.md:230`.

The estimate of roughly one million complete decodes corresponds to approximately `6000 × 8 × 20`. The actual contract also includes per-key replay, eight final model/flow conditions, train/dev enumeration and margin selection, and up to four additional variants per prototype. Its required long input strata can have substantially greater candidate and decoding work than the average eight-syllable example. The document does not explain which work is shared or cached, so the estimate cannot currently serve as a full-run capacity estimate.

For example, decoding the same candidates independently for each test condition increases that portion of decoding work eightfold; reusing frozen candidate/render evidence could avoid much of that duplication, but this reuse is not specified. The existing hard caps and INCONCLUSIVE behavior prevent this from silently weakening quality gates, so this is a planning clarification rather than a validity blocker.

Recommendation: Label the current figure as a single-pass estimate and add a workload accounting that includes phases, replay conditions, variants, and intended cache reuse. Include representative long literal and long return cases in the pre-quality capacity calibration.

Actual read inventory:

- Complete design-critic persona and Feature Specification Standard.
- Complete review target, lines 1–414, including the active Feature Specification and supporting Detailed Implementation Plan.
- Packet `manifest.json`, including its 16-source mappings.
- Complete linked `schema.json`; truncated output was recovered through additional reads.
- Complete linked artifacts: `examples.jsonl`, `numerical.json`, `worked-report.json`, `cohort-example.json`, `bank-example.json`, `canonical-model-sample.json`, `seen-example.json`, `occurrences.jsonl`, `lifecycle.json`, and `check_examples.py`.
- Authoritative protocol lines 180–234 were additionally read with source line numbers.

Limits: This was a read-only design audit. I did not run validators, tests, compilation, fitting, or quality experiments, and did not inspect production API implementations. API parity and experimental results therefore remain future evidence as the document itself states. No previous review/resolution reports, scratch experiments, history, memory, or prohibited evaluator/reporting internals were read.

---

# Stage 7 — Structural review

Reviewer `/root/shift_round2_structural`, fresh context. Complete returned report follows.

Structural review: no Blocker, Major, or Nit findings in the active Feature Specification scope, review_target.md lines 1–137.

The authored documents use a consistent H1 → H2 hierarchy. In the assembled packet, these become H3 → H4 beneath the packet’s H1 → H2 structure. The repeated “Source” headings and the protocol split at line 138 are assembly choices, not authored defects.

The supplied standard defines required subject coverage, but does not prescribe exact heading names or section order. The active scope makes the problem and goals accessible at lines 13–17, scope exclusions at lines 29 and 124, the proposed comparison structure at lines 47–75, alternatives and rejection rationale at lines 122–133, and risks and limits at lines 21–39 and 92–110. Its explicit protocol links provide the detailed architecture and safeguards.

The active tables have consistent column counts and separator rows; the bullet list and shell code fence are well formed. All active Markdown links have descriptive labels and syntactically valid local targets. The seven distinct linked target files exist.

Read inventory:
- Complete structural persona and Feature Specification Standard supplied in the task.
- Complete active packet lines 1–137.
- Complete manifest.json.
- Supporting packet lines 175–230, plus visible portions of the initial packet read, including lines 303–414. The initial whole-packet output was truncated; I do not claim a complete detailed-plan read.
- Heading-only inspection of the four authored documents represented in the active scope.
- File metadata for the seven distinct active link targets.

Limits: This was a structural review, not a validation of numerical examples, schema semantics, implementation feasibility, or runtime behavior. Linked artifact contents were not audited. No files were changed, and no tests, compiles, experiments, or subagents were run. No other review reports or history were read.

---

# Stage 7 — Feature style review

Reviewer `/root/shift_round2_feature_style`, fresh context. Complete returned report follows.

No Blocker or Major style findings. Two precision Nits remain within Feature lines 1–137.

1. Nit — Packet line 104; `design/shift-return-worked-scoring.md:26`.
   “若有錯誤，上限可能不達1%” makes the inequality unclear. Literally, “不達1%” can mean below 1%, which satisfies the required upper-bound threshold. The intended concern is failure to satisfy the ≤1% requirement. Write “若有錯誤，Wilson95上限可能超過1%，不追加案例直到過關。”

2. Nit — Packet line 35; `design/shift-english-auto-return-experiment.md:27`.
   “零不可逆原鍵／提交／保護狀態破壞” leaves unclear whether reversible key or state violations are permitted. The authoritative G5 definition at packet line 342 requires zero dropped/duplicated keys, application rewrites, and explicit-lock violations without an irreversibility qualification. Replace this summary phrase with a direct reference to the zero-violation requirement, such as “且G5的原鍵、提交與保護狀態檢查全部通過。”

Read inventory: the complete style persona; review packet lines 1–414, with findings restricted to Feature lines 1–137; and the packet manifest, including source-line mappings. Detailed lines 138–414 were consulted only to resolve terminology and requirements.

Limits: no additional style standard was supplied. No linked artifact contents or repository implementation files were needed for these editorial findings. No previous reviews, resolution reports, history, tests, compiles, writes, experiments, or subagents were used.
