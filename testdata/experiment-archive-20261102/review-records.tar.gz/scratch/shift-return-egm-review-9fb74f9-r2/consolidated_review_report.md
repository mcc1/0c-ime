# EGM round two — Shift-return experiment design

**Final decision: the design contract may proceed to P0 offline tool implementation and verification. No Blocker or Major from this round remains open after the focused re-audit.** This is not a quality-experiment pass, native-output pass or product-release approval.

The full five-stage flow reviewed `9fb74f98828946f06f51a0dde94c4d07e8e49f50` with nine accepted fresh-context reviewers. It found three unique Major exchange-contract gaps and eight unique Nits. The parent applied repairs under the user's existing modification authorization, committed them as `c512578157607615ed114feba20c8a443f260a19`, and ran one focused re-audit with two new reviewers. Both confirmed the Major closures and found no remaining Blocker, Major or Nit within their repaired-contract scope.

## Scope, isolation and artifacts

- Workflow: [EGM review skill](/workspace/.0c-tools/review-skills/vendor/elephant-goldfish-model-403d8881d62022490637d740657b33f01e321ea8/skills/egm-review/SKILL.md), pinned bundle `403d8881d62022490637d740657b33f01e321ea8`. The previously selected uninterrupted full flow was reused.
- Original [review packet](review_target.md): Feature lines 1–137, Detailed lines 138–414. [Manifest](manifest.json) maps the sixteen original authored source files and their hashes.
- All reviewers used native `spawn_agent` with `fork_turns: none`. Stage 8 received only this round's three required earlier reports. The focused re-auditors received only this round's readiness/codebase reports. No parent transcript, private reasoning, old experiment results or memory was supplied.
- One initial zoom-out attempt accidentally encountered old result-script snippets during a broad search. It was excluded from the verdict and replaced. Subsequent prompts restricted source searches and prohibited historical report directories. See [isolation note](isolation-note.md). The excluded attempt is not one of the nine accepted stage reviewers.
- No authored source changed until all five initial stages completed. The original source bytes can be recovered from `source-snapshots/9fb74f9/`; repaired bytes are archived in `source-snapshots/c512578/`. The original packet is not relabeled as a review of the repair.

## Stage results before repair

| Stage | Accepted reviewers | Result |
| --- | --- | --- |
| 5 Initial zoom-out | 1 replacement reviewer | No findings |
| 6 Comprehension | 1 | One Nit: undefined H1 label |
| 7 Design / structure / style | 3 | No Blocker/Major; three Nits |
| 8 Intermediate zoom-out | 1 | Repeats the capacity-estimate Nit; no Blocker/Major |
| 9 Readiness / codebase / detailed style | 3 | Five raw Major findings, deduplicated into three contract gaps; four Nits |

Across the accepted initial reviews: **zero Blockers, three unique Majors and eight unique Nits.** The capacity Nit is repeated in two stages and counted once. Repeated reports are not independent votes or additional defects.

## Major findings and closure evidence

| ID | Original finding | Applied repair | Independent closure |
| --- | --- | --- | --- |
| M1 | Step returned an Observation type that required training candidates/gold, while runtime events need Snapshot; handoff was not serializable | Step now returns Snapshot. TrainingObservation is separately typed and built by a gold-aware external label builder. Snapshot has a typed nullable handoff and queryless lifecycle examples. | Both focused reviewers: closed |
| M2 | Row was required to copy primary stratum metadata but its strict schema could not store it | Row now requires primary_metadata containing selected primary id/category/stratum/context/contrast fields. Variants retain their own fixture ID while copying the selected primary. Positive examples cover different strata. | Both focused reviewers: closed |
| M3 | Required uncapped generation, pruning and resource diagnostics had no persisted exchange record | Added GeneratorDiagnostic, `generators.jsonl.gz`, query joins and reducer inputs. Records distinguish cap loss, completed-search miss and incomplete/exhausted enumeration without inventing empty sets. | Both focused reviewers: closed |

The follow-up also specifies a complete Evidence bundle for Go summarization rather than relying on hidden qualification state. Runtime records never acquire gold fields merely to satisfy a serialization shape.

## Nit disposition

All eight editorial/planning items were applied. Only the lookup-boundary item was independently re-audited as part of the focused technical scope; the parent checked the remaining textual repairs. Do not interpret the follow-up as a second full style review.

| ID | Finding | Repair |
| --- | --- | --- |
| N1 | H1 used without definition | Replaced with the actual context-effect claim |
| N2 | One-million-decode estimate omitted phases, conditions, variants and long tasks | Labeled single-pass example; added workload accounting, explicit no cross-phase/condition cache, and fixed long-input calibration cases |
| N3 | “Upper bound may not reach 1%” obscured the inequality | Now explicitly says the upper bound may exceed1% |
| N4 | Overview's “irreversible violations” wording weakened G5 | Overview now directly requires all G5 checks |
| N5 | Lookup budget counting boundary was ambiguous | Counts evaluator-direct logical Exact/HasPrefix requests, including memo hits; counts external Best calls separately; leaves original Source interfaces intact |
| N6 | O-fixed/O-revise were undefined aliases | Uses fixed/revise consistently |
| N7 | CLI rules crowded one paragraph | Split shared arguments and command-specific exceptions into a block/table |
| N8 | Accusatory wording in resource/scope requirements | Replaced with direct prohibitions and phase scope |

## Traceability

| Raw report finding | Consolidated item |
| --- | --- |
| [Readiness](readiness_report.md) 1; [Codebase](codebase_details_report.md) 1 | M1 |
| Readiness2; Codebase2 | M2 |
| Readiness3 | M3 |
| [Comprehension](comprehension_report.md) Nit | N1 |
| [Design critic](design_critic_report.md) Nit; [Intermediate zoom-out](intermediate_zoom_out_report.md) Nit | N2 |
| [Feature style](feature_style_report.md) 1–2 | N3–N4 |
| Codebase3 | N5 |
| [Detailed style](readiness_style_report.md) 1–3 | N6–N8 |

The [initial zoom-out](zoom_out_report.md) and [structural](structural_report.md) reviewers returned no findings. [Combined critic](critic_report.md) and [combined readiness](implementation_readiness_report.md) files preserve the complete individual reports. The original full-flow readiness verdict was not a pass; it was repaired afterward, rather than overwritten.

Focused final reports:

- [Readiness re-audit](reaudit_readiness_report.md): all three Major conflicts closed, no new finding in focused scope.
- [Codebase re-audit](reaudit_codebase_report.md): all three Major conflicts plus the lookup-budget Nit closed, no new finding in focused scope.

## Verification actually performed

The parent ran `python3 design/shift-return-v2/check_examples.py` and `python3 scripts/check_public_tree.py`. The [repair check log](remediation-check.log) records schema/ownership/reading/analytic checks, the eight-condition/ten-comparison hypothetical report, primary/variant strata, runtime/training separation, handoff shapes and cap-loss/search-miss/exhaustion distinctions. Whitespace and Markdown target existence were also checked. The source changes are confined to design documents and their example checker/artifacts; production behavior was not changed.

Reviewers inspected documents and source read-only; they did not run the evaluator or tests. Some reported truncated broad outputs, then retrieved relevant narrower sections. Their full read inventories and limits are preserved. Neither parent checks nor review approval establish new-tool runtime parity, actual dataset qualification, learned model quality, native TSF behavior or latency.

## Next permitted conclusion

The contract is ready to guide P0 implementation/verification. P0–P3 must still implement and verify the planned tools and source parity; data and tool hashes must be frozen before the new quality experiment. The 90% return, 30% improvement, confidence, literal-risk and safety gates remain unchanged by this round's repairs. Only measured passage of those gates can support the later output experiment. No dataset acquisition, model fitting or quality replay took place in this round.
