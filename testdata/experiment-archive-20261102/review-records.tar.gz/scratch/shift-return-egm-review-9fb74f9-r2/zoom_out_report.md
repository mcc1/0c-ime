# Stage 5 — Initial zoom-out

Reviewer `/root/shift_round2_zoom_clean`, fresh context; replacement for the excluded search-exposure attempt. Complete returned report follows.

Zoom-out review: PASS. No Blocker, Major, or Nit findings supported by this read-only architectural audit.

The feature scope supplies sufficient context and stays focused on the root problem: Shift already marks the English start, so the experiment studies the return boundary and revision within an uncommitted fragment. It explicitly excludes automatic English entry, general decoder replacement, and product release (packet lines 15–39, 124–135). This fits the README’s goal of reducing manual interruption during input.

The main architectural choices are proportionate to the experiment. Four predetermined feature masks and two ownership flows isolate distinct questions; they are not a search over speculative model families (packet lines 49–75, 130–135). The fixed-rule alternative is considered explicitly, and the document limits what a linear-probe failure can establish. The detailed numeric and serialization rules belong in the detailed implementation section rather than constituting an altitude drop in the feature specification.

The separation between immutable candidate scoring, disposable real Session baselines, and virtual output ownership is clear (packet lines 150–161, 184–222). Keeping the initial recognition experiment separate from native output holding avoids silently treating an offline prediction as a working Windows input feature (packet lines 346–356). The independent reducer adds work, but it has a concrete verification role: it checks recorded evidence against frozen labels instead of trusting replay-produced correctness flags (packet lines 329–333).

Reuse verification found no substantiated reinvention requiring a finding:

- `core/mixedparse/context.go:10` already supplies `SpellExact`, and `core/mixedparse/guards.go:15` supplies `NumberLike`; both are explicitly reused in the source map (packet lines 368–369).
- Existing `core/mixedparse/generator.go:27–51,89–110` requires complete parses, supports at most two syllables, excludes spaces, limits raw input to 64 bytes, and searches only at explicit non-space tone endings. It cannot directly implement the proposed pending-prefix, first-tone-space, longer-fragment contract. A separate generator is justified.
- Existing `core/mixedparse/state.go:128–180` uses tone-opportunity selection and the older raw/window semantics. Direct reuse would import behavior outside the new Shift eligibility and ownership contract.
- `core/session/mixed_eval_adapter.go:76–126` provides the disposable factory pattern but omits spaces from its raw ledger and explicitly marks space handling unsupported. The source map acknowledges this limitation and preserves factory reuse while replacing the ledger behavior (packet lines 376–382).
- Existing `internal/mixedeval/fit.py` trains 26 features under different pair weighting, optimization, and selection rules. Its presence does not make it an equivalent implementation of the specified 13-feature estimator.
- Existing lock code is coupled to mixed-eval-v1 inputs and paths. A version-specific shift-return lock is reasonable; the proposal does not need a generic lock framework.

Actual read inventory:

- Complete supplied zoom-out persona and zoom-out standard.
- All 414 packet lines, using supplemental reads to cover the initially truncated middle; the packet manifest.
- Repository `README.md`.
- Complete linked examples: `examples.jsonl`, `lifecycle.json`, `bank-example.json`, `cohort-example.json`, `seen-example.json`, `occurrences.jsonl`, `numerical.json`, and `canonical-model-sample.json`.
- `check_examples.py` source; selected schema portions covering Query, Candidate, safety, metrics, Sources, and Observation; selected worked-report portions covering gates, conditions, paired comparisons, qualification, derived metrics, and unavailable safety.
- Complete `core/mixedparse/{context,generator,types}.go`, `core/session/mixed_eval_adapter.go`, and `internal/mixedeval/fit.py`.
- Selected portions of `core/mixedparse/{state,guards}.go`, `core/lexicon/lexicon.go`, `core/input/input.go`, `core/personal/personal.go`, `core/english/dictionary.go`, `internal/datadir/datadir.go`, and `internal/mixedeval/lock.go`.
- Restricted declaration/API searches in `core/**/*.go`, `internal/datadir/**/*.go`, and the explicitly permitted evaluator source files.

Limitations: This is an architectural review, not exhaustive schema or implementation validation. The full schema and worked-report bodies were not read line by line. Some batched tool output was truncated; conclusions above rely on visible source or subsequent focused reads. No writes, compilation, tests, checker execution, experiments, or subagents occurred. No previous/current review reports, resolution reports, scratch experiments, conversation history, or reporttools were read. The authored examples remain hypothetical evidence.
