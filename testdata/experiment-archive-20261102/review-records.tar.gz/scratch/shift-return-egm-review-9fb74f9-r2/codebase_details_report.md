# Stage 9 — Codebase details

Reviewer `/root/shift_round2_codebase`, fresh context. Complete returned report follows.

No Blocker found in the cited existing APIs. Two Major contract gaps and one Nit remain.

1. **Major — Runtime Step result conflicts with the exchange types.** Packet lines 152, 161 and 167 specify `Step(State,Event,Policy) (State,Observation,error)` and bind Observation to the schema. However, `design/shift-return-v2/schema.json:1958–2012` defines Observation as a training candidate record requiring `candidate`, `raw` and `gold_ids`. Runtime events instead produce the lifecycle fields represented by Snapshot at schema lines 578–733. Packet lines 210–220 also require closed-state handoff events, but Snapshot has no handoff field and rejects additional properties.

   Counterexample: Enter must close the fragment without generating or scoring another candidate, return its final commit, and preserve a handoff event. The specified Observation cannot represent that result without inventing training data, and Snapshot cannot serialize the required handoff.

   Specify a distinct training-observation type and runtime Step-result type; define the Snapshot/handoff relationship and exact serialized handoff shape. This concerns proposed evaluator interfaces, not a nonexistent current API.

2. **Major — Required Row metadata cannot be serialized under the schema.** Packet line 305 says Row copies primary metadata, explicitly including `id/category/stratum/context_class/contrast_eligible`. Assignment’s primary metadata objects contain those fields (`schema.json:896–970`), but Row has only `fixture_id`, `primary_category`, `context_class` and `contrast_eligible`; it lacks primary stratum (`schema.json:1123–1329`) and rejects additional properties.

   Counterexample: a component’s selected primary is in the `1` syllable stratum while another variant is in `17–64`. The required Row audit copy cannot state the selected primary’s stratum without violating the schema. A reducer can recover it from fixtures, but that does not satisfy the documented Row contract.

   Define the precise Row representation of primary metadata, including stratum, or explicitly narrow the copy requirement and require the reducer to recover the omitted fields.

3. **Nit — Define the lookup-budget counting boundary for reused Decoder calls.** Packet line 350 caps “exact/prefix” dictionary queries without specifying whether this includes Decoder’s internal calls, cached hits, or neutral-particle fallback lookups. Those distinctions exist in the reused code: `decode.go:165–183` calls `HasPrefix`, `nbest.go:142–161` calls `Exact`, and `decode.go:370–428` uses the Layered source’s `System()` and cached `Prefixed` results. `personal.go:333–336` exposes a neutral-particle wrapper that itself performs additional lookups.

   Specify which operations increment the counter, whether cache hits count, and how instrumentation preserves the `Layered` and `Long` interfaces. Otherwise independently implemented evaluators can exhaust the same nominal budget at different points.

Verification findings:

- The cited existing APIs exist and their principal described semantics match the inspected source: `datadir.Open`, `personal.NewModel`/`Source`, `SpellExact`, `NumberLike`, `Dictionary.Has`, `Decoder.Best`, `input.Exact.Expand`, lexicon APIs, Session APIs, proto constants/Text, and vocab factories.
- `vocab.Set.Add`’s third argument is indeed a timestamp.
- `Source()` preserves the neutral-particle view; empty Decoder Left resolves to BOS.
- The specified Session factory matches constructor fields and defaults. The old evaluator factory uses the documented vocab construction and excludes spaces from its raw ledger.
- Commit `e754019571573051d8c29e06526802c31d5172e2` exists. HEAD is the requested `9fb74f98828946f06f51a0dde94c4d07e8e49f50`. Within the permitted production/source trees, the production Session difference from that baseline is the insertion-observer hook in `mixed.go`; the remaining listed differences concern mixedparse or evaluator infrastructure. This inspection establishes source differences, not runtime parity.
- The future Create files are explicitly marked. Their absence is not a finding.

Actual read inventory and limits:

- Read the complete reviewer persona, readiness standard, review packet, manifest and source-map section.
- Read relevant schema definitions for events, fixtures, Query, Candidate, Snapshot, Model-adjacent contracts, Assignment/components, locks, Row, training Observation and CandidateOccurrence.
- Read worked fixtures, occurrence examples and lifecycle cases.
- Read complete `internal/datadir/datadir.go`, `core/mixedparse/context.go`, `core/mixedparse/guards.go`, `core/input/input.go`, `core/lexicon/lexicon.go`, `core/lexicon/neutral.go`, `core/proto/proto.go`, `core/session/mixed_policy.go`, and the evaluator observer/adapter.
- Inspected relevant sections of `core/personal/personal.go`, `core/english/dictionary.go`, `core/decode/decode.go`, `core/decode/nbest.go`, `core/decode/bias.go`, `core/decode/personal_mass.go`, `core/session/session.go`, `core/session/mixed.go`, and `core/vocab/vocab.go`. Some initial batched output was truncated; subsequent targeted reads covered the cited APIs and relevant implementation branches.
- No other review/resolution reports, prohibited evaluator directories, history reports, scratch experiments or broad repository searches were read. No writes, tests, compilation or subagents were used.
