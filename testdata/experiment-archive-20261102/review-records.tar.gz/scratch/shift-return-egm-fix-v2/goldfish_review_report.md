# Goldfish Annotated Review Report

Status: resolved — proposed edits applied; document/example checks passed. This is not an independent EGM pass for the final patch.

**Target:** Shift-return design documents, full files; v1 findings from the e91bbd7 review.

The user explicitly instructed modification after receiving the consolidated report. This is the authorized custom-instruction/batch-edit path of EGM resolve; no additional approval gate was requested. All13 items are PROPOSE FIX, with original severities retained; no contests, escalations or declines. The old review and frozen packet remain unchanged.

## A1 — Severity: Blocker

- **Discrepancy Description:** Evaluator files/interfaces/schemas/CLI/checkpoints were deferred.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 sections2/9; schema.json; check_examples.py.
- **Change:** Create-only map, typed records, phase commands, deterministic failures and independent reducer.

## A2 — Severity: Blocker

- **Discrepancy Description:** B recommendation flags and score adapters were undefined.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section5; source-map-v2.md.
- **Change:** Remove the two undefined recommendation flags before any new data, retain actual C/A controls, define13-dimensional sources and distinct prefix-supported versus complete log scores.

## A3 — Severity: Major

- **Discrepancy Description:** Shift/space/baseline/output replay lacked contracts.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section3.
- **Change:** Explicit eligibility/lifecycle table, actual Toggle mapping, C/A intentional Shift omission, application ledger and bounded closed-state handoff.

## A4 — Severity: Major

- **Discrepancy Description:** Pending features/render/ownership and freeze projection were incomplete.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section4; source-map worked vectors.
- **Change:** Define n/k, exact leading coverage, pending raw display, candidate/display identities and worked fixed/revise transitions.

## A5 — Severity: Major

- **Discrepancy Description:** Fitting arithmetic, label projection and normalization were ambiguous.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section6; numerical.json.
- **Change:** Exact logistic objective/gradient, hierarchical pair weights, population standardization, multiple-gold handling and analytic update.

## A6 — Severity: Major

- **Discrepancy Description:** Acquisition/categories/strata/contrast cohort were unspecified.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section7.
- **Change:** Fixed synthetic task source procedure, two blind annotation passes, taxonomy precedence, category budgets, separate return/literal length strata and deterministic contrast predicate.

## A7 — Severity: Major

- **Discrepancy Description:** Group/component independence for Wilson was unclear.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 sections7/8; worked-scoring.md.
- **Change:** Group equals transitive component, one primary per intent, correlated variants excluded from n and counts worked example.

## A8 — Severity: Major

- **Discrepancy Description:** Dev risk rates, bootstrap and reporting formulas were incomplete.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 sections6/8; worked-report.json; schema report/row/observation definitions.
- **Change:** Both literal rates independently gated, deterministic bootstrap/empty strata treatment, paired/interaction/stability formulas and complete hypothetical report.

## A9 — Severity: Major

- **Discrepancy Description:** The ranker choice lacked alternatives analysis.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section1.
- **Change:** Compare manual, deterministic word trigger, learned local probe and abstention; explain calibration/interaction objective without claiming superiority over untested rules.

## A10 — Severity: Major

- **Discrepancy Description:** Overview and detail disagreed about shared coefficients.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Overview, combination-order, protocol v2 sections1/5.
- **Change:** Four separately fitted masks share procedure, data and budget; frozen EC sensitivity probe is separately named.

## A11 — Severity: Major

- **Discrepancy Description:** Correct character and correct reading were conflated.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Overview, protocol v2 section8; worked-scoring.md.
- **Change:** Name boundary_reading_success, surface_success and materialization_success;90% only means first metric.

## A12 — Severity: Nit

- **Discrepancy Description:** Resource limits did not bound computation/artifacts.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** Protocol v2 section9.
- **Change:** Query/decoder/pair/disk budgets and fail-visible exhaustion; no excluded difficult rows.

## A13 — Severity: Nit

- **Discrepancy Description:** Navigation/canonical terminology/frozen information/side-effect wording needed cleanup.
- **AI Suggestion:** PROPOSE FIX
- **Justification:** This affects reproducibility, validity or reader understanding and is supported by the original review.
- **Proposed Edit / applied location:** All revised summaries and source map.
- **Change:** One normative version, linked exact APIs, canonical identity, explicit zero learning/persistence counters, information versus ownership distinction.

## Verification status

Schema/ownership/reading examples, three invalid cases, analytic gradient/normalization and the eight-condition hypothetical report pass the document checker. Existing Decoder.Best was separately exercised on a tiny fixed lexicon: first syllable prefix score -2, complete-only missing, complete two-syllable word score -2. These checks do not execute the new evaluator, public-quality replay or model fitting. Three fresh-context reviewers audited commit392b27e and returned further gaps. The final patch addresses these as recorded below; it was checked by the parent, not subjected to another independent EGM round. No claim of final independent review passage is made.

## Focused re-audit and final repair trace

The raw re-audits remain in design_reaudit.md, source_reaudit.md and readiness_reaudit.md. They reviewed392b27e, not the final revision. Original severities are retained. Duplicate reports describe the same missing contract, not independent additional defects.

| Item | Raw findings | Applied repair / evidence |
| --- | --- | --- |
| F1 Cohort/reducer inputs | Readiness1 Blocker; Source1 Major; Design3 Major | Frozen per-primary category/contrast metadata, fixture/bank/source/event/candidate reducer inputs and joins; mixed-component cohort example checked |
| F2 Seen inputs | Readiness2 Major | Assign receives Sources, explicit matching/hash rules and whole-component regression test |
| F3 Canonical fitting/bytes | Readiness3 Major | Explicit observation/pair order, two-pass float64 reduction and Python reference writer; shuffled-observation ordering and canonical model/hash checked |
| F4 Positive evidence requirement | Design1 Major | G3 now additionally requires positive paired absolute-error-reduction CI lower bounds and20discordant components for each main comparison; fixed before any new quality measurement |
| F5 Interval statistic / zero baseline | Readiness4 and Design2 Major | Named absolute_error_reduction_ci95; baseline-zero resamples stay valid; sparse toy shows [0,.75], not a supported improvement |
| F6 Prelude lifecycle | Readiness5 Major | Unified Close postconditions plus cancel exception;11 nonempty-prelude cases checked |
| F7 Acquisition bank | Readiness6 Major | Persisted BankTask schema, prompt normalization, typo/source spans, annotation linkage and deterministic fixture conversion; prototype-ID example checked |
| F8 Unknown safety | Source2 Major | Nullable counters, availability/reason fields, unknown propagation; no-replay example has null, and fabricated zero is rejected |
| F9 Candidate occurrence | Source3 Major | Query occurrence envelope and query_id joins; two local-ID collisions with distinct inputs checked |
| F10 Full paired report | Design4 Nit | All10 required pairs present, unavailable contrast entries explicit |
| F11 Vocabulary argument | Source4 Nit | now=0 documented as timestamp, not weight |

## Final scope and remaining execution work

All original13 proposed fixes and the focused re-audit repairs have been applied to design artifacts. There were no contests, escalations or declined Nits. Final commit: 9fb74f98828946f06f51a0dde94c4d07e8e49f50. The follow-up is a parent repair, not a second re-audit of each stage; the EGM one-re-audit limit is respected.

The schema and toy examples pass; links, whitespace and public-tree checks pass. The existing decoder tiny probe returned first-prefix -2, complete-first missing, complete-word -2. These are bounded document/source checks. P0–P3 evaluator implementation and parity, new dataset qualification, model fitting, final replay and output/native integration remain future authorized phases, not completed evidence. Final independent EGM passage is not claimed. No product behavior or installer changed.
