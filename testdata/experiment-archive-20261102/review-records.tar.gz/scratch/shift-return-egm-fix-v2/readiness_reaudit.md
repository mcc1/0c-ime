# Focused EGM implementation-readiness re-audit

Snapshot `392b27efc5db66323afadb4b2d7a910c6fd8bbc9`; reviewer `/root/shift_v2_readiness_audit`, fresh context. Complete returned report follows.

The offline plan does not yet meet the zero-decision implementation-readiness standard. The schemas settle many exchange formats, but consequential input, reporting, reproducibility, and lifecycle choices remain.

1. **Blocker — The independent report reducer cannot recover the required context cohort from its permitted inputs.**

   Affected sources: `shift-return-protocol-v2.md:35`, `:158`, `:178`, `:185`; `schema.json:818–868`, `:1006–1164`.

   The reducer is restricted to frozen rows and assignment. However, a Row contains neither `context_class` nor another context-contrast membership field. Assignment components contain row IDs, primary IDs, and category strings, but no context-contrast membership. The predicate in line 158 depends on source gold, shared prefixes, continuations, and dictionary evidence. None of that can be reconstructed from the allowed reducer inputs.

   Concrete counterexample: two return components can have identical assignment structure and final model error flags while only one belongs to the qualifying context-contrast cohort. Their required G3 statistics differ, but the reducer sees no distinguishing field.

   Add frozen, validated primary-level cohort membership to Row or Assignment, or explicitly authorize a specified frozen cohort manifest as another reducer input. Define how membership survives primary selection when a component contains both qualifying and nonqualifying variants. Include a small worked reducer input/output demonstrating that G3 uses the intended subset.

2. **Major — `assign` cannot perform the specified seen-data exclusion with its documented inputs.**

   Affected sources: `shift-return-protocol-v2.md:28`, `:40`, `:42`, `:146`, `:156`; `schema.json:888–895`, `:1559–1585`.

   `Assign([]Fixture)` and the CLI instructions say assignment reads only fixtures. Yet assigning a component to `regression` requires comparison against the frozen seen prefixes, contents, and raw inputs. Those lists live in Sources, not Fixture, and Assignment must also record `seen_sha256`.

   Concrete counterexample: the same fixture file paired with an empty seen list belongs to its hash-selected formal split; paired with a seen list containing its English prefix, its entire component must become regression. A fixture-only function cannot produce both correct answers.

   Specify the seen manifest input, exact matching rules, its digest scope, and the API/CLI argument that supplies it. Include a test that changes only the seen manifest and verifies whole-component exclusion.

3. **Major — The deterministic fitting contract names a canonical order without defining it, and its canonical JSON rules do not determine numeric bytes.**

   Affected sources: `shift-return-protocol-v2.md:44`, `:130`, `:132–134`; `schema.json:744–795`.

   Training requires canonical pair accumulation, single-threaded float64 arithmetic, and byte-identical reproduced models. No canonical pair ordering tuple is specified. The standardization population also has no specified accumulation order. Sorting JSON object keys does not establish the ordering of observations, candidates, or pairs.

   Furthermore, UTF-8, sorted keys, and no whitespace do not uniquely encode floating-point values: `1`, `1.0`, and `1e0`, or `0` and `-0`, can satisfy those rules while producing different bytes and hashes.

   Specify observation and pair sort keys, mean/variance accumulation order and algorithm, and a cross-language numeric serialization convention. Add a fixture with deliberately shuffled input rows and a normative serialized model/hash. Otherwise independent implementations can satisfy the documented mathematics while failing the mandated byte comparison.

4. **Major — The paired confidence interval has no defined statistic.**

   Affected sources: `shift-return-protocol-v2.md:170`, `:176`, `:178`; `schema.json:1294–1362`; `worked-report.json:371–383`.

   A paired record carries repaired count, worsened count, integer net, relative error reduction, and one `bootstrap95`. The contract explains resampling and quantiles but never identifies which statistic that interval bounds. The worked example leaves the interval null, so it does not settle the ambiguity.

   Concrete counterexample: with 100 components, 20 baseline errors, and 10 challenger errors, the interval could describe net repaired components, absolute error-rate reduction, or relative error reduction. Those have different scales and different behavior when a bootstrap sample has zero baseline errors.

   Name the interval statistic explicitly, or provide separate fields for each required statistic. Define the zero-baseline policy for each replicate and give a non-null worked interval example.

5. **Major — Closing transitions do not consistently specify what happens to the retained prelude.**

   Affected sources: `shift-return-protocol-v2.md:38`, `:64–74`, `:80`; `schema.json:599–610`.

   The state and view formula distinguish application text, prelude composition, and research display. Enter explicitly appends `prelude + display`. A second Shift instead appends the current display and clears research state; focus, cursor, paste, and protection transitions similarly seal the display without specifying whether the prelude is appended, retained, or handed back to Session.

   Concrete counterexample: start with `app=""`, `prelude="中"`, and research display `"x窄"`. Applying `app += display` while retaining the prelude yields `"x窄中"` under the prescribed view formula; clearing the prelude loses `"中"`. Preserving order requires a further decision about committing or transferring the prelude.

   Give exact postconditions for `app`, `prelude`, `display`, `closed`, and handoff output for every closing event. Add lifecycle fixtures with a nonempty prelude, including second Shift, focus, paste, protect, and cancel. This concerns the offline state/ledger implementation, not deferred native output integration.

6. **Major — The acquisition bank lacks the persisted task contract needed for reproducible prototype construction and annotation validation.**

   Affected sources: `shift-return-protocol-v2.md:144–156`; `schema.json:312–414`, `:1489–1587`.

   Prototype IDs hash `{source_ref,intent,prompt,raw,gold}`, and category selection, typo classification, independent annotation, public-source modifications, and budget selection all depend on acquisition metadata. Fixture has no prompt or designated typo span. Sources has generic reference/hash fields but no defined bank/task shape or task-level annotation/adjudication linkage. No additional bank schema, path, or interface is specified.

   Consequently, an implementer must independently design the artifact that makes these prescribed operations reproducible. A generic source hash cannot by itself tell a fresh implementation how to retrieve and canonicalize the prompt or validate task-specific labels.

   Define the acquisition-bank record, canonical prompt representation, task/source linkage, designated typo spans, annotation records, and the transformation into fixtures. Provide one example showing prototype-ID calculation and deterministic budget selection. Keep these authoring labels outside policy inputs.

Actual read inventory:

- Entire implementation-readiness persona and implementation-readiness standard requested by the parent.
- Entire `design/shift-return-protocol-v2.md` — 201 lines.
- Entire `design/shift-return-source-map-v2.md` — 41 lines.
- Entire `design/shift-return-v2/schema.json` — 1,699 lines; reread the initially truncated portions in bounded ranges.
- Entire `examples.jsonl` — 5 records.
- Entire `numerical.json` — 27 lines.
- Entire `worked-report.json` — 456 lines.
- Entire `check_examples.py` — 105 lines.
- Entire current experiment, combination-order, and worked-scoring summaries — 31, 33, and 34 lines respectively.
- Additional source inspection: `core/mixedparse/context.go` and the first 180 lines of `core/decode/decode.go`.
- Read-only HEAD check confirmed `392b27efc5db66323afadb4b2d7a910c6fd8bbc9`.

Limits: no writes, builds, tests, checker execution, subagents, history, memory, or prior review/resolution reports were used. Source-map API parity was not comprehensively verified against production source. This review addresses readiness of offline data, evaluation, fitting, reporting, and compatibility-state tooling; it does not require the deferred product/native implementation.
