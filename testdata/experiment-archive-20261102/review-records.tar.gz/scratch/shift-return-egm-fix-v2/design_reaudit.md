# Focused EGM design re-audit

Reviewed snapshot: `392b27efc5db66323afadb4b2d7a910c6fd8bbc9`. Reviewer `/root/shift_v2_design_audit`, fresh context. Complete returned report follows.

No Blocker found. I found three Major issues and one Nit affecting reproducibility or interpretation of the proposed experiment. These are design findings; no evaluator execution or collected results are assumed.

1. **Major — G3 can declare context support despite substantial uncertainty.**
   Affected scope: `design/shift-return-protocol-v2.md:176–189`, especially G3 at line 185.

   Bootstrap intervals must be available, but G3 never requires them to exclude zero improvement. For example, among 100 independent contrast components, E0 could make 10 errors and EC seven, comprising five repairs and two worsenings. This meets the 30% relative reduction requirement and positive net improvement, although a paired interval can include no benefit. The remaining gates can still pass on the larger overall cohorts. Consequently, GO can be reached without convincing evidence that the measured context benefit exceeds sampling variation.

   Predeclare an uncertainty requirement for the primary contrast, such as a positive lower bound for paired error reduction, together with an adequate number of informative discordant components. Alternatively, explicitly describe G3 as an exploratory point-estimate screen and avoid treating passage as supported context effectiveness.

2. **Major — Bootstrap behavior is undefined when the resampled baseline has zero errors.**
   Affected scope: `design/shift-return-protocol-v2.md:170,176,178,182,185`; `design/shift-return-v2/schema.json:1324–1360`.

   The document defines the observed relative reduction when the baseline has zero errors, and defines invalid bootstrap replicates when a subgroup has zero members. It does not define a replicate with a nonempty subgroup but zero baseline errors. Relative error reduction is undefined in that replicate. The paired schema also supplies only one `bootstrap95` field without specifying whether it describes net repairs, error-rate difference, or relative reduction.

   For example, a 100-component contrast with only one observed E0 error will produce many resamples without that erroneous component. Implementations could discard those replicates, substitute zero, or calculate an interval for another statistic, producing materially different availability and G0 outcomes.

   Name each interval’s statistic and define zero-baseline handling per replicate, its contribution to `valid_bootstrap`, and its effect on G0/G3. Add a worked sparse-error example.

3. **Major — Component primaries and context/category qualification are not joined by an explicit selection rule.**
   Affected scope: `design/shift-return-protocol-v2.md:150–160,174,178,185`; `design/shift-return-v2/schema.json:818–867,1364–1405`.

   Each component receives one return primary, selected by source priority and ID. Components can nevertheless contain tasks from multiple categories and both context-contrast and ordinary return tasks. The contract does not explicitly say whether the 100 contrast components and category minimums must be represented by those selected primaries, or whether any member task qualifies the component.

   Consider two return tasks sharing a prefix or vendor family: A meets the contrast predicate; B does not and wins primary selection. Counting that component toward contrast qualification while scoring B would violate the intended cohort. Scoring A instead would create a second primary-selection procedure. The same ambiguity affects category qualification when a component’s selected primary belongs to another category.

   Require qualification and subgroup metrics to use the selected primary’s category and predicate, or define separate, deterministic cohort-specific primaries and their weighting. Include a mixed-category, mixed-context component example and make assignment/report validation enforce the chosen rule.

4. **Nit — The “complete hypothetical report” does not demonstrate the required paired-report shape.**
   Affected scope: `design/shift-return-worked-scoring.md:3`; `design/shift-return-protocol-v2.md:178`; `design/shift-return-v2/worked-report.json:371–383`.

   The worked report contains only E0-revise versus EC-revise on all-return. The contract requires four feature comparisons, four fixed-to-revise comparisons, and the primary context-contrast comparison. G3 being unavailable is appropriate for this toy cohort, but the example leaves the representation of required unavailable comparisons unspecified.

   Include the complete comparison set, with explicit unavailable context entries, or label this artifact a partial report example and provide a separate complete shape example.

The alternatives requirement is addressed: the document evaluates manual switching, fixed word rules, a linear probe, and literal fallback with specific reasons and limitations. It also appropriately separates boundary/readings, surface accuracy, materialization, and product readiness; acknowledges synthetic sampling; preserves collision cases; and does not claim that tools or quality results already exist.

Actual read inventory:

- Complete `agents/design_critic.md` and `resources/document_standards/feature-spec-standard.md` under the specified EGM vendor directory.
- Complete `design/shift-return-protocol-v2.md` and the linked `design/shift-return-source-map-v2.md`.
- Complete summaries: `shift-english-auto-return-experiment.md`, `shift-return-combination-order.md`, and `shift-return-worked-scoring.md`.
- Complete linked artifacts: `shift-return-v2/schema.json`, `examples.jsonl`, `numerical.json`, and `worked-report.json`.
- Complete `shift-return-v2/check_examples.py`, inspected without execution.

Limits: strictly read-only inspection; no edits, writes, builds, tests, subagents, production-source verification, collected-data inspection, or runtime parity verification. No conversation/memory or earlier review/resolution reports were consulted. The requested shorthand `source-map-v2.md` was resolved to the source map explicitly linked by the protocol.
