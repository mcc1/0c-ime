# Focused EGM source re-audit

Snapshot `392b27efc5db66323afadb4b2d7a910c6fd8bbc9`; reviewer `/root/shift_v2_source_audit`, fresh context. Complete returned report follows.

Readiness verdict: three Major exchange-contract gaps remain. I found no Blocker in the checked source API mappings or baseline score semantics.

1. Major — The independent reducer cannot reconstruct the required context-contrast results from its authorized inputs.

Affected references: `design/shift-return-protocol-v2.md:35`, `:158`, `:178`; `design/shift-return-v2/schema.json:816` (`component`), `:1006` (`row`).

The reducer is explicitly limited to frozen rows and assignment. Neither shape records a fixture’s `context_class` or membership in the predetermined context-contrast cohort. Assignment only retains component categories, which describe task categories and do not identify contrast membership. A component may contain multiple categories or variants, so those categories cannot substitute for per-primary cohort membership. The independent reducer therefore cannot reproduce the required EC/E0 contrast comparison, contrast component count, or G3 decision. Broader qualification inputs such as source completeness are likewise absent.

Recommendation: define the reducer’s complete inputs and invocation. Either add frozen per-primary cohort/category and qualification metadata to rows/assignment, or explicitly authorize a hashed fixture/qualification input. Specify how it joins those records and independently reconstructs G3 and qualification.

2. Major — Required safety evidence cannot represent “unknown,” despite the contract prohibiting invented zeros.

Affected references: `design/shift-return-protocol-v2.md:40`, `:178`, `:195`; `design/shift-return-v2/schema.json:1100`, `:1421`; `design/shift-return-v2/worked-report.json`, `safety`.

The protocol requires explicit unsupported/exhausted evidence and says unknown safety counts must not be filled with zero. Every row and report safety counter is nevertheless required and restricted to a nonnegative integer. There is no null, availability flag, or evidence status for those counters. An interrupted or unsupported run cannot serialize an honestly unknown count using the fixed schema. The worked report reinforces the problem by showing all safety counts as zero while explicitly saying no event replay occurred.

Recommendation: permit null counters with explicit availability/reason metadata, and define propagation from row to aggregate safety/G5. Update the no-replay worked report to demonstrate unavailable safety evidence.

3. Major — The replay candidate artifact has no defined association with its query occurrence.

Affected references: `design/shift-return-protocol-v2.md:44`, `:90`; `design/shift-return-v2/schema.json:478`, `:585`, `:1128`.

The fixed `candidates.jsonl.gz` contains Candidate objects, but Candidate has no fixture/episode ID, condition, event index, key offset, or raw prefix. Snapshots have occurrence metadata and a selected candidate ID, but candidate IDs hash only segment kind, offsets, and reading. Literal/pending segment text is deliberately excluded. Thus different same-length literal prefixes can produce the same hypothesis ID while having different English-prefix features and displayed text. Hypothesis IDs are consequently insufficient to join a shared replay candidate stream to snapshots.

Enumeration observations provide an appropriate occurrence envelope, but the protocol reserves that shape for the separate enumeration outputs. No ordering or indexing contract repairs the replay stream.

Recommendation: define a candidate-occurrence envelope containing episode/fixture ID, condition, event index, raw prefix and Candidate, and use it for replay artifacts. Keep the existing hypothesis identity as a query-local identity rather than treating it as globally unique evidence.

4. Nit — The custom vocabulary argument is described as a weight, but the existing API takes a timestamp.

Affected references: `design/shift-return-source-map-v2.md:23`; `core/vocab/vocab.go:366`.

`Set.Add(entries []Entry, source string, now int64)` receives a timestamp as its third argument. The source map calls the proposed zero value “weight0.” Passing zero is valid, so this does not change the planned call’s behavior.

Recommendation: replace “weight0” with `now=0` or “timestamp 0.”

Checked source conclusions:

- `SpellExact`, `NumberLike`, English ASCII case folding, `input.Exact`, B5’s prefix log score, W11’s complete log score, `Decoder.Left=""` as BOS, and the neutral-particle `personal.Model.Source()` view agree with the specified reuse.
- The checked Session constructor and baseline adapter support the documented factory settings and the need for a new application ledger.
- The pinned-baseline diff for the checked production files showed only the existing mixed-evaluation insert-observer hook in `core/session/mixed.go`; it did not reveal a conflicting baseline algorithm change.
- Proposed evaluator paths are explicitly labeled future Create work. Their absence is not a finding.

Actual read inventory and limits:

- Fully read the mandated persona and implementation-readiness standard.
- Fully read protocol v2, source map v2, all five example fixtures, numerical JSON, worked report, example-checker source, and the three requested explanatory summaries.
- Read schema definitions, including the candidate, snapshot, model, assignment/component, lock, row, report, sources, observation and derived shapes; retrieved the initially truncated assignment section separately.
- Read `core/mixedparse/context.go`, `guards.go`, `core/english/dictionary.go`, `core/input/input.go`, `core/lexicon/lexicon.go`, `internal/datadir/datadir.go`, `core/session/mixed_eval_adapter.go`, and `core/session/mixed_policy.go`.
- Inspected relevant portions of `core/session/session.go`, `mixed.go`, `core/decode/decode.go`, `core/personal/personal.go`, `core/proto/proto.go`, and `core/vocab/vocab.go`, including constructors, event handling, score helpers, decoding, source views and vocabulary signatures. Large combined decoder/personal output was truncated; findings rely on separately retrieved relevant sections.
- Confirmed checkout HEAD `392b27efc5db66323afadb4b2d7a910c6fd8bbc9`; compared the named production files against pinned baseline `e754019571573051d8c29e06526802c31d5172e2`.
- No writes, builds, tests, checker execution, subagents, history/memory reads, or prior review/resolution-report reads. Numerical and tiny-decoder claims were inspected analytically, not rerun.
