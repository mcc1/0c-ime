# Stage 7 — Design critic review

Reviewer: `/root/shift_egm_design_critic`, fresh context. Complete returned report follows.

Review outcome: changes requested. The design clearly separates offline recognition, output feasibility, and product integration, and it does not claim that experiments have already run. Two Major gaps remain against the feature specification standard. No Blocker identified.

Major — The chosen architecture lacks the required evaluation of viable alternatives.

Affected scope: packet lines 101–113 and 124–137; supporting definition at packet lines 242–260. Sources: `design/shift-return-protocol-v1.md` lines 17–29 and 46–64; `design/shift-return-combination-order.md` lines 7–20.

The document carefully compares feature masks and decision finalization within one conditional linear ranker. Those comparisons answer useful experimental questions, but they do not explain why this architecture is the appropriate first probe. The ranker is selected at protocol line 48 without comparing its complexity, interpretability, calibration requirements, or implementation cost with other viable approaches. C/A are behavior references, rather than documented architectural alternatives with selection or rejection rationale.

This misses the standard’s mandatory alternatives evaluation. A fresh engineer cannot tell whether a simpler deterministic word-evidence policy was considered, whether an explicit abstention/manual-return approach could meet the user goal at lower risk, or why a calibrated statistical ranker is preferable for this first experiment.

Recommendation: add a short alternatives table covering at least the existing manual behavior, a deterministic local evidence policy, and the proposed learned ranker. Explain which question each can answer, its expected costs and limitations, and why the ranker is selected for this experiment. This need not add more experimental arms.

Major — The independent sampling unit is not sufficiently defined to implement the literal-risk gate consistently.

Affected scope: packet lines 75 and 79; detailed definitions at packet lines 282–305. Sources: `design/shift-english-auto-return-experiment.md` lines 67 and 71; `design/shift-return-protocol-v1.md` lines 86–109.

The proposal requires at least 400 independent groups and a two-sided Wilson upper bound of at most 1%. The detailed protocol distinguishes groups from transitive family components: shared families are unioned into components, splitting and bootstrap resampling use components, but primary selection and quality denominators use groups. Protocol line 109 permits Wilson only for “pure independent” primary incidence denominators, without defining the mandatory action when several groups belong to one component.

That leaves two incompatible implementations available: count all groups for Wilson despite known family dependence, or decline to calculate Wilson and leave G4 undecidable. A component bootstrap for other comparisons does not resolve the Wilson gate. At this rare-error threshold, the distinction materially affects whether the experiment can pass.

Recommendation: define the relationship between group and component and freeze the independent unit for each G4 denominator. For example, use one prespecified primary per independent component for the Wilson qualification cohort, or explicitly define another valid component-level qualification procedure. State how correlated groups contribute to descriptive rates, minimum sample qualification, and the gate. Include a worked example containing multiple groups in one family component.

Nit — Resource limits bound retained hypotheses, but not the work required to produce and score them.

Affected scope: packet lines 44 and 79; detailed definitions at packet lines 233–240 and 250–268. Sources: `design/shift-english-auto-return-experiment.md` lines 36 and 71; `design/shift-return-protocol-v1.md` lines 37–44 and 54–72.

The 512-byte and 256-hypothesis limits are useful, but the generator enumerates feasible offsets and readings before canonical truncation, requires uncapped/capped diagnostics, and performs repeated full-path decoder scoring. Retained-state capacity therefore does not establish a bound on enumeration, decoder calls, evaluation time, or logged artifact size.

Recommendation: before tool freeze, document an estimated offline compute/storage budget and deterministic handling of enumeration or scoring exhaustion. Keep resource exhaustion visible as unavailable evidence or coverage failure; do not silently discard affected rows. Product latency thresholds can remain deferred to the expressly separate output stage.

Read inventory and verification limits:

- Read the complete assigned design-critic persona and feature-specification standard.
- Read the complete review packet: FeatureRange 1–222 and DetailedRange 223–326.
- Read all linked design supplements: the protocol, combination/order design, worked scoring example, and inherited `design/mixed-input-intent-experiment-v2.md`.
- Read `manifest.json`; verified that all four mapped source-file SHA-256 hashes match the manifest.
- Inspected relevant current source excerpts in `core/proto/proto.go` and `core/session/session.go`. They support the stated distinction between Shift toggling and ordinary English key passthrough.
- No files were changed, no compilation or tests were run, and no child agents were used.
- This is a design review. Historical baseline behavior, helper parity, candidate recall, training convergence, statistical outcomes, native output behavior, and latency remain unverified. The documents explicitly describe those as future work; hypothetical worked outputs are not experimental evidence.
