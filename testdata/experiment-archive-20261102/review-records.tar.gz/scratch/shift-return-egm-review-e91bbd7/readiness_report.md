# Stage 9 — Implementation-readiness review

Reviewer: `/root/shift_egm_readiness`, fresh context. Complete returned report follows.

The plan does not pass the implementation-readiness standard. It fixes substantial experimental policy, including the four models, eight replay conditions, main EC-revise condition, training budget, margins, and quality gates. However, implementing the offline evaluator still requires decisions about interfaces, event handling, feature adapters, labels, numerical conventions, data qualification, and verification.

This assessment concerns offline evaluator, data, fitting, and reporting readiness. The explicitly deferred output experiment, native Windows integration, latency thresholds, and installation package are not current implementation blockers.

1. **Blocker — Required implementation contracts are still future deliverables.**

   **References:** `design/shift-return-protocol-v1.md:64,125–129`; packet lines 260, 321–325.

   The plan requires a source map, schemas, examples, feature vectors, and concrete package/CLI names, but does not provide them. Naming `shiftreturneval` does not identify files to create or modify, exported interfaces, command arguments, artifact formats, validation failures, or exit behavior. A fresh engineer must design the evaluator’s boundaries and interchange contracts before implementing it.

   Supply an explicit file-change list and interface/schema definitions for fixtures, candidates, snapshots, model files, locks, replay results, and reports. Specify the commands and artifact dependencies for each phase. These can be small contracts, but they must precede implementation under the zero-decision rule.

2. **Blocker — The core B features and decoder adapters have not been mapped to executable behavior.**

   **References:** `design/shift-return-protocol-v1.md:54–64`; packet lines 250–260.

   “Original conservative/aggressive recommendation equivalent flag” does not define whether a feature means that a particular candidate is recommended, that any Chinese interpretation is recommended, or that a particular legacy branch fires. The required snapshot projection into the legacy helpers is also absent. The document explicitly says to stop if this projection cannot be established, so this is an acknowledged prerequisite, not completed readiness.

   The inspected source demonstrates why merely naming existing helpers is insufficient. At pinned preview2, `core/session/mixed.go:461–546` implements a stateful sequence of branches, and `mixedBoundary` at lines 598–658 selects between offsets using several thresholds. The current `core/mixedparse/guards.go:102–117` returns thirteen predicates; it does not directly provide the two proposed recommendation features.

   Likewise, specify the initial statistical score’s scorer, decoder options, prefix setting, missing-value handling, and log/probability conversion. The pinned legacy single-syllable helpers at `mixed.go:740–759` return exponentiated scores with `prefix=true`, while W explicitly uses complete decoding with `prefix=false`.

   Provide the promised source map and worked vectors, including competing offsets, first-tone space, prefix-only support, and missing scores. Define parity assertions against the pinned source.

3. **Major — The offline event and baseline replay contracts remain incomplete.**

   **References:** `design/shift-english-auto-return-experiment.md:30–32`; packet lines 38–40. `design/shift-return-protocol-v1.md:19–21,35–42,100,105`; packet lines 103–105, 231–238, 296, 301.

   The feature specification requires evaluator behavior for repeated Shift, focus/field changes, cursor movement, paste, and explicit selection. The detailed plan supplies eligibility and lock constraints, but no transition table defining how these events close, commit, cancel, preserve, or reset the virtual fragment. The normal-mode and protected-mode regression cases therefore cannot be implemented without choosing behavior.

   C/A replay is also ambiguous: replaying the same Shift prelude literally puts the legacy Session into English mode, whereas its mixed-input behavior requires a different mode setup. Specify exactly which events each baseline receives and which transformations are intentional.

   Define an offline application ledger for unhandled keys and commits. The inspected `core/session/session.go:526–530` returns unhandled English keys when no composition exists; treating Session snapshots alone as the entire visible output would lose those keys. The existing observer is not a complete solution: `core/session/mixed_eval_adapter.go:104–109` excludes spaces from its raw ledger and marks spaces and several punctuation keys unsupported.

   This finding requires a deterministic offline replay contract; it does not require implementing native focus or paste integration now.

4. **Major — Pending candidates lack a complete selection and display contract.**

   **References:** `design/shift-return-protocol-v1.md:37–41,54–60,74`; packet lines 233–237, 250–256, 270. `design/shift-return-combination-order.md:30–35`; packet lines 147–152.

   Prefix-only candidates must survive, but must not count as completed characters. Pending tails must remain recoverable. The plan does not specify the exact virtual display when such a candidate wins, which portions receive Chinese ownership, or whether a candidate without complete word coverage is eligible to replace literal display.

   W’s treatment of incomplete paths also needs a full feature vector: specify whether an already completed Chinese prefix supplies its word coverage and mean score while a later syllable is pending, and define every W value for the literal branch.

   These choices affect the O-fixed projection, “already displayed bytes,” first-success time, and transient-error duration. Add worked transitions showing partial first syllable, prefix-only first reading, completed word plus incomplete next syllable, and uninterpretable trailing raw bytes. State the exact candidate identity, features, display, ownership, and O-fixed compatibility result at each event.

5. **Major — The fitting instructions still admit materially different numerical implementations.**

   **References:** `design/shift-return-protocol-v1.md:68–76`; packet lines 264–272.

   Pairwise logistic loss and hierarchical equal weighting are specified, but the exact equation and normalization are not. Define whether L2 contributes `λ‖w‖²` or `λ‖w‖²/2`, which coefficients it covers, and how hierarchy weights behave when checkpoints have no valid pairs.

   Standardization also needs an exact observation population: identify the checkpoints included, whether repeated candidates count once per observation, whether missing score placeholders enter mean/std, and whether std uses a population or sample denominator.

   Gold projection needs rules for a prefix that has entered the intended Chinese span but has not completed its first syllable, and for fixtures with multiple acceptable readings. “Gold versus every negative” does not determine how multiple acceptable candidates participate in the loss.

   Supply a small numerical worked example with projected labels, observation counts, normalization statistics, pair weights, objective, gradient, and first update. Fixed learning rate and iteration count alone do not make the model reproducible.

6. **Major — Data acquisition and qualification need operational definitions.**

   **References:** `design/shift-return-protocol-v1.md:82–92`; packet lines 278–288. `design/shift-english-auto-return-experiment.md:47`; packet line 55.

   Source eligibility and acquisition budgets are fixed, but the acquisition and annotation procedure remains open. The engineer must choose source collections or manual task procedures, adjudication rules, the “main coverage” taxonomy, and allocation across the stated length strata.

   The context-contrast cohort is especially consequential: “desired spans and prefix collision structure” does not provide a deterministic predicate establishing when a continuation supplies distinguishing information. Different annotators could construct different hundred-group qualifying cohorts without violating the prose.

   Specify these procedures and classification rules before collection. Define stable IDs and the exact `sorted_component_ids` input to the split hash; relate family, group, equivalence group, and component explicitly. Include annotation examples for typo recovery, opposite-intent collisions, immediate termination, and intentional incomplete tails. The actual new dataset can remain a later execution artifact.

7. **Major — Reporting and uncertainty calculations need a complete executable contract.**

   **References:** `design/shift-return-protocol-v1.md:76,96–111`; packet lines 272, 292–307. `design/shift-return-combination-order.md:18,50`; packet lines 135, 167.

   Dev selection uses a single “literal-final” rate even though the final gates deliberately separate literal-only errors from return-English-span errors. State whether dev eligibility requires both rates independently and how the subsequent sorting compares them.

   Bootstrap seed and iteration count are fixed, but the random generator, interval construction, and treatment of replicates with empty subgroup denominators are not. Also clarify whether a component may contain multiple scoring groups. If it can, explain how the claimed independent-group qualification and Wilson denominator are established.

   Define report fields and formulas for paired repaired/worsened groups, interaction effects, revision gain, first correctness, final stability, and transient-error durations. The worked scoring supplement verifies several final outcomes, but does not determine these calculations or provide a full expected gate report.

8. **Major — The verification phase lacks the specific test plan required by the standard.**

   **References:** `design/shift-return-protocol-v1.md:44,100–105,125–127`; packet lines 240, 296–301, 321–323.

   The plan says to add tests and verify tools before freezing, but does not identify test files, commands, fixtures, expected assertions, or phase completion criteria. Quality gates describe experimental acceptance; they do not establish that the evaluator implements the contract correctly.

   Add concrete verification cases for first-tone spaces; prefix-only survival into a complete word; pending tails; B snapshots unaffected by later evidence; future-key/gold exclusion; deterministic capping and overflow; O-fixed compatibility and fallback; literal and Chinese score ties; multiple acceptable labels; split/grouping determinism; weighting and gradients; and independently recomputed reporting. Define baseline parity, disposable-store invariance, protected-mode zero calls, and Enter-equals-last-display assertions. Map these checks to stable implementation checkpoints.

No Nit findings are necessary. The listed gaps affect executable behavior or the validity of the experiment.

Actual read inventory:

- Complete implementation-readiness persona and standard at the two paths supplied in the task.
- Packet manifest and target packet, with complete authoritative source reads covering the packet’s feature and detailed sections.
- Complete `design/shift-english-auto-return-experiment.md`, `design/shift-return-protocol-v1.md`, `design/shift-return-combination-order.md`, and `design/shift-return-worked-scoring.md`.
- Complete linked `design/mixed-input-intent-experiment-v2.md`.
- Complete current `core/session/mixed_eval_adapter.go`, and `core/mixedparse/types.go`, `generator.go`, `guards.go`, and `context.go`.
- Current `core/proto/proto.go:1–155`; relevant `core/session/session.go` sections around request dispatch, mode changes, and English key handling; `core/decode/decode.go:83–159`.
- Pinned preview2 `core/session/mixed.go` excerpts containing `finishMixedTone`, `mixedBoundary`, `englishThenNumber`, and associated scoring and boundary helpers.
- Repository filename and symbol searches to locate these implementation references.

Limits: This was a read-only document-readiness review with targeted source inspection. No files were changed; no tests, compiles, experiments, or subagents were run. No prior reports, conversation history, or memory were read. Source inspection did not establish complete baseline parity or validate the proposed adapters. No required persona, standard, target section, or linked design supplement was left unread.
