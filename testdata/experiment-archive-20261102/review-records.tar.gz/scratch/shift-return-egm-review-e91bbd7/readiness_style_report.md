# Stage 9 — Detailed style review

Reviewer: `/root/shift_egm_readiness_style`, fresh context. Complete returned report follows.

No Blocker findings. One Major precision issue and three Nits.

1. **Major — Ambiguous scope of dataset strata.** Packet lines 280 and 286; `design/shift-return-protocol-v1.md:84,90`.

   “每組含單字、2–4音節短詞、5–16音節段落、17–64音節長段” does not identify whether “每組” means each dependency group, each intent cohort, or each coverage category. It follows both return and literal categories, although Chinese syllable counts do not directly describe ordinary literal-only tasks. “每個主coverage類至少20 groups” then imposes a qualification threshold without explicitly identifying the applicable category list. State which cohort receives the syllable strata, whether each dependency group must contain every stratum, and which named categories require 20 groups. These distinctions affect what qualifies as sufficient data.

2. **Nit — “Canonical” terminology lacks a precise referent.** Packet lines 236, 264, 268 and 270; `design/shift-return-protocol-v1.md:40,68,72,74`.

   The document alternates between “canonical reading UTF8,” “canonical identity,” and “canonical排序” when specifying truncation, negative enumeration and tie breaking. It does not explicitly say whether these share an ordering or identify the fields comprising canonical identity. Define the identity and ordering once, then reference that definition consistently. This is especially useful because these phrases specify deterministic behavior rather than incidental implementation details.

3. **Nit — G5 uses an ambiguous compressed phrase.** Packet line 301; `design/shift-return-protocol-v1.md:105`.

   “假設學習／持久化0” can read as “assume learning/persistence is zero,” rather than as a prohibition on side effects while evaluating candidate hypotheses. Line 238 helps establish the intended restriction, but the gate should stand alone. Name the prohibited operations and their counting scope explicitly, such as learning updates and persistent writes during candidate evaluation, if that is the intended requirement.

4. **Nit — Replace conversational metaphors with direct technical requirements.** Packet lines 254, 256, 264, 270 and 315; `design/shift-return-protocol-v1.md:58,60,68,74,119`.

   Phrases such as “不交給模型投票,” “E0會偷看到後文,” “不抽容易negatives,” “黏住前次答案,” and “feature actually consumed” make otherwise precise requirements less uniform. Prefer direct statements: enforce hard constraints before scoring; freeze B before subsequent context arrives; enumerate all negative candidates; apply no hysteresis margin; verify that feature values enter candidate scoring. These edits preserve the requirements while making them easier to audit.

Actual read inventory: the complete supplied `agents/style.md`; `review_target.md` lines 1–326, with findings restricted to DetailedRange 223–326; the adjacent `manifest.json`; the complete `design/shift-return-combination-order.md`; and the complete linked `design/mixed-input-intent-experiment-v2.md` lines 1–114. The feature specification, protocol introduction and worked-scoring supplement were read in the packet for definitions and context.

Limits: no additional style standard was supplied. This was a read-only document style and precision review. I did not read prior review reports, inspect implementation source, modify files, compile, run tests, or verify experimental claims. The document explicitly describes a proposed experiment and hypothetical scoring examples; this review does not imply that implementation, training or evaluation occurred.
