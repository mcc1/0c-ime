# Stage 7 — Combined critic report

Four Major findings and five Nits were returned across the three independent reviews. No Blocker. Reports below preserve each reviewer's complete findings; no design edits were made.


---

# Stage 7 — Design critic review

Reviewer: `/root/shift_egm_design_critic`, fresh context. Complete returned report follows.

Review outcome: changes requested. The design clearly separates offline recognition, output feasibility, and product integration, and it does not claim that experiments have already run. Two Major gaps remain against the feature specification standard. No Blocker identified.

Major — The chosen architecture lacks the required evaluation of viable alternatives.

Affected scope: packet lines 101–113 and 124–137; supporting definition at packet lines 242–260. Sources: `design/shift-return-protocol-v1.md` lines 17–29 and 46–64; `design/shift-return-combination-order.md` lines 7–20.

The document carefully compares feature masks and decision finalization within one conditional linear ranker. Those comparisons answer useful experimental questions, but they do not explain why this architecture is the appropriate first probe. The ranker is selected at protocol line 48 without comparing its complexity, interpretability, calibration requirements, or implementation cost with other viable approaches. C/A are behavior references, rather than documented architectural alternatives with selection or rejection rationale.

This misses the standard’s mandatory alternatives evaluation. A fresh engineer cannot tell whether a simpler deterministic word-evidence policy was considered, whether an explicit abstention/manual-return approach could meet the user goal at lower risk, or why a calibrated statistical ranker is preferable for this first experiment.

Recommendation: add a short alternatives table covering at least the existing manual behavior, a deterministic local evidence policy, and the proposed learned ranker. Explain which question each can answer, its expected costs and limitations, and why the ranker is selected for this experiment. This need not add more experimental arms.

Major — The independent sampling unit is not sufficiently defined to implement the literal-risk gate consistently.

Affected scope: packet lines 75 and 79; detailed definitions at packet lines 282–305. Sources: `design/shift-english-auto-return-experiment.md` lines 67 and 71; `design/shift-return-protocol-v1.md` lines 86–109.

The proposal requires at least 400 independent groups and a two-sided Wilson upper bound of at most 1%. The detailed protocol distinguishes groups from transitive family components: shared families are unioned into components, splitting and bootstrap resampling use components, but primary selection and quality denominators use groups. Protocol line 109 permits Wilson only for “pure independent” primary incidence denominators, without defining the mandatory action when several groups belong to one component.

That leaves two incompatible implementations available: count all groups for Wilson despite known family dependence, or decline to calculate Wilson and leave G4 undecidable. A component bootstrap for other comparisons does not resolve the Wilson gate. At this rare-error threshold, the distinction materially affects whether the experiment can pass.

Recommendation: define the relationship between group and component and freeze the independent unit for each G4 denominator. For example, use one prespecified primary per independent component for the Wilson qualification cohort, or explicitly define another valid component-level qualification procedure. State how correlated groups contribute to descriptive rates, minimum sample qualification, and the gate. Include a worked example containing multiple groups in one family component.

Nit — Resource limits bound retained hypotheses, but not the work required to produce and score them.

Affected scope: packet lines 44 and 79; detailed definitions at packet lines 233–240 and 250–268. Sources: `design/shift-english-auto-return-experiment.md` lines 36 and 71; `design/shift-return-protocol-v1.md` lines 37–44 and 54–72.

The 512-byte and 256-hypothesis limits are useful, but the generator enumerates feasible offsets and readings before canonical truncation, requires uncapped/capped diagnostics, and performs repeated full-path decoder scoring. Retained-state capacity therefore does not establish a bound on enumeration, decoder calls, evaluation time, or logged artifact size.

Recommendation: before tool freeze, document an estimated offline compute/storage budget and deterministic handling of enumeration or scoring exhaustion. Keep resource exhaustion visible as unavailable evidence or coverage failure; do not silently discard affected rows. Product latency thresholds can remain deferred to the expressly separate output stage.

Read inventory and verification limits:

- Read the complete assigned design-critic persona and feature-specification standard.
- Read the complete review packet: FeatureRange 1–222 and DetailedRange 223–326.
- Read all linked design supplements: the protocol, combination/order design, worked scoring example, and inherited `design/mixed-input-intent-experiment-v2.md`.
- Read `manifest.json`; verified that all four mapped source-file SHA-256 hashes match the manifest.
- Inspected relevant current source excerpts in `core/proto/proto.go` and `core/session/session.go`. They support the stated distinction between Shift toggling and ordinary English key passthrough.
- No files were changed, no compilation or tests were run, and no child agents were used.
- This is a design review. Historical baseline behavior, helper parity, candidate recall, training convergence, statistical outcomes, native output behavior, and latency remain unverified. The documents explicitly describe those as future work; hypothetical worked outputs are not experimental evidence.

---

# Stage 7 — Structural review

Reviewer: `/root/shift_egm_structural`, fresh context. Complete returned report follows.

No Blocker, Major, or Nit structural findings.

The actual feature-spec standard does not prescribe exact section titles, a fixed section order, a mandatory standalone “Alternatives Considered” heading, or special Markdown link syntax. Its named areas are non-exhaustive content requirements. Missing those literal English headings is therefore not a structural defect.

The authored structure is coherent:
- Goal document: problem and motivation, S1/S2 scope, existing mode behavior, input intentions, controls, metrics, risks and integration limits.
- Protocol: numbered sections 1–9, with sections 1–2 included in FeatureRange and sections 3–9 available in DetailedRange.
- Combination supplement: four numbered sections covering information combinations, decision timing, the experiment matrix and interpretation.
- Worked example: task table, sequential checkpoints and scoring explanations.

Authored documents use H1 titles, H2 main sections and the goal document’s H3 subsection without skipped levels. Tables, lists, inline code and Markdown links appear well formed. All linked design documents were available.

Assembly observations, not authored findings:
- Packet lines 7–9, 83–85, 116–118 and 184–186 put each “Source” label and the associated document title at the same heading level. This is packet presentation; it does not establish an authored hierarchy violation.
- The protocol is split at packet lines 114/227, making its later numbered sections appear under “Detailed Implementation Plan.” The manifest explicitly maps that split. The source protocol remains continuous.
- Absolute links are the packet’s documented expansion of valid relative source links.

Content coverage relevant to the standard is discoverable despite being distributed. Alternatives and their trade-offs appear as controls and the 4×2 comparison matrix at packet lines 99–113 and 122–180. Risks and limitations appear at lines 36–44, 71–81 and throughout the referenced detailed protocol. Whether the prospective comparison sufficiently justifies the chosen research method is a substantive design assessment, not a missing-header finding.

Read inventory:
- Complete structural persona and feature-spec standard at the paths supplied by the parent.
- Review packet, FeatureRange lines 1–222 and DetailedRange lines 223–326.
- Adjacent manifest.
- All four authoritative source documents: `design/shift-english-auto-return-experiment.md`, `design/shift-return-protocol-v1.md`, `design/shift-return-combination-order.md`, and `design/shift-return-worked-scoring.md`.
- Complete linked `design/mixed-input-intent-experiment-v2.md`, including the inherited intent, collision and data-isolation requirements.

Limits: read-only document and structural review. No prior reports, history or memory consulted. No source-code behavior verification, writes, tests, compilation or subagents.

---

# Stage 7 — Feature style review

Reviewer: `/root/shift_egm_feature_style`, fresh context. Complete returned report follows.

Style and clarity review — Feature Specification, packet lines 1–222

Two Major clarity issues and four Nits. No Blocker findings. The document generally distinguishes proposed experiments, hypothetical examples, and observed results clearly; none of the findings below assumes an experimental outcome.

1. **Major — The main comparison has conflicting descriptions of parameter equality.**

   References: packet line 65, `design/shift-english-auto-return-experiment.md:57`; packet lines 111–113, `design/shift-return-protocol-v1.md:27–29`.

   Line 65 requires the comparison to use the same strategy, candidate generation, dictionary, **parameters**, and raw keys. Lines 111–113 instead distinguish separately fitted feature models from a supplementary probe that holds EC coefficients fixed. A fresh reader cannot tell whether “same parameters” governs the main effectiveness comparison or only the probe.

   Clarify the two comparisons explicitly: the main feature comparison shares the fitting procedure and budget but permits separately fitted coefficients; the fixed-coefficient probe measures the frozen EC model’s sensitivity to context. Update the earlier summary to use those same terms.

2. **Major — “Success” alternates between correct characters and correct boundary/readings.**

   References: packet lines 23 and 73, `design/shift-english-auto-return-experiment.md:15,65`; packet line 218, `design/shift-return-worked-scoring.md:33`. Definition checked against packet lines 298 and 303, `design/shift-return-protocol-v1.md:102,107`.

   Line 23 defines success as correctly composing the first Chinese character, and line 73 includes composing the first character within the 90% target. The worked example allows a wrong homophone surface to succeed on intent/readings, while the detailed definition says G2 evaluates intent/readings only. These passages leave “correct first character” open to two interpretations: the intended written character or a materialized character with the intended reading.

   State consistently that the 90% gate measures boundary and complete readings, identify the required materialization behavior separately, and give surface accuracy its own named metric. This preserves the existing distinctions without making the headline success claim broader than its denominator.

3. **Nit — The revision history depends on missing conversational context.**

   References: packet line 13, `design/shift-english-auto-return-experiment.md:5`; packet line 120, `design/shift-return-combination-order.md:3`.

   “使用者指出” explains a requirement through an unavailable conversation, while “此處『三種』依前文解讀” refers to wording whose antecedent is unclear in the packet. The latter also places three information groups beside the protocol’s three model conditions, inviting confusion about what was expanded.

   State the current requirement directly. In the supplement, say that the earlier conditions were E0, EL, and EC, and that adding EW completes the B-always-present, L-by-W factorial comparison.

4. **Nit — The E0 summary can be mistaken for decision freezing.**

   References: packet lines 65 and 106, `design/shift-english-auto-return-experiment.md:57` and `design/shift-return-protocol-v1.md:22`; packet lines 147–150, `design/shift-return-combination-order.md:30–33`. Definition checked against packet line 256, `design/shift-return-protocol-v1.md:60`.

   “之後不利用後文重估該切法” and “不使用後文詞證據重評它” can suggest that E0 fixes the initial boundary decision. The supplement separately defines O-fixed, and the detailed definition says E0 under O-revise does not freeze the raw keys. The feature section should make this distinction visible before introducing the process matrix.

   Describe E0 as freezing the candidate’s initial information features while leaving decision revision governed by O-fixed or O-revise. Avoid wording that makes information freezing sound like ownership freezing.

5. **Nit — Mixed terminology increases the cost of following the comparisons.**

   References: packet lines 55, 65–79, 111–113, and 135–158.

   The prose switches repeatedly between Chinese terms and English fragments such as “paired groups,” “context,” “final error,” “features,” “replay conditions,” and “ownership／reading.” Some English identifiers are useful, especially E0, EC, and O-revise, but several ordinary concepts receive multiple renderings without an introductory mapping.

   Add a compact terminology note and use one rendering consistently for repeated concepts—for example, 後文資訊（context）, 配對群組（paired groups）, and 最終錯誤率（final error rate）. Keep exact model and API identifiers unchanged.

6. **Nit — Some prohibitions use accusatory language where a validity condition would be more precise.**

   References: packet lines 67, 95, 150, and 152, respectively `design/shift-english-auto-return-experiment.md:59`, `design/shift-return-protocol-v1.md:11`, and `design/shift-return-combination-order.md:33,35`.

   “不能冒稱,” “不假裝,” and “不能……冒充” imply misrepresentation rather than explaining the evidentiary limit. The surrounding technical requirements already provide a factual basis for direct wording.

   Replace these with statements such as “此結果不足以證明跨 literal／讀音比較,” “本輪不涵蓋多次自動切換,” and “generator recall 須以封存篩選前的候選集合計算.” The constraints remain equally strict and become easier to apply objectively.

Read inventory and limits:

- Read the complete assigned Style Goldfish persona.
- Read the manifest and all packet lines 1–326. Findings target Feature Specification lines 1–222; Detailed Implementation Plan lines 223–326 were used for definitions and clarification.
- Read the complete explicitly linked `design/mixed-input-intent-experiment-v2.md` to check inherited terminology and requirements.
- The four authored source documents were read through their manifest-mapped packet excerpts; the complete protocol is included across the two packet sections.
- No additional style standard was provided. No conversation history, previous review reports, source code, experiment outputs, tests, or builds were used. No files were changed.
