# EGM review: Shift-return experiment design

**Decision: changes required. The proposal is not ready for evaluator implementation or quality measurement.** The full five-stage review completed with nine fresh-context reviewers. The initial scope and comparison structure are defensible; the experiment's operational contracts and several claims remain incomplete or inconsistent.

This is a design/readiness judgment, not a negative experiment result. No new data were collected, no model was fitted, and no experiment was run. The review does not reject the hypothesis that later context can improve mixed-input boundaries.

## Reviewed version and method

- Source commit: `e91bbd7bddf473fa205aba5c2fa700b6ae710678`.
- Authoritative sources: `design/shift-english-auto-return-experiment.md`, `design/shift-return-protocol-v1.md`, `design/shift-return-combination-order.md`, and `design/shift-return-worked-scoring.md`.
- [Manifest](manifest.json) records original hashes and source-to-packet line mappings. [Review packet](review_target.md) assembles the sources without changing their claims; relative links were expanded to absolute paths.
- Feature range: packet lines 1–222. Detailed range: 223–326.
- Workflow: [EGM review skill](/workspace/.0c-tools/review-skills/vendor/elephant-goldfish-model-403d8881d62022490637d740657b33f01e321ea8/skills/egm-review/SKILL.md), pinned bundle `403d8881d62022490637d740657b33f01e321ea8`; user-selected uninterrupted full flow.
- Every reviewer was dispatched with `fork_turns: none`, read its persona and required standard, and reported its actual read inventory and limits. Only stage 8 received previous stage reports, as required by the workflow. No reviewer retrieved conversation history or memory; incidental historical search matches were explicitly excluded where encountered.
- No source documents were changed during the review. No resolution pass or re-audit was performed.

## Stage results

| Stage | Reviewers | Result |
| --- | --- | --- |
| 5 Initial zoom-out | 1 | No findings; scope and reuse boundaries supported |
| 6 Comprehension | 1 | Intended behavior understood; one navigation Nit |
| 7 Critic | 3 | Four Major findings, five Nits; structural reviewer found no structural defects |
| 8 Intermediate zoom-out | 1 | One Major and one Nit, both repeating stage-7 concerns; confirms no edits resolved them |
| 9 Readiness | 3 | Two Blockers, ten Majors, four Nits before deduplication |

After deduplication: **two Blocker action items, nine Major action items, two Nit cleanup items.** Severity follows the strongest supported finding for the same underlying gap. Repeated findings are not independent votes or additional defects. Full reviewer reports remain available below.

## Required actions, in priority order

| ID | Severity | Required change | Completion evidence |
| --- | --- | --- | --- |
| A1 | Blocker | Define evaluator files, interfaces, fixture/event/model/report schemas, CLI, artifact dependencies and incremental verification checkpoints. These are presently deferred to future artifacts. | One Create/Modify/Delete inventory; executable contract; concrete assertions and phase commands, including independent report recomputation |
| A2 | Blocker | Define B's conservative/aggressive recommendation features and initial score adapters. A set of guard predicates is not the complete original ordered decision. Legacy prefix-supported exponentiated score is not automatically the proposed exact log score. | Source map with inputs, branch semantics, scorer/options, missing-value rules and worked feature vectors; pinned-source parity cases |
| A3 | Major | Specify Shift eligibility, lifecycle events, space handling, baseline event transformations and application output for unhandled keys. Existing infrastructure does not supply these contracts. | Event transition table and replay cases for actual Toggle, spaces, pre-existing composition, repeated toggles, locks, protected states and unhandled English output |
| A4 | Major | Define selection, ownership, features and display for prefix-only candidates, incomplete syllables and unmatched tails. These affect both scoring and the fixed/revise comparison. | Complete worked state transitions with exact raw spans, feature vectors, virtual display, identity and O-fixed compatibility/fallback |
| A5 | Major | Fix the numerical fitting contract, including the exact objective, hierarchy weights, regularization, standardization population and multiple acceptable gold candidates. | Small numerical example through objective, gradient and first update; reproducible zero-pair and missing-score cases |
| A6 | Major | Make acquisition, annotation, coverage taxonomy, length strata, context-contrast membership and stable split identifiers operational. | Pre-collection source/task procedure and adjudication rules; category allocation table; deterministic labels and grouping examples |
| A7 | Major | Establish the independent sampling unit used by each 1% Wilson gate. The current group/component distinction can produce dependent denominators. | Explicit group-to-component relationship, prespecified independent qualification cohort or component-level procedure, minimum counts and a correlated-group example |
| A8 | Major | Define both dev literal-risk rates and the full reporting/uncertainty contract, including paired outcomes, bootstrap generator/intervals, empty replicates and interaction effects. | Machine-readable report schema, exact formulas, complete expected report and independent check |
| A9 | Major | Justify choosing a learned ranker before adding its machinery. Feature-mask ablations are not an evaluation of architectural alternatives. | Short comparison of manual behavior, deterministic local word-evidence policy and learned selector, with costs/limits and reasons for selection; no extra experiment arms are inherently required |
| A10 | Major | Resolve whether main comparisons share coefficients or only fitting procedure/budget. The overview and detailed specification currently differ. | Main separately fitted comparisons and frozen-coefficient sensitivity probe named consistently in all documents |
| A11 | Major | Resolve whether headline “correct first character” means intended written character or correct boundary/readings. The 90% gate currently measures the latter. | Consistent named boundary/reading, surface and materialization metrics; no broader success claim than the measured denominator |
| A12 | Nit | Bound offline enumeration/scoring/logging work, not only retained bytes/hypotheses. | Estimated compute/storage budget and deterministic exhaustion treatment without dropping tasks |
| A13 | Nit | Improve navigation and terminology: link old evaluator/reusable APIs, define canonical identity, distinguish frozen information from frozen ownership, and use direct side-effect requirements. | Small editorial/source-reference pass; retain exact technical constraints |

### Why these findings matter for the core question

The design should reveal whether later word evidence helps infer intent, rather than how well one newly introduced classifier happens to perform. A9 requires a reasoned choice of probe. A2 and A5 prevent different implementations from silently testing different probes. A3 and A4 ensure that later context can actually revisit the same original keys. A7 prevents correlated account variants from producing an unsupported rare-error claim. A10 and A11 ensure the comparison and success claims match the actual computation.

The four combinations and two decision-finalization policies remain useful controls. Reviewers did not find that eight replay conditions imply eight separately searched models. The design correctly separates context information from the opportunity to revise, and offline detection from native output feasibility. Those strengths do not close the action items above.

## Traceability matrix

Raw labels below refer to finding numbers in the complete linked reports. “Intermediate Major/Nit” are the two unnumbered findings in the stage-8 report.

| Raw finding | Consolidated action |
| --- | --- |
| [Readiness](readiness_report.md) 1 | A1 |
| Readiness 2 | A2 |
| Readiness 3 | A3 |
| Readiness 4 | A4 |
| Readiness 5 | A5 |
| Readiness 6 | A6 |
| Readiness 7 | A7, A8 |
| Readiness 8 | A1 verification portion |
| [Codebase](codebase_details_report.md) 1 | A1 |
| Codebase 2 | A2 |
| Codebase 3 | A3 |
| Codebase 4 | A13 |
| [Design critic](design_critic_report.md) alternatives Major | A9 |
| Design critic independent-unit Major | A7 |
| Design critic resource Nit | A12 |
| [Feature style](feature_style_report.md) 1 | A10 |
| Feature style 2 | A11 |
| Feature style 3–6 | A13 |
| [Detailed style](readiness_style_report.md) 1 | A6 |
| Detailed style 2–4 | A13 |
| [Comprehension](comprehension_report.md) navigation Nit | A13 |
| [Intermediate zoom-out](intermediate_zoom_out_report.md) Major | A9 |
| Intermediate zoom-out Nit | A12 |

The [initial zoom-out](zoom_out_report.md) and [structural](structural_report.md) reviews returned no findings. Their absence from the finding matrix does not mean they were omitted.

## Parent adjudication and limits

The parent accepts the operational gaps as reasons not to start the quality experiment yet. It independently checked the relevant existing adapter/source snippets: spaces are excluded or marked unsupported in the old ledger; old request mapping lacks the required Shift contract; and `mixedSyllableScore` uses prefix-supported decoding then exponentiates. It also checked that the authored source hashes remained unchanged. These checks support A2/A3 but are not parity tests.

The two Blockers concern readiness under EGM's zero-decision implementation standard, not evidence of a production defect or impossibility of the core idea. The remaining work should complete the smallest offline experimental contract. It need not expand into Windows integration, add more trained models, or change the agreed quality thresholds. The method-alternatives decision should be resolved before investing in four learned models.

Recommended repair order: A9 first; then A10/A11 and A6/A7 to settle what is being tested and counted; then A1–A5/A8 with worked transitions and numerical examples; finally the small A12/A13 cleanup. Review the repaired affected sections before freezing the tool/data. Do not begin fitting or judge the core hypothesis using the current incomplete contract.

No data collection, training, replay, tests, native output validation, code edits or automatic remediation were performed in this review. Complete raw reports, source mappings and artifact hashes are retained in this directory.
