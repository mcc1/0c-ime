# Stage 8 — Intermediate zoom-out review

Reviewer: `/root/shift_egm_intermediate_zoom`, fresh context with the three specified earlier stage reports. Complete returned report follows.

Intermediate zoom-out review: one Major and one Nit. No Blocker. The experiment remains appropriately scoped, but the choice of a learned selector needs a brief justification before committing to its implementation.

Major — The learned selector is selected before its added complexity is justified.

Affected scope: packet lines 101–113 and 242–274; `design/shift-return-protocol-v1.md:17–29,46–88`.

The design specifies a conditional linear ranker, training labels, normalization, four fitted models, and dev-selected margins. The information and freezing comparisons explain how to study that ranker, but they do not explain why it is the simplest suitable first probe. Existing conservative/aggressive behavior is presented as a behavioral reference, without assessing whether a deterministic policy using the same exact-word and decoder evidence would answer enough of the question.

This is an architectural justification gap, rather than evidence that learning is necessarily unnecessary. A learned comparison between literal and Chinese interpretations may be useful, particularly because Chinese decoder scores are not already calibrated against literal interpretations. The document should state that reasoning and compare the implementation and calibration costs with a simpler local evidence policy.

Add a short alternatives discussion covering the current manual behavior, a deterministic local evidence policy, and the proposed learned selector. Explain why the selected probe earns its extra machinery. This does not require additional experimental arms or a claim that deterministic rules can resolve indistinguishable intentions.

This agrees with the stage-7 design critic’s alternatives finding. No intervening edits have addressed it.

Nit — The retained-state limits leave the cost of the offline probe unspecified.

Affected scope: packet lines 233–240, 250–252, 264–268, and 321; `design/shift-return-protocol-v1.md:37–44,54–56,68–72,125`.

The 512-byte and 256-hypothesis limits constrain retained state. They do not specify how much work may occur before truncation, how uncapped diagnostics are obtained, or the cost of repeated complete-path decoding and eight streams of checkpoint artifacts. These costs matter when deciding whether the proposed first experiment remains proportionate.

Before freezing the tool, record an estimated compute/storage budget and deterministic treatment of enumeration or scoring exhaustion. Preserve exhausted tasks as coverage failures or unavailable evidence, consistent with the existing overflow policy. Product latency requirements can remain in the separate output stage.

This is the same boundedness concern raised by the stage-7 design critic; the existing capacity limit has not resolved it.

The rest of the architecture is restrained.

Packet lines 19–44 and 93–95 limit the work to an eligible Shift-started fragment and preserve the normal Chinese decoder. Lines 81 and 311–317 explicitly separate recognition evidence from output ownership, native integration, and installation packages. Those distinctions address the actual first-character problem without pretending that a shadow detector can recover keys already delivered to the application.

The four feature combinations and two freezing policies have concrete purposes at lines 124–180. They separate word evidence, length evidence, and the opportunity to revise. They share four fitted models and retain EC-revise as the designated primary method. I do not find speculative product scope or an unjustified eight-model search here. The numerical and algorithmic detail at lines 227–325 is appropriately placed in the Detailed Implementation Plan.

Code searches support reuse rather than wholesale replacement:

- `core/mixedparse/context.go:10` provides `SpellExact`.
- `core/mixedparse/guards.go:15,102` provides `NumberLike` and the guard projection.
- `core/session/mixed_eval_adapter_test.go:59` contains existing guard-projection parity coverage.
- `core/decode/decode.go:229` provides `Decoder.Best`, including its path and score interface.
- `core/mixedparse/generator.go:54` already contains exact-word coverage and prefix-support traversal. Its traversal is a useful starting point, although the proposed maximum multi-syllable coverage ratio has a different objective.
- `internal/mixedeval/replay.go:28` implements the Wilson calculation.
- `internal/mixedeval/fit.py` supplies an existing pairwise logistic fitting pattern. Its eligibility exclusions, feature schema, weighting, training budget, and selection procedure differ from this protocol, so direct adoption would violate the new contract.

The old generator is unsuitable unchanged: `core/mixedparse/generator.go:27–50,89–108` limits parsing to two syllables, 64 bytes, and explicit-tone checkpoints, excluding spaces. `core/mixedparse/state.go:151–180` also demonstrates the old window lifecycle and restrictions. A separately versioned experiment can therefore be justified while reusing suitable primitives. “Independent version” at packet line 321 should not be interpreted as a requirement to copy every existing utility.

The other stage-7 Major findings remain unresolved: the independent unit for G4 qualification, parameter equality between the main comparison and probe, and the meaning of “correct first character” versus boundary/readings success. They materially affect what the experiment can establish. This review neither treats their proposed mitigations as implemented nor establishes that the current design is ready to execute.

Read inventory and limits:

- Read the complete assigned zoom-out persona and Zoom-Out Standard.
- Read the complete review target, lines 1–326, recovering truncated portions with narrower reads.
- Read the complete manifest and the three explicitly supplied stage-context reports: `zoom_out_report.md`, `comprehension_report.md`, and `critic_report.md`.
- Read the complete repository `README.md` and linked `design/mixed-input-intent-experiment-v2.md`.
- Read the four authored documents through their manifest-mapped packet contents; did not independently reread or hash-verify their separate files.
- Read complete `core/mixedparse/context.go`, `core/mixedparse/guards.go`, and `internal/mixedeval/fit.py`.
- Read targeted excerpts of `core/mixedparse/generator.go:1–115`, `core/mixedparse/state.go:135–180`, `core/decode/decode.go:229–267`, `internal/mixedeval/replay.go:1–65`, `core/session/mixed_eval_adapter_test.go:1–120`, `core/session/session.go:437–452,486–531`, and `core/proto/proto.go:20–32,219–228`.
- Searched spelling, guards, decoding, parser/state-machine limits, fitting, and metric code for reuse. Incidental historical reporting-script search matches were excluded from review evidence.

No files were changed, tests or compilation run, or subagents used. No other history, memory, or reports informed the assessment. Source inspection does not establish parity with the pinned preview2 revision, helper suitability under the new contract, candidate recall, statistical validity of collected data, quality outcomes, or output feasibility.
