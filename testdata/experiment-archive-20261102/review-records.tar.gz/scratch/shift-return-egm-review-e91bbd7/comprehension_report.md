## What this proposes

The proposal studies automatic return to Chinese after the user presses Shift to mark the start of an English fragment. It preserves alternative English/Chinese interpretations within an uncommitted composition so that later syllables and words can revise an earlier boundary decision. The experiment compares four combinations of initial, length, and word evidence, crossed with two policies for freezing or revising earlier decisions; EC-revise remains the designated primary method. Passing the offline recognition gates permits a separate output experiment, while product integration and installation packages require further output, latency, and native integration evidence.

## How the existing system works, per this document

Shift currently toggles a persistent English mode. In English mode without a composition, the engine can return `handled=false`, allowing the application to receive the original keys; detecting a Chinese boundary afterward therefore does not establish that the first Chinese character can actually be produced. Existing conservative and aggressive mixed-input policies provide behavioral comparisons, but they are not implementations of this Shift-return feature. The proposal retains the existing Chinese decoder and hard protections, while introducing a local selector for the experimental fragment.

## Findings

### Blocker

None found. I could paraphrase both the intended feature and the experiment’s relationship to the current system.

### Major

None found within this self-containment review. The packet explains the distinctions between recognition and materialized output, reversible intermediate displays and final errors, reading accuracy and surface accuracy, and information effects and freezing effects.

### Nit — Identify the earlier evaluator and its components with a navigable reference

**Affected scope:** Packet lines 87 and 240; source `design/shift-return-protocol-v1.md`, lines 3 and 44.

The packet introduces `mixed-eval-v1`, then refers to the “old generator,” “old Machine,” and “guard parity tools” without a link or source location identifying those components. Their relevant limitations are explained, so this does not prevent understanding the new experiment. However, a fresh reader cannot establish which existing evaluator implementation those names denote or find the reusable tools from these references alone.

Add one documentation or source reference identifying the earlier evaluator and the named components. This is a navigation and terminology issue, not a request to complete the future implementation or its source-map artifacts.

## Read inventory and limits

Read completely:

- `/workspace/.0c-tools/review-skills/vendor/elephant-goldfish-model-403d8881d62022490637d740657b33f01e321ea8/agents/comprehension.md`
- `/workspace/scratch/shift-return-egm-review-e91bbd7/review_target.md`, lines 1–326, including the feature and detailed ranges. The initially truncated middle section was read separately.
- `/workspace/scratch/shift-return-egm-review-e91bbd7/manifest.json`
- `/workspace/0c-ime/design/mixed-input-intent-experiment-v2.md`, the linked document retaining applicable intent, collision, and isolation requirements.

Read targeted current-source excerpts:

- `core/proto/proto.go`, lines 20–32 and 219–228.
- `core/session/session.go`, lines 437–452 and 486–531.
- `core/session/mixed.go`, lines 596–625 and 1006–1031.
- `core/session/mixed_policy_test.go`, lines 1–44.

Also searched those source files for the named mode handlers, policy branches, and `numberLike`. The four authored documents represented in the packet were read through their assembled contents; their separate source files were not independently reread or hash-verified.

No required file access failed. No history, memory, previous review reports, builds, tests, experiments, or writes were used. Current-source excerpts were used for comprehension only; this review does not establish parity with the pinned preview2 revision or implementation readiness.

---

Reviewer: `/root/shift_egm_comprehension`, fresh context. This file preserves the complete returned report.
