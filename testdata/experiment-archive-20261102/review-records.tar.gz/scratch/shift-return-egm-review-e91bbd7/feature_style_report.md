# Stage 7 — Feature style review

Reviewer: `/root/shift_egm_feature_style`, fresh context. Complete returned report follows.

Style and clarity review — Feature Specification, packet lines 1–222

Two Major clarity issues and four Nits. No Blocker findings. The document generally distinguishes proposed experiments, hypothetical examples, and observed results clearly; none of the findings below assumes an experimental outcome.

1. **Major — The main comparison has conflicting descriptions of parameter equality.**

   References: packet line 65, `design/shift-english-auto-return-experiment.md:57`; packet lines 111–113, `design/shift-return-protocol-v1.md:27–29`.

   Line 65 requires the comparison to use the same strategy, candidate generation, dictionary, **parameters**, and raw keys. Lines 111–113 instead distinguish separately fitted feature models from a supplementary probe that holds EC coefficients fixed. A fresh reader cannot tell whether “same parameters” governs the main effectiveness comparison or only the probe.

   Clarify the two comparisons explicitly: the main feature comparison shares the fitting procedure and budget but permits separately fitted coefficients; the fixed-coefficient probe measures the frozen EC model’s sensitivity to context. Update the earlier summary to use those same terms.

2. **Major — “Success” alternates between correct characters and correct boundary/readings.**

   References: packet lines 23 and 73, `design/shift-english-auto-return-experiment.md:15,65`; packet line 218, `design/shift-return-worked-scoring.md:33`. Definition checked against packet lines 298 and 303, `design/shift-return-protocol-v1.md:102,107`.

   Line 23 defines success as correctly composing the first Chinese character, and line 73 includes composing the first character within the 90% target. The worked example allows a wrong homophone surface to succeed on intent/readings, while the detailed definition says G2 evaluates intent/readings only. These passages leave “correct first character” open to two interpretations: the intended written character or a materialized character with the intended reading.

   State consistently that the 90% gate measures boundary and complete readings, identify the required materialization behavior separately, and give surface accuracy its own named metric. This preserves the existing distinctions without making the headline success claim broader than its denominator.

3. **Nit — The revision history depends on missing conversational context.**

   References: packet line 13, `design/shift-english-auto-return-experiment.md:5`; packet line 120, `design/shift-return-combination-order.md:3`.

   “使用者指出” explains a requirement through an unavailable conversation, while “此處『三種』依前文解讀” refers to wording whose antecedent is unclear in the packet. The latter also places three information groups beside the protocol’s three model conditions, inviting confusion about what was expanded.

   State the current requirement directly. In the supplement, say that the earlier conditions were E0, EL, and EC, and that adding EW completes the B-always-present, L-by-W factorial comparison.

4. **Nit — The E0 summary can be mistaken for decision freezing.**

   References: packet lines 65 and 106, `design/shift-english-auto-return-experiment.md:57` and `design/shift-return-protocol-v1.md:22`; packet lines 147–150, `design/shift-return-combination-order.md:30–33`. Definition checked against packet line 256, `design/shift-return-protocol-v1.md:60`.

   “之後不利用後文重估該切法” and “不使用後文詞證據重評它” can suggest that E0 fixes the initial boundary decision. The supplement separately defines O-fixed, and the detailed definition says E0 under O-revise does not freeze the raw keys. The feature section should make this distinction visible before introducing the process matrix.

   Describe E0 as freezing the candidate’s initial information features while leaving decision revision governed by O-fixed or O-revise. Avoid wording that makes information freezing sound like ownership freezing.

5. **Nit — Mixed terminology increases the cost of following the comparisons.**

   References: packet lines 55, 65–79, 111–113, and 135–158.

   The prose switches repeatedly between Chinese terms and English fragments such as “paired groups,” “context,” “final error,” “features,” “replay conditions,” and “ownership／reading.” Some English identifiers are useful, especially E0, EC, and O-revise, but several ordinary concepts receive multiple renderings without an introductory mapping.

   Add a compact terminology note and use one rendering consistently for repeated concepts—for example, 後文資訊（context）, 配對群組（paired groups）, and 最終錯誤率（final error rate）. Keep exact model and API identifiers unchanged.

6. **Nit — Some prohibitions use accusatory language where a validity condition would be more precise.**

   References: packet lines 67, 95, 150, and 152, respectively `design/shift-english-auto-return-experiment.md:59`, `design/shift-return-protocol-v1.md:11`, and `design/shift-return-combination-order.md:33,35`.

   “不能冒稱,” “不假裝,” and “不能……冒充” imply misrepresentation rather than explaining the evidentiary limit. The surrounding technical requirements already provide a factual basis for direct wording.

   Replace these with statements such as “此結果不足以證明跨 literal／讀音比較,” “本輪不涵蓋多次自動切換,” and “generator recall 須以封存篩選前的候選集合計算.” The constraints remain equally strict and become easier to apply objectively.

Read inventory and limits:

- Read the complete assigned Style Goldfish persona.
- Read the manifest and all packet lines 1–326. Findings target Feature Specification lines 1–222; Detailed Implementation Plan lines 223–326 were used for definitions and clarification.
- Read the complete explicitly linked `design/mixed-input-intent-experiment-v2.md` to check inherited terminology and requirements.
- The four authored source documents were read through their manifest-mapped packet excerpts; the complete protocol is included across the two packet sections.
- No additional style standard was provided. No conversation history, previous review reports, source code, experiment outputs, tests, or builds were used. No files were changed.
