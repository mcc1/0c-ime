# Stage 5 — Initial zoom-out review

Reviewer: `/root/shift_egm_initial_zoom`, fresh context. The following is the complete returned report.

Zoom-out review: no Blocker, Major, or Nit findings.

The design provides enough context and addresses the root problem: using the manually marked English start to infer the return boundary while preserving the first Chinese syllable and the complete intended English span. Its scope stays within one eligible Shift-started segment, separates automatic English entry into S2, and separates offline recognition from actual output ownership and native integration. These boundaries are explicit in packet lines 19–44, 81, 93–95, and 311–317.

The additional experiment conditions have stated purposes rather than speculative product requirements. The B/L/W comparisons distinguish word evidence from length, and the fixed/revise comparison distinguishes evidence from the opportunity to revise. The eight conditions share four fitted models and retain EC-revise as the declared primary method. Packet lines 124–180 explain these distinctions and limit the conclusions appropriately. I do not regard the implementation detail in packet lines 227–325 as an altitude violation because it is explicitly placed in the Detailed Implementation Plan.

Code searches substantiate the principal reuse claims:
- `core/mixedparse/context.go:10` provides `SpellExact`.
- `core/decode/decode.go:229` provides `Decoder.Best`, returning a decoded path and log score.
- `core/mixedparse/guards.go:15` and `:102` provide `NumberLike` and the existing guard projection.
- `core/session/mixed_eval_adapter_test.go:59` contains guard projection parity coverage.
- `internal/mixedeval/replay.go:28` already provides the Wilson incidence calculation.
- `internal/mixedeval/fit.py` provides an existing pairwise logistic fitting pattern, although its eligibility rules, feature schema, weighting, optimization budget, and selection procedure differ from this protocol and cannot be adopted unchanged.

The need for a separately versioned experiment is supported by the existing generator: `core/mixedparse/generator.go:27–50` limits parsing to two syllables, and `:89–108` imposes the 64-byte limit and explicit-tone restrictions. The old state machine also contains early-closing behavior. Thus packet lines 242 and 321 do not establish a needless replacement of a suitable existing implementation. Keeping the existing decoder and strict-spelling primitives while changing the experiment contract is a reasonable boundary.

Read inventory:
- Read the complete assigned persona and Zoom-Out Standard.
- Read all 326 packet lines and the complete manifest mapping.
- Read the complete repository `README.md` and linked `design/mixed-input-intent-experiment-v2.md`.
- Read the authored experiment, combination-order, worked-scoring, and protocol content completely through their packet copies.
- Read complete `core/mixedparse/context.go`, `types.go`, `guards.go`, and `internal/mixedeval/fit.py`.
- Read relevant portions of `core/mixedparse/generator.go`, `core/session/mixed_eval_adapter.go`, `mixed_eval_adapter_test.go`, `session.go`, `core/decode/decode.go`, and `internal/mixedeval/replay.go`.
- Searched parser/state-machine, ranking, guard, spelling, decoding, fitting, and metric code for existing implementations. A broad reuse search incidentally returned historical reporting-script snippets; those were excluded from review evidence and conclusions.

Verification limits: this was a read-only document and source review. I made no edits, ran no compilation or tests, inspected no experiment outputs, and verified no quality claims. Source-map parity, derived-feature vectors, complete event handling, data independence, candidate recall, and output feasibility remain prospective requirements. The documents explicitly identify those limits and do not present the hypothetical scoring examples as experiment results.
