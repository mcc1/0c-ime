# Stage 9 — Codebase details review

Reviewer: `/root/shift_egm_codebase`, fresh context. Complete returned report follows.

Codebase Details review: no verified Blocker; three Majors and one Nit. The document correctly identifies several limitations of the existing evaluator, but it does not yet satisfy the implementation standard’s zero-decision rule.

1. Major — The implementation file map and executable checkpoints remain deferred.

Affected scope: `design/shift-return-protocol-v1.md:125–129` (packet lines 321–325), particularly “具體package／CLI需在code freeze manifest列齊.”

The proposed `shiftreturneval` version is clearly a future artifact; its absence is not a nonexistent-reference defect. However, the plan leaves its package layout, CLI, file changes, schemas, and verification entry points to the implementer. It also gives one broad implementation step before freeze rather than incremental phases with explicit buildable checkpoints. Existing infrastructure is spread across `core/mixedparse`, build-tagged `core/session/mixed_eval_adapter.go`, `internal/mixedeval`, and `cmd/0c-mixed-eval`; selecting which pieces to reuse or replace is an architectural decision.

Recommended resolution: add a single Create/Modify/Delete file inventory, package ownership, exact CLI commands and artifact contracts, and incremental implementation phases with specified checks. Preserve the old evaluator as required. Report this omission once rather than treating each proposed file as a missing existing reference.

2. Major — The B-feature source adapters are intentionally unresolved, and existing guard parity does not supply the missing recommendations.

Affected scope: `design/shift-return-protocol-v1.md:54–64` (packet lines 250–260).

The plan explicitly postpones mapping the conservative/aggressive recommendation flags and initial score adapter to concrete helpers. Those choices materially define B and therefore all four models.

The reusable `mixedparse.Evaluator.Guards` in `core/mixedparse/guards.go` returns 13 individual predicates. The parity infrastructure in `core/session/mixed_eval_adapter_test.go:57–100` compares those predicates against Session helpers; it does not establish equivalence to the complete conservative/aggressive recommendation. Actual decisions include ordered branches in `core/session/mixed.go:464–549`, `mixedBoundary` at lines 601–661, and `core/session/mixed_policy.go:25–69`, including competition between offsets, frequency ratios, whole-reading acceptance, and typo recovery.

The score interpretation also needs resolution. Existing `mixedSyllableScore` calls `Best(..., prefix=true)` and exponentiates its result (`core/session/mixed.go:758–762`); it can score a reading through longer-word prefix support. The proposed B feature says “exact statistical log score,” and explicitly permits missing scores for prefix-only support, while W explicitly requires `prefix=false`. These are different contracts, not interchangeable representations of one existing helper.

Recommended resolution: complete the source map now. Specify recommendation flag identity, projected context and raw arguments, branch precedence, score scorer/options, `prefix` value, log/probability conversion, and missing-value behavior. Supply worked vectors and parity cases for the complete derived features, including first-tone space, prefix-only readings, competing offsets, and typo recovery. A future stop-if-unmappable requirement prevents accidental approximation but does not make the current plan implementation-ready.

3. Major — Required Shift/space/baseline replay behavior has no concrete replacement adapter contract.

Affected scope: `design/shift-return-protocol-v1.md:35–44,100–105` (packet lines 231–240 and 296–301), with the M/R/C/A definitions at source lines 17–20.

The new generator’s stated limitations are accurate, but changes are also needed in the event and observation infrastructure:

- `internal/mixedeval/replay.go:83–142` has no Shift/Toggle event mapping. Its environment mapping sets `proto.Mode`, which does not preserve the distinction the experiment requires between manual Shift eligibility and generic English mode.
- `core/session/mixed_eval_adapter.go:104–109` excludes spaces from its raw ledger and marks every space unsupported. Space is mandatory in at least 20% of return primaries.
- That observer derives ownership from Session composition. In M, English keys can pass directly to the application (`core/session/session.go:525–526`), so Session composition alone cannot reconstruct full end-to-end output.
- Existing `mixedparse.Context.Protected` treats all English mode as protected (`core/mixedparse/types.go:44–46`). The plan correctly requires a separate eligibility concept, but does not define its event/state interface.
- C/A are explicitly said to be behavior controls rather than actual Shift-return strategies. The exact event transformation from the Shift-bearing task to those Chinese-mode mixed-input controls is not specified.

These are not false claims that the new functionality already exists. They are missing implementation contracts necessary to obtain the stipulated G0/G5 evidence.

Recommended resolution: define the new event schema and transition table, actual `proto.Toggle` replay, eligibility lifecycle, space ownership, application-output ledger for unhandled keys, M/R/C/A event transformations, and exact observer support/failure behavior. Include infrastructure parity checks covering Shift, spaces, pass-through output, pre-existing composition, repeated toggles, and protected states.

4. Nit — Cite the verified reusable APIs directly.

Affected scope: `design/shift-return-protocol-v1.md:44,56,62` (packet lines 240, 252, 258).

The existing reuse claims are substantially correct: `mixedparse.SpellExact` exists in `core/mixedparse/context.go:10–21`; `decode.Decoder.Best` returns a path and log score and supports `prefix=false` in `core/decode/decode.go:227–279`; `mixedparse.Project` resets `LastWord` and retained prefix for nonempty literal prefixes in `core/mixedparse/types.go:99–111`. English dictionary membership preserves supplied source text while its lookup normalizes ASCII case (`core/english/dictionary.go:104–110`).

Recommended resolution: name these exact APIs and source locations in the plan, alongside the limitations of their current callers. This makes the reuse instructions executable without additional source discovery.

Verified existing-state claims and version distinctions:

The old generator enforces 64 bytes, at most two parsed syllables, explicit `3467` tone endings, and excludes spaces; the old Machine closes on its second tone opportunity. These match packet line 240. The neural caution is also justified: `core/rerank/rerank.go` accepts a reading plus Chinese candidate hypotheses and enforces length/alignment constraints; it does not define calibrated comparison between arbitrary literal and alternate-reading boundary hypotheses.

Repository HEAD is `e91bbd7bddf473fa205aba5c2fa700b6ae710678`. Compared with pinned preview2 `e754019571573051d8c29e06526802c31d5172e2`, the inspected Session mixed-input change is the observer hook in `insertMixedTyped`; `mixed_policy.go` and decoder production behavior show no differences in that comparison. The evaluator/observer packages were added afterward. Comparing upstream `04fa94ee…` with preview2 confirms substantial mixed-input changes, including addition of `mixed_policy.go`; treating upstream as an interchangeable baseline would be incorrect, and the plan appropriately separates it.

Read inventory:

Read the complete assigned persona and implementation-readiness standard; the entire packet in two passes; its manifest; the complete linked `mixed-input-intent-experiment-v2.md`, combination-order supplement, and worked-scoring supplement. Inspected complete `core/mixedparse/{generator,guards,state,context,types}.go`, `core/session/mixed_eval_adapter.go`, `internal/mixedeval/correctness.go`, `core/rerank/rerank.go`, and targeted production sections of Session mode/key handling, mixed-input decisions, aggressive policy, decoder, personal scorer, English dictionary, replay, and rerank integration. Read guard/observer parity infrastructure and both asset manifests. Used Git read-only comparisons for the pinned versions.

Verification limits:

No files were changed and no compilation, tests, replay, model training, or quality evaluation was run. Source inspection establishes API existence and visible behavior, not empirical parity or experiment feasibility. New packages, schemas, trained models, and reports were treated as proposed artifacts, not falsely claimed existing code.
