# Stage 9 — Combined implementation readiness report

Two Blockers, ten Majors and four Nits were returned before deduplication. The plan is not implementation-ready. No design edits were made.

---

# Stage 9 — Implementation-readiness review

Reviewer: `/root/shift_egm_readiness`, fresh context. Complete returned report follows.

The plan does not pass the implementation-readiness standard. It fixes substantial experimental policy, including the four models, eight replay conditions, main EC-revise condition, training budget, margins, and quality gates. However, implementing the offline evaluator still requires decisions about interfaces, event handling, feature adapters, labels, numerical conventions, data qualification, and verification.

This assessment concerns offline evaluator, data, fitting, and reporting readiness. The explicitly deferred output experiment, native Windows integration, latency thresholds, and installation package are not current implementation blockers.

1. **Blocker — Required implementation contracts are still future deliverables.**

   **References:** `design/shift-return-protocol-v1.md:64,125–129`; packet lines 260, 321–325.

   The plan requires a source map, schemas, examples, feature vectors, and concrete package/CLI names, but does not provide them. Naming `shiftreturneval` does not identify files to create or modify, exported interfaces, command arguments, artifact formats, validation failures, or exit behavior. A fresh engineer must design the evaluator’s boundaries and interchange contracts before implementing it.

   Supply an explicit file-change list and interface/schema definitions for fixtures, candidates, snapshots, model files, locks, replay results, and reports. Specify the commands and artifact dependencies for each phase. These can be small contracts, but they must precede implementation under the zero-decision rule.

2. **Blocker — The core B features and decoder adapters have not been mapped to executable behavior.**

   **References:** `design/shift-return-protocol-v1.md:54–64`; packet lines 250–260.

   “Original conservative/aggressive recommendation equivalent flag” does not define whether a feature means that a particular candidate is recommended, that any Chinese interpretation is recommended, or that a particular legacy branch fires. The required snapshot projection into the legacy helpers is also absent. The document explicitly says to stop if this projection cannot be established, so this is an acknowledged prerequisite, not completed readiness.

   The inspected source demonstrates why merely naming existing helpers is insufficient. At pinned preview2, `core/session/mixed.go:461–546` implements a stateful sequence of branches, and `mixedBoundary` at lines 598–658 selects between offsets using several thresholds. The current `core/mixedparse/guards.go:102–117` returns thirteen predicates; it does not directly provide the two proposed recommendation features.

   Likewise, specify the initial statistical score’s scorer, decoder options, prefix setting, missing-value handling, and log/probability conversion. The pinned legacy single-syllable helpers at `mixed.go:740–759` return exponentiated scores with `prefix=true`, while W explicitly uses complete decoding with `prefix=false`.

   Provide the promised source map and worked vectors, including competing offsets, first-tone space, prefix-only support, and missing scores. Define parity assertions against the pinned source.

3. **Major — The offline event and baseline replay contracts remain incomplete.**

   **References:** `design/shift-english-auto-return-experiment.md:30–32`; packet lines 38–40. `design/shift-return-protocol-v1.md:19–21,35–42,100,105`; packet lines 103–105, 231–238, 296, 301.

   The feature specification requires evaluator behavior for repeated Shift, focus/field changes, cursor movement, paste, and explicit selection. The detailed plan supplies eligibility and lock constraints, but no transition table defining how these events close, commit, cancel, preserve, or reset the virtual fragment. The normal-mode and protected-mode regression cases therefore cannot be implemented without choosing behavior.

   C/A replay is also ambiguous: replaying the same Shift prelude literally puts the legacy Session into English mode, whereas its mixed-input behavior requires a different mode setup. Specify exactly which events each baseline receives and which transformations are intentional.

   Define an offline application ledger for unhandled keys and commits. The inspected `core/session/session.go:526–530` returns unhandled English keys when no composition exists; treating Session snapshots alone as the entire visible output would lose those keys. The existing observer is not a complete solution: `core/session/mixed_eval_adapter.go:104–109` excludes spaces from its raw ledger and marks spaces and several punctuation keys unsupported.

   This finding requires a deterministic offline replay contract; it does not require implementing native focus or paste integration now.

4. **Major — Pending candidates lack a complete selection and display contract.**

   **References:** `design/shift-return-protocol-v1.md:37–41,54–60,74`; packet lines 233–237, 250–256, 270. `design/shift-return-combination-order.md:30–35`; packet lines 147–152.

   Prefix-only candidates must survive, but must not count as completed characters. Pending tails must remain recoverable. The plan does not specify the exact virtual display when such a candidate wins, which portions receive Chinese ownership, or whether a candidate without complete word coverage is eligible to replace literal display.

   W’s treatment of incomplete paths also needs a full feature vector: specify whether an already completed Chinese prefix supplies its word coverage and mean score while a later syllable is pending, and define every W value for the literal branch.

   These choices affect the O-fixed projection, “already displayed bytes,” first-success time, and transient-error duration. Add worked transitions showing partial first syllable, prefix-only first reading, completed word plus incomplete next syllable, and uninterpretable trailing raw bytes. State the exact candidate identity, features, display, ownership, and O-fixed compatibility result at each event.

5. **Major — The fitting instructions still admit materially different numerical implementations.**

   **References:** `design/shift-return-protocol-v1.md:68–76`; packet lines 264–272.

   Pairwise logistic loss and hierarchical equal weighting are specified, but the exact equation and normalization are not. Define whether L2 contributes `λ‖w‖²` or `λ‖w‖²/2`, which coefficients it covers, and how hierarchy weights behave when checkpoints have no valid pairs.

   Standardization also needs an exact observation population: identify the checkpoints included, whether repeated candidates count once per observation, whether missing score placeholders enter mean/std, and whether std uses a population or sample denominator.

   Gold projection needs rules for a prefix that has entered the intended Chinese span but has not completed its first syllable, and for fixtures with multiple acceptable readings. “Gold versus every negative” does not determine how multiple acceptable candidates participate in the loss.

   Supply a small numerical worked example with projected labels, observation counts, normalization statistics, pair weights, objective, gradient, and first update. Fixed learning rate and iteration count alone do not make the model reproducible.

6. **Major — Data acquisition and qualification need operational definitions.**

   **References:** `design/shift-return-protocol-v1.md:82–92`; packet lines 278–288. `design/shift-english-auto-return-experiment.md:47`; packet line 55.

   Source eligibility and acquisition budgets are fixed, but the acquisition and annotation procedure remains open. The engineer must choose source collections or manual task procedures, adjudication rules, the “main coverage” taxonomy, and allocation across the stated length strata.

   The context-contrast cohort is especially consequential: “desired spans and prefix collision structure” does not provide a deterministic predicate establishing when a continuation supplies distinguishing information. Different annotators could construct different hundred-group qualifying cohorts without violating the prose.

   Specify these procedures and classification rules before collection. Define stable IDs and the exact `sorted_component_ids` input to the split hash; relate family, group, equivalence group, and component explicitly. Include annotation examples for typo recovery, opposite-intent collisions, immediate termination, and intentional incomplete tails. The actual new dataset can remain a later execution artifact.

7. **Major — Reporting and uncertainty calculations need a complete executable contract.**

   **References:** `design/shift-return-protocol-v1.md:76,96–111`; packet lines 272, 292–307. `design/shift-return-combination-order.md:18,50`; packet lines 135, 167.

   Dev selection uses a single “literal-final” rate even though the final gates deliberately separate literal-only errors from return-English-span errors. State whether dev eligibility requires both rates independently and how the subsequent sorting compares them.

   Bootstrap seed and iteration count are fixed, but the random generator, interval construction, and treatment of replicates with empty subgroup denominators are not. Also clarify whether a component may contain multiple scoring groups. If it can, explain how the claimed independent-group qualification and Wilson denominator are established.

   Define report fields and formulas for paired repaired/worsened groups, interaction effects, revision gain, first correctness, final stability, and transient-error durations. The worked scoring supplement verifies several final outcomes, but does not determine these calculations or provide a full expected gate report.

8. **Major — The verification phase lacks the specific test plan required by the standard.**

   **References:** `design/shift-return-protocol-v1.md:44,100–105,125–127`; packet lines 240, 296–301, 321–323.

   The plan says to add tests and verify tools before freezing, but does not identify test files, commands, fixtures, expected assertions, or phase completion criteria. Quality gates describe experimental acceptance; they do not establish that the evaluator implements the contract correctly.

   Add concrete verification cases for first-tone spaces; prefix-only survival into a complete word; pending tails; B snapshots unaffected by later evidence; future-key/gold exclusion; deterministic capping and overflow; O-fixed compatibility and fallback; literal and Chinese score ties; multiple acceptable labels; split/grouping determinism; weighting and gradients; and independently recomputed reporting. Define baseline parity, disposable-store invariance, protected-mode zero calls, and Enter-equals-last-display assertions. Map these checks to stable implementation checkpoints.

No Nit findings are necessary. The listed gaps affect executable behavior or the validity of the experiment.

Actual read inventory:

- Complete implementation-readiness persona and standard at the two paths supplied in the task.
- Packet manifest and target packet, with complete authoritative source reads covering the packet’s feature and detailed sections.
- Complete `design/shift-english-auto-return-experiment.md`, `design/shift-return-protocol-v1.md`, `design/shift-return-combination-order.md`, and `design/shift-return-worked-scoring.md`.
- Complete linked `design/mixed-input-intent-experiment-v2.md`.
- Complete current `core/session/mixed_eval_adapter.go`, and `core/mixedparse/types.go`, `generator.go`, `guards.go`, and `context.go`.
- Current `core/proto/proto.go:1–155`; relevant `core/session/session.go` sections around request dispatch, mode changes, and English key handling; `core/decode/decode.go:83–159`.
- Pinned preview2 `core/session/mixed.go` excerpts containing `finishMixedTone`, `mixedBoundary`, `englishThenNumber`, and associated scoring and boundary helpers.
- Repository filename and symbol searches to locate these implementation references.

Limits: This was a read-only document-readiness review with targeted source inspection. No files were changed; no tests, compiles, experiments, or subagents were run. No prior reports, conversation history, or memory were read. Source inspection did not establish complete baseline parity or validate the proposed adapters. No required persona, standard, target section, or linked design supplement was left unread.

---

# Stage 9 — Codebase details review

Reviewer: `/root/shift_egm_codebase`, fresh context. Complete returned report follows.

Codebase Details review: no verified Blocker; three Majors and one Nit. The document correctly identifies several limitations of the existing evaluator, but it does not yet satisfy the implementation standard’s zero-decision rule.

1. Major — The implementation file map and executable checkpoints remain deferred.

Affected scope: `design/shift-return-protocol-v1.md:125–129` (packet lines 321–325), particularly “具體package／CLI需在code freeze manifest列齊.”

The proposed `shiftreturneval` version is clearly a future artifact; its absence is not a nonexistent-reference defect. However, the plan leaves its package layout, CLI, file changes, schemas, and verification entry points to the implementer. It also gives one broad implementation step before freeze rather than incremental phases with explicit buildable checkpoints. Existing infrastructure is spread across `core/mixedparse`, build-tagged `core/session/mixed_eval_adapter.go`, `internal/mixedeval`, and `cmd/0c-mixed-eval`; selecting which pieces to reuse or replace is an architectural decision.

Recommended resolution: add a single Create/Modify/Delete file inventory, package ownership, exact CLI commands and artifact contracts, and incremental implementation phases with specified checks. Preserve the old evaluator as required. Report this omission once rather than treating each proposed file as a missing existing reference.

2. Major — The B-feature source adapters are intentionally unresolved, and existing guard parity does not supply the missing recommendations.

Affected scope: `design/shift-return-protocol-v1.md:54–64` (packet lines 250–260).

The plan explicitly postpones mapping the conservative/aggressive recommendation flags and initial score adapter to concrete helpers. Those choices materially define B and therefore all four models.

The reusable `mixedparse.Evaluator.Guards` in `core/mixedparse/guards.go` returns 13 individual predicates. The parity infrastructure in `core/session/mixed_eval_adapter_test.go:57–100` compares those predicates against Session helpers; it does not establish equivalence to the complete conservative/aggressive recommendation. Actual decisions include ordered branches in `core/session/mixed.go:464–549`, `mixedBoundary` at lines 601–661, and `core/session/mixed_policy.go:25–69`, including competition between offsets, frequency ratios, whole-reading acceptance, and typo recovery.

The score interpretation also needs resolution. Existing `mixedSyllableScore` calls `Best(..., prefix=true)` and exponentiates its result (`core/session/mixed.go:758–762`); it can score a reading through longer-word prefix support. The proposed B feature says “exact statistical log score,” and explicitly permits missing scores for prefix-only support, while W explicitly requires `prefix=false`. These are different contracts, not interchangeable representations of one existing helper.

Recommended resolution: complete the source map now. Specify recommendation flag identity, projected context and raw arguments, branch precedence, score scorer/options, `prefix` value, log/probability conversion, and missing-value behavior. Supply worked vectors and parity cases for the complete derived features, including first-tone space, prefix-only readings, competing offsets, and typo recovery. A future stop-if-unmappable requirement prevents accidental approximation but does not make the current plan implementation-ready.

3. Major — Required Shift/space/baseline replay behavior has no concrete replacement adapter contract.

Affected scope: `design/shift-return-protocol-v1.md:35–44,100–105` (packet lines 231–240 and 296–301), with the M/R/C/A definitions at source lines 17–20.

The new generator’s stated limitations are accurate, but changes are also needed in the event and observation infrastructure:

- `internal/mixedeval/replay.go:83–142` has no Shift/Toggle event mapping. Its environment mapping sets `proto.Mode`, which does not preserve the distinction the experiment requires between manual Shift eligibility and generic English mode.
- `core/session/mixed_eval_adapter.go:104–109` excludes spaces from its raw ledger and marks every space unsupported. Space is mandatory in at least 20% of return primaries.
- That observer derives ownership from Session composition. In M, English keys can pass directly to the application (`core/session/session.go:525–526`), so Session composition alone cannot reconstruct full end-to-end output.
- Existing `mixedparse.Context.Protected` treats all English mode as protected (`core/mixedparse/types.go:44–46`). The plan correctly requires a separate eligibility concept, but does not define its event/state interface.
- C/A are explicitly said to be behavior controls rather than actual Shift-return strategies. The exact event transformation from the Shift-bearing task to those Chinese-mode mixed-input controls is not specified.

These are not false claims that the new functionality already exists. They are missing implementation contracts necessary to obtain the stipulated G0/G5 evidence.

Recommended resolution: define the new event schema and transition table, actual `proto.Toggle` replay, eligibility lifecycle, space ownership, application-output ledger for unhandled keys, M/R/C/A event transformations, and exact observer support/failure behavior. Include infrastructure parity checks covering Shift, spaces, pass-through output, pre-existing composition, repeated toggles, and protected states.

4. Nit — Cite the verified reusable APIs directly.

Affected scope: `design/shift-return-protocol-v1.md:44,56,62` (packet lines 240, 252, 258).

The existing reuse claims are substantially correct: `mixedparse.SpellExact` exists in `core/mixedparse/context.go:10–21`; `decode.Decoder.Best` returns a path and log score and supports `prefix=false` in `core/decode/decode.go:227–279`; `mixedparse.Project` resets `LastWord` and retained prefix for nonempty literal prefixes in `core/mixedparse/types.go:99–111`. English dictionary membership preserves supplied source text while its lookup normalizes ASCII case (`core/english/dictionary.go:104–110`).

Recommended resolution: name these exact APIs and source locations in the plan, alongside the limitations of their current callers. This makes the reuse instructions executable without additional source discovery.

Verified existing-state claims and version distinctions:

The old generator enforces 64 bytes, at most two parsed syllables, explicit `3467` tone endings, and excludes spaces; the old Machine closes on its second tone opportunity. These match packet line 240. The neural caution is also justified: `core/rerank/rerank.go` accepts a reading plus Chinese candidate hypotheses and enforces length/alignment constraints; it does not define calibrated comparison between arbitrary literal and alternate-reading boundary hypotheses.

Repository HEAD is `e91bbd7bddf473fa205aba5c2fa700b6ae710678`. Compared with pinned preview2 `e754019571573051d8c29e06526802c31d5172e2`, the inspected Session mixed-input change is the observer hook in `insertMixedTyped`; `mixed_policy.go` and decoder production behavior show no differences in that comparison. The evaluator/observer packages were added afterward. Comparing upstream `04fa94ee…` with preview2 confirms substantial mixed-input changes, including addition of `mixed_policy.go`; treating upstream as an interchangeable baseline would be incorrect, and the plan appropriately separates it.

Read inventory:

Read the complete assigned persona and implementation-readiness standard; the entire packet in two passes; its manifest; the complete linked `mixed-input-intent-experiment-v2.md`, combination-order supplement, and worked-scoring supplement. Inspected complete `core/mixedparse/{generator,guards,state,context,types}.go`, `core/session/mixed_eval_adapter.go`, `internal/mixedeval/correctness.go`, `core/rerank/rerank.go`, and targeted production sections of Session mode/key handling, mixed-input decisions, aggressive policy, decoder, personal scorer, English dictionary, replay, and rerank integration. Read guard/observer parity infrastructure and both asset manifests. Used Git read-only comparisons for the pinned versions.

Verification limits:

No files were changed and no compilation, tests, replay, model training, or quality evaluation was run. Source inspection establishes API existence and visible behavior, not empirical parity or experiment feasibility. New packages, schemas, trained models, and reports were treated as proposed artifacts, not falsely claimed existing code.

---

# Stage 9 — Detailed style review

Reviewer: `/root/shift_egm_readiness_style`, fresh context. Complete returned report follows.

No Blocker findings. One Major precision issue and three Nits.

1. **Major — Ambiguous scope of dataset strata.** Packet lines 280 and 286; `design/shift-return-protocol-v1.md:84,90`.

   “每組含單字、2–4音節短詞、5–16音節段落、17–64音節長段” does not identify whether “每組” means each dependency group, each intent cohort, or each coverage category. It follows both return and literal categories, although Chinese syllable counts do not directly describe ordinary literal-only tasks. “每個主coverage類至少20 groups” then imposes a qualification threshold without explicitly identifying the applicable category list. State which cohort receives the syllable strata, whether each dependency group must contain every stratum, and which named categories require 20 groups. These distinctions affect what qualifies as sufficient data.

2. **Nit — “Canonical” terminology lacks a precise referent.** Packet lines 236, 264, 268 and 270; `design/shift-return-protocol-v1.md:40,68,72,74`.

   The document alternates between “canonical reading UTF8,” “canonical identity,” and “canonical排序” when specifying truncation, negative enumeration and tie breaking. It does not explicitly say whether these share an ordering or identify the fields comprising canonical identity. Define the identity and ordering once, then reference that definition consistently. This is especially useful because these phrases specify deterministic behavior rather than incidental implementation details.

3. **Nit — G5 uses an ambiguous compressed phrase.** Packet line 301; `design/shift-return-protocol-v1.md:105`.

   “假設學習／持久化0” can read as “assume learning/persistence is zero,” rather than as a prohibition on side effects while evaluating candidate hypotheses. Line 238 helps establish the intended restriction, but the gate should stand alone. Name the prohibited operations and their counting scope explicitly, such as learning updates and persistent writes during candidate evaluation, if that is the intended requirement.

4. **Nit — Replace conversational metaphors with direct technical requirements.** Packet lines 254, 256, 264, 270 and 315; `design/shift-return-protocol-v1.md:58,60,68,74,119`.

   Phrases such as “不交給模型投票,” “E0會偷看到後文,” “不抽容易negatives,” “黏住前次答案,” and “feature actually consumed” make otherwise precise requirements less uniform. Prefer direct statements: enforce hard constraints before scoring; freeze B before subsequent context arrives; enumerate all negative candidates; apply no hysteresis margin; verify that feature values enter candidate scoring. These edits preserve the requirements while making them easier to audit.

Actual read inventory: the complete supplied `agents/style.md`; `review_target.md` lines 1–326, with findings restricted to DetailedRange 223–326; the adjacent `manifest.json`; the complete `design/shift-return-combination-order.md`; and the complete linked `design/mixed-input-intent-experiment-v2.md` lines 1–114. The feature specification, protocol introduction and worked-scoring supplement were read in the packet for definitions and context.

Limits: no additional style standard was supplied. This was a read-only document style and precision review. I did not read prior review reports, inspect implementation source, modify files, compile, run tests, or verify experimental claims. The document explicitly describes a proposed experiment and hypothetical scoring examples; this review does not imply that implementation, training or evaluation occurred.
