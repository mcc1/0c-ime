# Shift-return experiment: review packet

This packet assembles the authored documents without changing their claims. Source documents remain authoritative. Relative Markdown links are expanded to absolute paths. Review the linked supplements and source references; do not use conversation history or earlier review reports.

## Feature Specification

### Source: design/shift-english-auto-return-experiment.md (lines 1–73)

### 先研究手動英文起點、自動中文終點

狀態：依新的使用情境調整研究順序；目標設計，尚未執行或改產品。此文件優先於[混打意圖 v2](/workspace/0c-ime/design/mixed-input-intent-experiment-v2.md)的執行順序。v2 的中文／literal 意圖、不可辨識衝突與資料隔離要求繼續適用，但其 C/A 改善率不能直接套在本實驗。

開跑前目標修訂：使用者指出整段組字與後文證據是核心，因此取消「第二音節截止」及「任何暫時轉字皆算最終誤判」的設定。改評未提交整段的最終結果，以及後文究竟修好多少前面的判斷。此修訂在新實驗、資料與品質結果之前完成；不是依實驗結果放寬門檻。

細化設計見[實驗 protocol v1](/workspace/0c-ime/design/shift-return-protocol-v1.md)及[手算計分例](/workspace/0c-ime/design/shift-return-worked-scoring.md)。後者是假設輸出演練，不是品質結果。

#### 核心目標

使用者在中文輸入時先按 Shift 切到英文，已提供英文片段的起點。**第一階段只判斷何時結束英文片段，並從正確的按鍵邊界恢復中文組字，免去第二次 Shift。** 不同時研究自動開始英文，不重寫全部 mixed-input 邏輯。

例：`[Shift]microsoftsu3cl3`，期望完整保留 `microsoft` 並輸出「你好」。另一個同樣以 Shift 開始的任務可能是帳號 `microsoft593`，它應完整保留；若任務是 `microsoft` 加「窄」，就需要判斷後段中文。Shift 提供起點及英文意圖，並沒有消除終點歧義。

成功是首個中文字也正確組出、英文原文完整保留，不只是模式指示燈切回中文。允許輸入後面的字詞後，自動重新判斷同一未提交組字段的先前切法；使用者打完再手動選字／重打則另計介入成本，不算自動成功。不能要求只看第一音節就永久定案。

例如到 `microsoft593` 時可同時保留帳號與「microsoft窄」；後面出現意圖為「窄小的走道」的注音時，必須檢查成詞及句子證據是否實際提高中文解釋的選擇，並修正先前的 literal 判斷。相反地，帳號後續或刻意用注音按鍵構造的完整帳號，不能只因有中文詞就一律轉字。

#### 兩階段分開驗證

| 階段 | 已知條件 | 唯一新增判斷 | 暫不改動 |
| --- | --- | --- | --- |
| S1，優先 | 使用者 Shift 標示英文起點 | 英文何時結束、中文從哪個 raw offset 開始 | 自動進英文、一般中文 decoder、帳號／格式等非目標邏輯 |
| S2，後續 | 起點未知 | 何時進英文；何時回中文 | S1 的終點機制先固定，再測新增起點判斷的影響 |

S1 通過不能宣稱 S2 也通過。S2 比較固定終點機制＋手動起點與同機制＋自動起點，避免把兩種錯誤混在一起。

#### 模式語意與來源

現有 `core/proto/proto.go` 的 `Toggle` 表示單按 Shift；`core/session/session.go` 的 `setMode` 處理切換，`key` 在英文且無 composition 時回 `handled=false`，英文字元可能已直接送入應用程式。Shift 目前是持續英文模式，本提案會改變這個語意，必須在明確啟用實驗行為的條件下測試，不靜默更動所有使用者的手動英文選擇。

只將「從中文由 Shift 進英文」當作可自動返回的暫時英文片段。啟動時英文、Caps Lock、外殼指定英文、明確 literal lock 與 private／blocked 等仍依既有行為；不把它們推斷成同一類。再次手動切換、換焦點／欄位、游標移動、貼上與明確選擇等如何終止片段，須在 evaluator 契約固定，不能跨應用程式帶狀態。

如果要等完整中文音節甚至詞才決定，就必須說明在這段等待期間的按鍵由誰持有。**只有 shadow detector，卻把首字按鍵全部直接送進應用程式，並不能完整實現自動回中文。** 離線可先研究辨識能力，但不能把「猜到終點」當作已解決輸出。

輸出實驗必須另固定保留 composition／延後送出的上限與顯示行為，測英文延遲與反悔成本；不能任意刪除已提交到應用程式的文字來補救。保留範圍必須覆蓋要測的整段後文，不能先以兩次聲調等早期窗口凍結答案，再宣稱已測長 context。若成本上限使較長任務提早封存，須如實列失敗／覆蓋限制，不排除該列。這是實作可行性與使用體驗的必要證據，不藉此擴成全域 parser 替換。

#### S1 要測的意圖

1. Shift 後輸入英文，再直接打一至多個中文字；包含已知／未知／大寫英文、數字聲母、第一聲空白與明確聲調。
2. Shift 後輸入真正英文、帳號、合成密碼、型號、版本、URL、日期等，整段沒有中文，不能因片段剛好能組字就提早退出英文。
3. 英數識別字完整結束後再接中文；恢復中文時不得侵入識別字，例如把帳號尾碼拿去組首字。
4. 中文起頭含誤按，再接正確中文；分開計首字修正與後續恢復，不把兩件事混算。
5. 相同前綴、後續不同，以及完整觀測相同的相反意圖。逐鍵因果評估：在字詞出現之前不能提前用，但出現之後必須允許重估未提交的前文。完全不可辨識時揭露模式偏好的取捨。
6. 後文強度配對：歧義首音節後分別接能成詞的中文、可支持中文的較長句子、真正 literal 後綴、刻意構造的注音式帳號，以及沒有額外資訊的終止事件。包含單字、短詞及較長組字段，不只測二音節。

每列先記任務意圖、完整英文 span、首個中文 raw offset、可接受讀音／字面與所有 Shift 事件。人工回切的 gold 時刻只能供計分，不能餵給 detector。新 held-out、分組及來源取得遵循 v2；先前已看過的資料只作 development／回歸。

#### 對照、指標與目標

對照一為原版手動英文：沒有第二次 Shift 就保持英文，反映需要補按 Shift／重打的成本；對照二為在正確終點人工 Shift 的 reference，確認相同按鍵經正常中文流程能產生預期輸出。後者是參考上限，不是可部署的自動策略。

實驗策略只新增終點判斷。先固定單一 detector 的可見輸入及規則，再評測；如果比較字／詞證據或不同等待長度，每個變因分開命名與對照，不同時換一套學習器、窗口和解碼器。

##### 必要的後文對照

在同一局部策略、候選生成、詞庫、參數及原鍵上，比較「只按首個歧義音節的資訊選切法，之後不利用後文重估該切法」與「後文逐鍵到達後，利用詞／句 context 重估同一組未提交解釋」。其他差異不能混入。另以配對決策 probe 固定同一 raw prefix 與 label-free 候選，遮蔽／開放後文評分資訊，確認效果確實來自 context；完整策略則各自記錄因果歷史，不用 gold 過去狀態。

每個 checkpoint 輸出候選切法、完整讀音／字面、詞證據、可用 context、可比較的評分與最終選擇，證明資訊有進入決策，而非只放在 log 或只影響同音字。若模型只能在固定讀音內選同音字，不能冒稱它已用 context 比較「帳號原鍵」與「英文＋中文」兩條解釋。既有 neural API 亦不能直接假定可跨讀音／literal 校準。

報後文修好、後文改壞、仍無法區分的 paired groups；中文切點／讀音改善與同一讀音的選字改善分開。沒有額外資訊的 continuation 是負對照，不應憑增加字數就宣稱更有中文證據。

S1 預定品質目標（所有結果前固定；執行前再補完整事件／分母契約）：

- **正確自動回中文：** 至少90%的 intended-return primary groups，在完整任務輸入完畢、Enter 前，已自動從正確邊界組出首字及完整中文讀音。單音節任務在該音節完成時評分，不排除短詞。Enter 只能提交最後顯示，不臨時另選答案。
- **後文確實有用：** 預先以意圖／按鍵結構標記的「首段有歧義、後文提供區別」隊列，使用後文的完整切點／讀音錯誤須相對不用後文下降至少30%，且 literal 最終錯誤不增加；基準零錯誤則要求維持零，不能宣稱量到改善。另報中文字面選字及修好／改壞數。這個門檻與90%整體成功率都要滿足，不能只挑其中一項。
- **最終英文保留：** literal-only 及 return 任務中的 intended 英文 span，完整任務結束時被錯轉／改寫的 incidence 點估與 Wilson two-sided95上限均≤1%；兩類分開報，不用大量容易的 literal 稀釋誤傷。必要作者保留案例全過。中間可逆的暫時顯示另報 any-event incidence、持續鍵數與反覆次數，不與最終錯誤混算，也不因它曾改變就直接否定後文修正。
- **不吞首字、不破壞英文：** 已判對終點的任務必須完整輸出英文與首個中文字；掉鍵、重複、改寫已提交英文、違反明確鎖定皆0。模式切回但首字仍是亂碼算失敗。
- **使用成本與過程：** 在第一音節、第二音節、每個後續完成音節及整段末尾記正確率；成詞 checkpoints 由 gold 事先標記、僅供計分，不傳給策略。報第二次 Shift 省下的比例、仍需手動介入比例、完整按鍵修正成本、首次判對與最後穩定所需鍵數／音節數，以及英文顯示／送出延遲。機械重播的省鍵數不是已完成使用者體驗驗證；可接受送出延遲、反覆與保留容量的數值須在輸出策略定案後、測試前另固定。

正式隊列至少400個獨立 intended-return groups，以及400個 literal-only groups；英文 span 隊列亦須達400個獨立 groups（可與 return 組共享任務，但需固定 primary span）。其中後文有區別的主對照至少100個獨立 groups，並保留刻意注音式帳號與完全不可辨識組，分開披露。數量不足、無法驗證首字 materialization 或輸出延遲規格未定時，不能給產品整合 GO。未知終點猜測不以原版100%未自動返回作巨大相對改善宣傳，直接報絕對成功率與誤判率。

先驗證偵測是否有足夠辨識能力，再驗證在持有原鍵與完整 composition 的條件下能否正確送出。前者單獨通過只支持繼續做輸出驗證；後者與延遲、保留條件也通過，才支持 S1 功能整合。S2 與安裝包另依各自證據決定。

### Source: design/shift-return-protocol-v1.md (lines 1–30)

### Shift 英文後自動回中文：實驗 protocol v1

狀態：事前實驗設計，尚無本實驗品質結果。依[目標文件](/workspace/0c-ime/design/shift-english-auto-return-experiment.md)細化。這是離線局部切點研究，不是替換產品 parser 的規格；輸出持有／原生整合另有明確關卡。舊 mixed-eval-v1 只作開發參考，不更改舊資料或宣稱它已驗證本題。

開跑前補充：[組合與決策順序](/workspace/0c-ime/design/shift-return-combination-order.md)新增EW（B+W），形成4模型×2封存流程；主要方案仍為EC-revise，其他門檻不改。下文的E0/EL/EC主要資訊比較皆指O-revise，O-fixed只作相同模型下的封存對照。

#### 1. 要回答的問題與介入範圍

使用者 Shift 已標示英文起點；檢查英文結束的位置及中文讀音能否隨後文變準。允許在同一未提交組字段內重估前面的英文／中文 ownership，沒有第二聲調截止或一次改判上限。使用者不再按第二次 Shift，也不手動選字。

這輪只處理一次 Shift 英文片段後接一段中文，以及該中文起頭誤按後的恢復。更後面再次轉英文另切成新任務，不假裝已解決多次自動切換。實驗模組只選該片段的 literal／Chinese spans；同音字仍由原有 decoder 產生。一般中文、既有學習、UI、鄰鍵修正與自動進英文不變。

主要假說 H1：相對未使用後文重判的局部判斷，使用後文可將歧義隊列的最終切點／讀音錯誤降低至少30%，並同時達到整體返回成功率90%、最終 literal 誤轉 Wilson95 上限1%的要求。H0 是未達上述聯合條件，不是「後文永遠無用」。

#### 2. 同一任務的對照

| ID | 行為 | 用途 |
| --- | --- | --- |
| M | 真實原版：Shift 進英文後不再切回 | 確認現有行為、省第二次 Shift 的成本；不當成偵測準確率基準 |
| R | 在 gold 終點人工回中文，其餘走原版 | 參考正常解碼上限；gold 僅此組可見，不參與選模 |
| C/A | preview2 的保守／積極混打，獨立 Session 重播相同 raw | 行為對照，揭露現有修正收益與帳號誤傷；不是實際 Shift 自動返回 |
| E0 | 同一局部選擇器，候選初次可辨讀時的資訊固定，不使用後文詞證據重評它 | 主要無後文對照 |
| EL | E0 資訊，加上當時後續音節／未解按鍵的數量，不加入後文內容分數 | 長度負對照 |
| EW | E0 資訊，加上後文字詞分數，不使用長度features | context與長度的組合對照 |
| EC | 同一局部選擇器，後文到達後更新詞與語言證據並重選 | 待驗證的 context 組 |

四個feature模型共用原鍵、候選生成、可見前文、詞庫、decoder、訓練資料、估計器、訓練預算及 margin 清單；feature mask 是資訊比較的唯一研究變因。各自因果重播，不讀 gold past state。模型因可用 features 不同分別按同一程序擬合，不能把係數差異當作某個 feature 的獨立因果效應。

另做不訓練、不選模的配對 probe：每個 raw prefix 的同一組候選及凍結 EC 係數，分別輸入正常 context features 與初次觀測 features。只解釋該 EC 對後文是否敏感，不把這種訓練分布外遮蔽當主要成效。若只 EL 改善、EC 沒有額外優勢，不能稱字詞內容已幫助區分。


### Source: design/shift-return-combination-order.md (lines 1–65)

### 資訊組合與決策順序：開跑前補充設計

狀態：尚未取得新品質結果。此補充將[protocol](/workspace/0c-ime/design/shift-return-protocol-v1.md)的三個資訊對照擴成完整的組合比較，並獨立測決策封存時機；其他資料、每模型訓練預算與品質門檻不變。此處「三種」依前文解讀為首段資訊B、長度L、後文字詞W。

#### 1. 組合不是三選一

B是基礎判斷，始終存在；另外兩個訊號採2×2對照：

| ID | 首段B | 後續長度L | 後文字詞W |
| --- | --- | --- | --- |
| E0 | 有 | 無 | 無 |
| EL | 有 | 有 | 無 |
| EW，新增 | 有 | 無 | 有 |
| EC | 有 | 有 | 有 |

E0/EL/EC原本是逐步加入資訊的組合；新增EW才能回答「context是否需要長度一起用」「長度是否反而干擾context」。沒有獨立的純長度分類器去取代B，也不預設三項全開最好。

主表報每種意圖的final error。分別比較EL−E0、EW−E0、EC−EL及EC−EW，並報修好／改壞paired groups。另報error尺度的交互作用 `I = error(EC) - error(EL) - error(EW) + error(E0)`：負值表示聯用的錯誤下降超過兩個單獨增益相加，正值表示增益重疊或互相干擾。這是指定尺度的描述，不單靠I宣稱因果或統計顯著；同component paired bootstrap區間一起報。

所有組仍用相同candidate generator與訓練程序；EW的L係數固定0。四組同時事前固定，不能看結果才新增缺少的組合。

#### 2. 順序要測的是何時定案

同一prefix、相同features與係數若以同一線性公式共同評分，改變「先算B還是先算W」沒有新的資訊含義。固定float64累加順序避免數值差；不將這種程式計算順序誤當使用情境的順序效果。

真正可能改變結果的是先作選擇後，有沒有讓後續資訊修正它。因此每個模型固定同一份係數與margin，再比較兩個流程，不因流程重新訓練：

| 流程 | 第一個可判斷時點 | 後文到達後 |
| --- | --- | --- |
| O-fixed：先選後封存 | 使用已出現資訊選暫時答案，並封存已處理bytes的ownership／reading | 只能在相容路徑上延伸；不能重切封存部分 |
| O-revise：先暫選、後文可回修 | 使用同一資訊選暫時答案，不封存 | 重新比較全部未手選鎖定的解釋，可改前面的切點／reading |

O-fixed的封存時點固定為Shift後第一次存在完整exact spelling首音節候選的key事件；不按gold中文起點、模型信心或未來是否成詞選時點。若選literal，就將此時已顯示bytes視為literal封存；若只支持prefix而未能顯示完成中文字，也不能假裝已完成。沒有這類事件的任務全程literal。只封存一次；後續同音字字面仍可由decoder更新，不改先前reading／ownership。

封存是離線流程對照，不等於真的把字送進應用程式。兩流程仍生成同一套未刪候選，O-fixed在選擇層篩選與封存projection相容的候選，獨立記錄「存在但被封存排除」；若沒有相容延伸，保留舊顯示並原鍵附加，記fallback，所有錯誤照算。搜尋recall不能用O-fixed的篩選後集合冒充generator能力。

實際按鍵順序完全相同，不能把未來context搬到前面。英文模式、privacy、明確手選／literal lock等硬約束兩流程皆先遵守；這不是研究是否可以讓context越過使用者明確選擇。

#### 3. 事前固定的實驗矩陣

四種feature模型×兩種流程，共8個replay conditions。只有4份模型；各模型margin依原固定dev程序在O-revise上選好，再不變地套到兩流程。流程對照不是8次模型搜尋。每個condition的final test只跑一次，所有結果都報。

| | O-fixed | O-revise |
| --- | --- | --- |
| E0 | E0-fixed | E0-revise |
| EL | EL-fixed | EL-revise |
| EW | EW-fixed | EW-revise |
| EC | EC-fixed | EC-revise |

資訊組合效果在同一O-revise下比較；決策封存效果在同一模型下比較。再報EC的回修增益與E0的回修增益之差，檢查context是否特別需要保留重判空間。不能拿EC-revise對E0-fixed的差值，全部歸因於context。

主要待驗證方案仍固定為EC-revise，沿用原G0–G5門檻，不在test後挑8組中最高分當主方案。EW若更好，構成減少長度訊號的下一版假說；保留本次完整證據，不能改主方案名義宣稱本次通過。EW-revise亦報同門檻成績以供評估，但事後改用它需新的確認實驗。

不是要求所有對照都達到EC的成效門檻：G0／共同generator的G1及執行安全G5必須有效；G2–G4以指定EC-revise及其必要paired比較判定。對照組因無context或早封存而品質較差，本身就是待觀測結果，不能據此宣布整個實驗工具失效。

#### 4. 預先定義怎麼解讀

- EC優於EL且EW也優於E0：有支持後文字詞內容的證據。
- EL改善、EC沒有優於EL：可能只是長度線索，尚未支持詞內容有效。
- EW優於EC：L可能與W重疊、造成偏差；不能假定資訊越多越好。
- 同一模型O-revise優於O-fixed：過早封存會阻止恢復；另看暫時誤轉、反覆與穩定延遲的成本。
- context只在O-revise有效：須把「保留未提交替代解釋」列為該方法必要條件，不能只換評分卻沿用原來的早期定案。
- 中文改善但literal超標：組合或順序仍未解決意圖取捨；任何一種都不能只摘中文成功率。

本補充只更改事前設計，沒有新模型、資料、品質結果或產品行為變更。若之後要測「先由格式規則阻擋，還是先讓context提出替代」等soft-rule優先序，必須另列具體非交換分支與獨立對照，不能從這次封存實驗推論全部規則排列。

### Source: design/shift-return-worked-scoring.md (lines 1–36)

### Shift-return 計分演練（假設輸出，非實驗結果）

本文件用來檢查[protocol](/workspace/0c-ime/design/shift-return-protocol-v1.md)是否會獎勵正確行為、懲罰誤傷。下列選擇全部是假設，不是程式實跑成績；不能算進正式資料。

每列的完整任務從中文模式開始，先按Shift，再逐鍵輸入raw，最後Enter。E0不以後文更新切點證據；EC使用後文。策略看不到「意圖」欄。所有同一raw的列有相同可見設定／前文，不能假裝系統可以同時猜對。

| 任務 | raw | 欲輸出 | E0假設最終顯示 | EC假設最終顯示 |
| --- | --- | --- | --- | --- |
| a，中文 | `microsoft593vul3` | microsoft窄小 | `microsoft593vul3` | microsoft窄小 |
| b，注音式帳號 | `microsoft593vul3` | `microsoft593vul3` | `microsoft593vul3` | microsoft窄小 |
| c，中文 | `WQ5j04fu06` | WQ賺錢 | WQ賺錢 | WQ賺錢 |
| d，型號 | `gpt4` | `gpt4` | `gpt4` | `gpt4` |

假設EL和E0同結果。a/b同一collision component，c/d各一component。a/b不能拆train/test，也不能因中文詞籍存在就刪掉b。

#### 逐鍵怎麼看a

| raw prefix | EC暫時顯示 | 計分解釋 |
| --- | --- | --- |
| `microsoft593` | `microsoft593` | 此時仍有兩種意圖，不要求永久定案；記首音節尚未成功 |
| `microsoft593v` | `microsoft593v` | 後字未完成，不能偷用未來的`ul3` |
| `microsoft593vul3` | microsoft窄小 | 後文到達後自動修好，記context repair、最終成功；仍需記恢復花了4鍵 |
| Enter | commit=microsoft窄小 | 必須等於上一個顯示，Enter不能再換另一個答案 |

同一份EC在b也會顯示「microsoft窄小」，因此b是最終literal誤轉。即使這是一個正常中文字詞，也不能當帳號任務的成功。這正是要測的取捨。

#### 這四列的手算

- return意圖a/c：E0錯1/2，EC錯0/2，錯誤下降100%；a是淨修好，c維持正確。
- literal-only意圖b/d：E0錯0/2，EC錯1/2。即使中文看起來有進步，仍不通過literal限制；樣本2也完全不具正式資格。
- a/b完整觀測相同且兩意圖等權，對該component最多同時命中1/2；若改為全保留literal，只會把成功與失敗交換，不是解決歧義。
- a中途literal後自動組中文，不能算最終失敗；若a在第二音節曾顯示正確、後來變回literal而最後仍錯，則算最終失敗。
- 假如cut/readings正確但字面是「microsoft窄筱」（小／筱同讀音），意圖／讀音項可成功，整段字面項失敗；不得把兩項混為一個90%成功率。
- 若EC直到Enter才從literal改中文，即使commit看似正確，亦違反Enter不得排名的條件；若首字raw早已送入應用程式、只能轉後一字，不能拿shadow預測當輸出成功。

正式報告須同時提供return、literal、英文span保留、context修好／改壞、讀音及字面的分母與結果。這份演練說明為何不能只選a這類改善案例，也不能要求所有早期暫時顯示一次就猜中。

## Detailed Implementation Plan

### Source: design/shift-return-protocol-v1.md (lines 31–129)

版本：M/R/C/A 的來源固定 preview2 `e754019571573051d8c29e06526802c31d5172e2`。上游 `v0.2.7` 可另報歷史行為，不與主要 context 對照混算。詞庫及系統統計模型使用當前公開 `assets/data`，實際 manifests、英文詞庫和工具鏈 hashes 在執行前寫入 lock。禁用 neighbor/fuzzy/autocomplete/neural；既有 neural API 沒有跨 literal／讀音校準能力，本輪不假設它具備。

#### 3. 實驗的觀測與候選契約

- 策略只收到 Shift 事件、已發生的 raw key prefix、已確認且允許使用的左文、layout、設定與明確鎖定。不收到 intended span、gold checkpoint、任務類別、paired ID 或未來按鍵。
- 起點是實際 Shift，不是 fixture 人工指定的正確中文起點。標準 layout，ASCII 實體字元，明確3/4/6/7與第一聲空白均包含；每列使用真正鍵值，不對錯字自動補鍵。
- 全 literal 解釋永遠保留。對每個可行 offset 枚舉 `literal prefix + exact Chinese suffix`；先前錯誤按鍵可包含在 literal prefix。中文以 standard exact spelling 解析，首音節須有完整讀音及詞庫exact或合法prefix支持；prefix-only可保留待續，不能當完成中文字。完整中文輸出須有exact word coverage，不能因某音節只能出現在詞中就提前丟棄。
- 中文候選保留完整有序讀音、每個 byte 的半開區間 ownership、完成／未完成狀態及原鍵。後續非完整音節先作可還原 pending tail；不能因下一字未完成就丟掉首字的另一解釋。中文之後再次含無法解釋的 raw tail 須明列，最終完整讀音計分不能忽略它。
- 同音字不擴成不同 boundary 候選；交給既有 decoder。在相同 boundary 下出現的字面變更與跨 boundary 變更分別記錄。literal branch 不使用中文字數或 LM 分數冒充可比較機率。
- 研究容量固定每片段512 raw bytes、最多256個 boundary hypotheses；不以音節次數關閉。先依 offset 升序、canonical reading UTF8 排序截取，literal 另保留；不按 gold／結果剪枝。若來源排列存在更多解析，排序規則同上，須記 uncapped/capped 差異。overflow 時記覆蓋失敗，保留全部原鍵作 literal fallback，不從分母移除。
- 首字 offset 的所有未鎖候選可在後續每一完成音節／聲調與每一新可見字元重估；未完成尾鍵可更新暫時顯示，但不使用未完成詞當完成詞。Enter 不作最後一次額外排名，只提交最後可見結果。手選／明確 literal lock 封存該區，不能跨越改判。
- 禁用日常 user store；每列 disposable store，假設路徑只有 immutable inputs／read-only scoring，不透過 Session 反覆試打。從 Shift 進英文的實驗 eligibility 與 generic English mode 分開，不能為了跑候選取消 private／paused／blocked 保護。

舊 generator 有64-byte／兩音節與不支援空白的限制，舊 Machine 有 early freeze，不能直接套用。可重用 SpellExact、read-only decoder 與 guard parity 工具，需新增獨立版本及測試。不能修改舊 lock 以冒充同一實驗。

#### 4. 最小局部選擇器：只研究資訊，不重建全域模型

採同一個 conditional linear ranker 比較該片段的 boundary hypotheses。它不接管片段外的中文，不替換 normal decoder。這是本輪固定的探針；若失敗，只能否定這個探針在此資料／條件下的表現，不否定所有 context 方法。

固定 feature groups：

| 組 | features（每項獨立） | 定義 |
| --- | --- | --- |
| B，初次資訊 | literal flag、英文 prefix exact membership、prefix 含數字、prefix 含非字母數字、prefix numberLike、原保守建議等價 flag、原積極建議等價 flag、首完整音節 exact statistical log score、該分數缺值 flag | 在該 first-boundary／first-reading 初次完整出現的 raw prefix 上取得後固定；literal 首分數為0、缺值flag=1。prefix 比較保留大小寫原文，英文詞籍依原 helper 規則 |
| L，長度 | 後續完成音節數、未解 tail byte 數 | 每個 checkpoint 更新；literal 候選兩值皆0 |
| W，詞內容 | 起於第一中文音節的最長 exact word 音節數、全完成中文路徑中可由≥2音節 exact words覆蓋的最大音節比例、完整解碼 mean log score、完整解碼缺值flag | 最長詞含單字=1；沒有完成路徑則0。coverage 以不重疊動態規劃求最大值，單字不增加分子。score 用現有 decoder 的完整讀音 Best、prefix=false，除已完成音節數；不將 prefix-only score 混入 |

E0 用 B，EL 用 B+L，EW 用 B+W，EC 用 B+L+W；unused coefficients 強制0。W 只提供可學習的證據，不先設定「有詞一定中文」。原作者 heuristics 的逐項命中另作 audit 輸出，不事後新增特徵。hard modes／lock／privacy 不交給模型投票。

B的snapshot key固定為`(first Chinese byte offset, first exact reading)`，literal另用固定key。時間是首音節按鍵首次完整的prefix，即使當時只有詞庫prefix支持也先記missing／guard資訊；不能等後面成詞後才建立B，否則E0會偷看到後文。後續讀音延伸共用該B；四組共用每個checkpoint的label-free候選，不能只替EC保存正解。同一O-revise下不提前封存E0原鍵；O-fixed的額外封存依補充設計獨立比較。

Decoder 初始 left context 只用當時可確認的中文左文；literal prefix 重設中文延續到 BOS，suffix 內完整解碼使用原統計模型，故後續字詞可改變先前字面與整條 reading 的分數。系統詞庫、LM 與 decoder options 要寫入每個 run。詞組／統計 context 與句子語意理解不同；本輪不宣稱測到了神經語意模型的能力。

實作前須將 B 的保守／積極建議與初次 score adapter 對應至具體 helper、固定來源與輸入欄位，做 parity；若任一項無法可靠投影，停止而非換成近似值。此 source map、derived-feature worked vectors、可讀報表 schema 是 code freeze 的必要產物。

#### 5. 擬合與 dev 選擇，結果前固定

四個模型都使用相同 train primary 的完整觀測 checkpoints：每個完成音節及最後一個 key，重複 checkpoint 去重。gold 只作訓練 label，先投影到當時 prefix，不要求未輸入音節出現；未輸入到 intended boundary 前的正解是literal pending。錯誤候選依canonical identity全列，不抽容易negatives。

目標為 pairwise logistic loss：gold與每個negative的feature差。各 intent、group、row、checkpoint、negative 逐級等權；同一equivalence group的互斥意圖都保留，不當成資料錯誤刪除。gold 不在候選者不能製造 gold candidate：訓練該 checkpoint 不產生pair並記錄，評測仍算失敗。所有無競爭候選列仍計評測分母。

訓練設定：float64、zero init、1000 full-batch gradient steps、learning rate0.05、L2=0.001、無early stopping、無額外模型搜尋。各連續feature以train primary candidate observations的mean/std標準化；std=0時輸出0，missing score先置0並另旗標。標準化統計只存train，四模型共用對應欄位的統計。固定canonical排序，單執行緒數值庫與實際版本入lock；不使用test調整預算。報loss與gradient，沒有收斂不能泛稱線性模型失敗。

literal score作比較基準；對最高分Chinese candidate，只有 `scoreChinese-scoreLiteral > margin` 才顯示中文。其餘literal。同分先literal，再first offset升序、canonical identity升序；沒有額外黏住前次答案的margin。這允許context到達後重新選擇，不加第二個穩定門檻。

四模型各自只從固定margin清單 `[0,0.1,0.25,0.5,1,2,4,8]` 選擇。dev先取literal-final點估≤1%且return成功≥90%的候選，再依return成功率高、literal錯誤低、margin小排序；若無可行候選，按literal錯誤低、return成功率高、margin小選一個作負結果測試，清楚標記dev未達標。不得因test選另一個。正式literal區間門檻仍以test判，不以dev點估代替。

code／資料／features凍結後才fit；數值模型、標準化與dev選擇紀錄提交後，四模型×兩流程的final replay各跑一次。O-fixed沿用O-revise選定的相同margin，不另選模。重算既有raw metrics不是新選模；修bug使受影響結果失效，見過的test不再作新方法未見資料。

#### 6. 資料取得與資格

固定取得預算為最多3000個 return 原型與3000個 literal 原型，另最多500個正常中文／模式／提交回歸原型。取得階段只可做結構／詞籍／數量驗證，不讀策略輸出。來源限公開且可引用內容或人工指定任務；每個中文字面與literal意圖先有來源／標註者記錄，不以decoder答案當gold。禁止實際密碼與私人trace。

Return涵蓋已知／未知／大寫英文、英數識別字後中文、數字聲母、誤按後恢復。literal涵蓋一般英文、帳號、刻意注音式帳號、型號版本、日期時間小數、URL路徑、識別字與隨機英數。每組含單字、2–4音節短詞、5–16音節段落、17–64音節長段的預先分層任務；字串超過研究容量仍保留。第一聲空白至少占return primary的20%。

對同一歧義首段建立後文配對：成詞中文、較長中文、正常literal、注音式literal、立即結束。配對是同一group，不能充獨立樣本。gold「後文有區別」須由欲輸出spans與前綴碰撞結構在看結果前標記，不按EC是否修好選列；詞籍驗證只記metadata，不決定意圖。

Families至少包含原英文prefix、中文詞／句原型、literal原型、模板實例／來源群、已知別名與相同可觀測條件的collision。共享任一family transitive union。廣泛coverage類別不是template family；同一真實固定模板不得拆。固定hash split：`SHA256("shift-return-v1:" + JSON(sorted_component_ids))`視為大端整數，JSON使用UTF8、無空白、ensure_ascii=false；mod10為0–5 train、6–7 dev、8–9 test。各group每種意圖各選一個primary，先按source priority（人工已驗證、公開已驗證、synthetic）、再id字典序固定；不因只選一列而丟掉相反意圖。同意圖的其他列作variants。

正式test至少400 return groups、400 literal-only groups、400 intended-English primary spans（可來自return）；每個主coverage類至少20 groups，context-contrast隊列至少100 groups。train/dev各至少100 return與100literal groups。數量不足不改seed／拆群；未讀品質前可按事前來源預算完成取得，但不在看結果後補到CI過關。最終資料、aliases、group、primary、split與標註exceptions全凍結。

v1及已在對話／既有測試出現的案例作development／mandatory，不算未見test。`microsoft593`及其相反意圖必須保留作碰撞示範。完全相同觀測而不同意圖的列都評分：先每意圖等權，再group平均；這種group的max可達分依標籤計算並明列，不能把兩答案皆算正確。

#### 7. 計分與事前判定

所有primary品質先列各意圖逐group成績及paired counts，不報一個混合總分。對一個group的同意圖primary，完整span任何一處失敗即該項失敗；額外variants另報worst-case，不混入主分母。相反意圖的collision列各自進相應分母，保持同split且CI依component，不當兩個獨立group。

| Gate | 主指標與通過要求 |
| --- | --- |
| G0 工具／資料資格 | source parity、完整prelude至Enter、raw ownership、gold validity、split、資料數量全部通過；gold／ownership缺失不能填零 |
| G1 搜尋可行性 | test gold完整partition/readings在capped set ≥99%；mandatory正解全部存活；uncapped、單字／長段與overflow另報。未通過先停止fit |
| G2 返回 | EC final key後、Enter前完整首boundary及完成讀音成功≥90%；沒有手動選字。錯同音字另報，不掩蓋完整字面任務成功率 |
| G3 後文內容有效 | 預定context-contrast隊列EC錯誤相對E0下降≥30%，並且EC較EL的淨修好group數>0；三者同literal風險限制下比較。E0零錯時要求EC零錯，標無可量測改善。報paired修好／改壞與group bootstrap95區間，不把點估改善當顯著性證明 |
| G4 保留literal | EC literal-only與return英文span的最終誤轉，各自點估與two-sided Wilson95上限≤1%；EC比E0、EL不增加最終literal錯誤；必要作者保留案例全過 |
| G5 不破壞 | zero丟鍵／重複／跨手選鎖定／改寫已提交文字；Enter逐字等於最後顯示；假設學習／持久化0；private／paused／blocked實驗呼叫0；正常中文回歸零新增失敗 |

Literal錯誤包括字母大小寫／標點改寫及英文尾碼被借入中文；不能只看是否出現漢字。return成功要求全部應完成讀音，不只首offset；pending tail未完成與本來任務要完成但未完成分開。字面gold在所有正式primary必備，報同音字錯誤與整段字面成功率；現階段G2主門檻只評意圖／讀音，字面並非可以省略的證據。

Bootstrap使用component作單位、10000次、固定seed `271828`，paired重抽保持四模型及兩流程同group；不得拆collision。在純獨立primary incidence分母使用Wilson（z=1.959963984540054）；若同group有多個英文primary span則先合成任一錯誤，不當獨立span做Wilson。零分母是null。

過程診斷：第一完成音節、第二音節、每個後續完成音節、gold詞末、final key各記cut/readings/surface；詞末只供評分。報首次正確、最後穩定、context修好／改壞、暫時literal誤轉的持續鍵數、boundary反覆數。**中途錯但自動修好不算final失敗；中途對最後改壞算失敗。** 一旦錯誤被送入應用程式則屬G5，不是可逆暫時顯示。

#### 8. 能下什麼結論

- **GO_OUTPUT_EXPERIMENT：** G0–G5全過，支持局部context方法，才做原鍵持有／完整composition的輸出驗證；不是產品或安裝包GO。
- **NO_GO_METHOD：** 有效比較未達G1–G5任一必要門檻。依搜尋缺失、評分選錯、context只改同音字、長度效應或不可辨識取捨分析；不由單一估計器宣稱context無用。
- **INCONCLUSIVE：** 必要工具、資料、paired metric／gold不可用或洩漏，停止品質宣稱。已可用負證據照報，不改稱通過。

若EC與E0相同，先檢查feature actually consumed及候選存活；若有字面改善但切點不改善，結論是context幫到選字但尚未解決中英意圖。若成詞中文改善而注音式帳號誤傷，結論是先驗取捨未解，不是成功辨認使用者意圖。

輸出階段再量英文即時顯示／送出延遲、整段反覆與機器延遲，於該階段開跑前另固定UX門檻。辨識期採虛擬未提交composition，不聲稱實際英文直通已可回收；512-byte容量也不是推薦產品等待長度。原生Windows TSF、跨欄位、手動反悔與效能未驗證之前不出新安裝包。

#### 9. 預定產物與開始順序

新增獨立 `shiftreturneval` 實驗版本，不能原地修改舊mixed-eval-v1；具體package／CLI需在code freeze manifest列齊。產物為schema與範例、source map、候選／worked feature vectors、資料取得manifest／family assignment、run lock、train設定、四個模型及dev選擇、八個conditions的逐鍵rows／candidates／events、gate report與錯誤分類。

先實作並驗證工具→凍結資料與code→做候選召回→按本規格fit/dev→凍結數值模型→一次final test→主agent獨立重算。任何新模型、feature、窗口或門檻變更先版本化；已看過test轉為回歸，不再當未見資料。

本次僅完成protocol與[手算計分例](/workspace/0c-ime/design/shift-return-worked-scoring.md)，沒有收新測試資料、實作選擇器、訓練或評測。實作前的source-map parity與schema是必做產物，不可跳過後宣稱本文件等於已跑實驗。

