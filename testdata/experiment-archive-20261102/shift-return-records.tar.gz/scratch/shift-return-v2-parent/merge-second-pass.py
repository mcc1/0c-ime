from pathlib import Path
import json,hashlib,sys
r=Path('/workspace/scratch/shift-return-v2/acquisition-v1')
def enc(x):return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def sha(x):return hashlib.sha256(x).hexdigest()
authored={}
for path in sorted(r.glob('bank-pending-*.jsonl')):
 for line in path.read_text().splitlines():
  task=json.loads(line);assert task['id'] not in authored;authored[task['id']]=task
for number in sys.argv[1:]:
 path=r/'second-pass'/f'review-{number}.second-ai.jsonl'
 second=[json.loads(x) for x in path.read_text().splitlines()]
 accepted=[];disputes=[]
 for s in second:
  task=authored[s['id']]
  assert len(task['annotations'])==1
  h=sha(enc({k:task[k] for k in ('intent','raw','gold')}))
  if not (s['accepted'] and s['reading_verified'] and s['inferred_intent']==task['intent'] and s['labels_sha256']==h==task['annotations'][0]['labels_sha256']):
   disputes.append({'id':task['id'],'second':s,'first_labels_sha256':h});continue
  assert s['annotator_id']!=task['annotations'][0]['annotator_id']
  task['annotations'].append(dict(annotator_id=s['annotator_id'],intent=s['inferred_intent'],reading_verified=True,accepted=True,labels_sha256=h,adjudication_ref=''))
  accepted.append(task)
 out=r/'parent-accepted'/f'bank-accepted-review{number}.jsonl'
 with out.open('xb') as f:
  for t in accepted:f.write(enc(t)+b'\n')
 decision={'packet':number,'second_evidence':str(path),'second_evidence_sha256':sha(path.read_bytes()),'accepted':len(accepted),'disputes':disputes,'bank_sha256':sha(out.read_bytes()),'alias_decisions':'separate parent alias overlay; final closure mandatory','quality_run':False}
 with out.with_suffix('.adjudication.json').open('xb') as f:f.write(enc(decision)+b'\n')
 print(json.dumps({'packet':number,'accepted':len(accepted),'disputes':len(disputes),'sha256':decision['bank_sha256']}))
