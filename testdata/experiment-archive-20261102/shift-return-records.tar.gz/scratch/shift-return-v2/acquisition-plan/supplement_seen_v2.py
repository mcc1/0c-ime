#!/usr/bin/env python3
"""Conservative seen-only inventory. Reads source tests/designs and old inputs, never scores/results."""
from pathlib import Path
import hashlib,json,re,unicodedata
root=Path('/workspace/0c-ime')
parent=Path('/workspace/scratch/shift-return-v2-parent/seen-draft.json')
base=json.loads(parent.read_text())
sets={k:set(base[k]) for k in ('seen_prefixes','seen_contents','seen_raw')}
files=sorted([*root.glob('core/**/*_test.go'),*root.glob('internal/**/*_test.go'),*root.glob('cmd/**/*_test.go')])
files += [root/'testdata/mixed-boundary/fixtures.jsonl',root/'design/mixed-input-experiment/examples.jsonl',root/'design/shift-return-v2/examples.jsonl',root/'design/shift-return-v2/metadata-fixtures.jsonl',root/'design/shift-return-v2/bank-example.json',root/'design/shift-return-protocol-v1.md',root/'design/shift-return-protocol-v2.md',root/'design/shift-return-source-map-v2.md',root/'design/shift-english-auto-return-experiment.md']
files += list(root.glob('internal/shiftreturn/test_*.py'))
files=list(dict.fromkeys(files))
for path in files:
 text=path.read_text()
 # This deliberately over-excludes source-test strings/comments; it never marks
 # a test/source token as genuinely new merely because it is not a scored row.
 for value in re.findall(r'"((?:[^"\\]|\\.)*)"',text):
  try:value=json.loads('"'+value+'"')
  except (ValueError,TypeError):continue
  if value and len(value)<=512 and all(' '<=c<='~' for c in value):
   sets['seen_raw'].add(value)
   if re.fullmatch(r'[A-Za-z][A-Za-z0-9_.:/+\-]{0,127}',value):sets['seen_prefixes'].add(value.lower())
  prefix=re.match(r'[A-Za-z][A-Za-z0-9_.:/+\-]*',value)
  if prefix:sets['seen_prefixes'].add(prefix.group().lower())
 for value in re.findall(r'[\u3400-\u4dbf\u4e00-\u9fff]+',text):sets['seen_contents'].add(unicodedata.normalize('NFC',value))
 for value in re.findall(r'[ㄅ-ㄩ][ㄅ-ㄩˊˇˋ˙]*(?:[ \t]+[ㄅ-ㄩ][ㄅ-ㄩˊˇˋ˙]*)*',text):sets['seen_contents'].add(' '.join(value.split()))
 if path.suffix=='.jsonl':
  for line in text.splitlines():
   f=json.loads(line)
   for family in f.get('families',[]):
    if family.startswith('prefix:'):sets['seen_prefixes'].add(family[7:].lower())
    if family.startswith('word:'):sets['seen_contents'].add(unicodedata.normalize('NFC',family[5:]))
   raw=''.join(e.get('key','') for e in f.get('events',[]) if e.get('type')=='key')
   if raw:sets['seen_raw'].add(raw)
   for assertion in f.get('assertions',[]):
    for accepted in assertion.get('accepted',[]):
     readings=[s.get('reading','') for s in accepted if s.get('kind')=='chinese']
     if readings:sets['seen_contents'].add(' '.join(' '.join(readings).split()))
sets['seen_raw'].update(['A'*129,'A'*512,'x'+'593'*17,'x'+'593'*64])
sets['seen_contents'].update([' '.join(['ㄓㄞˇ']*17),' '.join(['ㄓㄞˇ']*64),'窄'*17,'窄'*64])
result={k:sorted(v) for k,v in sets.items()}
result['purpose']='Conservative supplemental seen input; not qualified Sources/bank. Both annotators must retain AI identity. No quality files read.'
result['source_files']={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in [parent,*files]}
output=Path(__file__).with_name('seen-supplement-v2.json')
with output.open('x') as f:json.dump(result,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print({k:len(v) for k,v in sets.items()});print('read-only input/test/design files:',len(files))
