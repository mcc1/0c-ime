# P3 boundary: BLOCKED_CONTRACT; overall INCONCLUSIVE

No formal bank, source/data/numeric run lock, enumeration quality, model fitting, dev selection, held-out replay, installer or product integration was created or run. No worktree, commit or push was made by this worker. Parent owns the next adjudication and all freezes. The current HEAD is acc4a7e33787fec55bce1d633852c883a117152e (parent P0/P1 tool checkpoint); contract source is c512578157607615ed114feba20c8a443f260a19 and historical product baseline e754019571573051d8c29e06526802c31d5172e2.

## Blocking counterexample

Frozen protocol line138 says `x593v3` has invalid `v3`, n=1,k=1 with pending `v3`. Required API `mixedparse.SpellExact("v",layout.Standard.Symbol('3'))` actually returns `ㄒˇ,true`. `zhuyin.Valid` checks class order, not Mandarin phonotactics. Following that API gives n=2,k=1,L7=1,L8=0; the table expects n=1,k=1,L7=0,L8=2. Both render x窄v3 because k=1 leaves the same raw tail.

`TestCandidateWorkedAndFeatures` retains the frozen table expectation and fails. The exact API result is printed in tagged-tests.log. No phonotactic guard was silently added; no core, old mixedparse/mixedeval, schema or protocol was edited. `vv3` would be genuinely invalid under the present API, but changing a worked example or method is parent adjudication, not an implemented repair. G0 cannot pass until this is resolved and the full suite passes.

## Checks actually executed

`check-status.json` and separate logs record:

- Full tagged package/CLI tests, fresh count1, with fixed public inventory/parity/20-case calibration: exit1, solely the worked-v3 mismatch. All other tests ran and passed.
- Tagged package/CLI vet: exit0.
- Python numerical worked verification and two byte-identical tiny fits: exit0. These are analytic toys, not formal model fits.
- Eight Python weighting/numerical contracts: exit0, including multi-gold negatives, no-pair redistribution, component/checkpoint weighting, empty/over-budget pair rejection, masks and plain sequential sums.
- Design example checker: exit0; it is not a substitute for full SpellExact API agreement.
- Public-tree checker and diff check: exit0.
- Normal `go test ./...` and `go vet ./...`: exit0 earlier in this P3 turn; normal-checks.json records the actual execution sessions, not invented raw stdout. Production source remained unchanged.

The worker only used activated Go1.26.10/Python3.12.14/NumPy2.3.5/jsonschema4.26.0, GOMAXPROCS4/GOFLAGS-p4 and dedicated GOCACHE. Environment/tool hashes and actual resource snapshot are in environment.json. Source hashes cover39implementation/readme files; manifest SHA256 is a791048333496a4b54fbf7025eef357a24855ed33cefdabb99d84125925f797e. Public assets were read-only and their original byte hashes are in public-data-hashes.json.

## Implemented review surface

P0: strict reviewed-schema decoding with typed-kind and duplicate-key rejection; semantic events/spans/SpellExact labels; canonical assignment, primary metadata and whole-component seen exclusion; create-only CLI. P0 parent findings for wrong-kind decoding and literal backslash-u2028/u2029 canonical encoding were repaired and independently checked by parent.

Assignment now derives exact return-prefix/content/readings, full literal token and identical raw dependencies in addition to provided family/prototype/observable links. Known family values participate in seen matching, including literal tasks' declared prefixes and content embedded in longer tasks. NFC uses pinned Python; reading whitespace/case is normalized for matching without changing the seen-file hash contract. Independent Python assignment agrees. This realizes existing dependency criteria; it is not a new split seed or post-quality grouping change.

P1: exact cut enumeration, canonical256Chinese cap plus literal, uncapped IDs and resource diagnostics; original model Source with Layered/Long preserved; B snapshots, L/W DP and shared W/render decode; strict margin/ties; revise/fixed/explicit locks; lifecycle Close/handoff and hard gates. Explicit surface locks differ from fixed reading locks. Ordinary newly completed spans do not count as revisions; prior pending-to-Chinese resolution is separate. Homophone surface changes are separately diagnosed. The source API's -Inf exact paths retain their real text and set missing flags; only genuinely empty complete surfaces fail closed.

P2: real disposable M/R/C/A Sessions, correct Toggle/R control and application ledger including first-tone space and unhandled ASCII; observer-on/off Snapshot/store parity; separate nonlearning scoring store; private zero experiment calls. Current source differs from historical e754019 only through pre-existing helper files and the old nil observer hook; this worker made no production/old-evaluator changes. Normal-mode/private/custom-token/neutral-source/prelude cases are checked. RunEpisode replays the original prelude and rejects expected_prelude that differs from actual composition, instead of injecting gold output.

P3: fit/select, strict immutable file/tool locks and ancestry, full CPython-compatible bootstrap, source/bank/annotation/category/context/primary qualification, grade joins, reports, independent Python dictionary/reducer, runner/CLI, external training label builder, create-only evidence streams, source parity/calibration and aggregate retained-evidence limits. Enumeration has zero linear scores; data labels are built only after queries. Every model uses the prescribed fixed masks and1000full-batch updates. CPython3.12 compensated sum is explicitly avoided: [1e16,1,-1e16] has ordered mean0, not1/3. Model dev-margin copies are canonical Python output; selection has no test option.

Go and independent Python agree on a toy full eight-condition bundle, all10paired entries, six derived entries, query recall distinctions, primary/variant categories, strict selection, temporal counts, fixed-EC first-W sensitivity and separate homophone diagnostics. Tampered query/generator/row metadata is rejected. Sparse bootstrap reproduces3165baseline-zero replicates,10000valid draws and CI[0,.75]. No-pair rows remain in coverage. Unsupported rows retain full component n; rates/CIs are null and diagnostics disclose the conservative unavailable failure charge. Unrun safety is null/not_run, never zero. The fitter requires frozen successful enumeration completion metadata, so an exhausted episode cannot be hidden behind99%recall.

## Actual resource/data evidence

Fixed 20-case calibration is fully retained in tagged-tests.log. The193-byte x+593*64 case hits exactly250000logical lex queries after105performed generations and3571Best calls, then retains raw and resource_exhausted. The52-byte17-syllable case completes23734lex/884Best calls. These are operational negatives, not natural quality. They must not be fixed by deleting hard rows or reducing limits.

Actual free bytes10383925248 are below the unchanged10GiB floor10737418240. No cache/evidence deletion was attempted. Cgroup limits are32GiB RAM and4CPU. Capacity worksheet accounts separately for shared enumeration, four actual baseline passes, four fits,32dev passes, eight final conditions and reduction; actual frozen-row byte/memory totals remain unavailable. Current reducers keep decoded evidence in memory, so compressed size alone is not proof of memory feasibility.

Latest seen supplement is acquisition-plan/seen-supplement-v3.json, with397input/test/design source-file hashes; earlier versions remain. Source supply after it is525single-reading families and79369known English prefixes, not independent acquired tasks. No second AI annotation identity or acceptance was invented. acquisition-plan.md states budgets, family losses, proposed pre-quality contrast allocation and blind second-pass procedure. Source/data qualification still requires an actual bank/closure/primary split and parent review, not these inventory counts.

## Parent decisions still needed before freeze

1. Resolve the exact v3 API/worked-table contradiction while respecting the user's no-silent-method-change rule; keep its negative evidence.
2. Confirm immutable initial source lock -> fit lock -> later execution/evidence lock transport. Models reference initial source/fit file hashes; later locks hash selected models/evidence. A metadata-only descendant commit does not change frozen source bytes. No circular lock rewrite is used.
3. Confirm zero-based research-key ordinal for first_correct/last_stable; schema separately exposes event_index and key_offset but the prose only says key index.
4. Review locked-display preservation versus raw/literal fallback wording on resource failure; original raw remains retained and scoring stops.
5. Confirm the incomplete-metric representation: full n, disclosed failure charge in integer errors, null rates/intervals, unavailable paired/derived intervals. This avoids shrinking hard-case denominators but requires explicit interpretation of a schema whose errors field is nonnullable.

After those decisions: rerun complete checks, review code/tests, freeze source, acquire/blind-annotate data within fixed budgets, verify actual resource/data qualification, then release the formal phases sequentially. No current artifact supports GO_OUTPUT_EXPERIMENT or a quality NO_GO_METHOD.
