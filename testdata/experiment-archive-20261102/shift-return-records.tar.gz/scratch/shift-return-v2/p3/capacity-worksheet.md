# Capacity qualification: not yet passed

No formal dataset or quality run exists. The fixed 20-case calibration is in `tagged-tests.log`; `environment.json` records actual resources. Limits remain512raw bytes,256kept Chinese hypotheses,250000direct logical lex queries and100000Best requests per episode,2000000pairs per model/step,8GiB aggregate retained raw evidence, and10GiB free preflight. No old evidence was deleted.

Measured fixed cases:

| Input | Raw bytes | Generation performed | Direct lex requests | Best requests | Result |
| --- | ---: | ---: | ---: | ---: | --- |
| x +593 repeated17 |52|52|23734|884|ok |
| x +593 repeated64 |193|105|250000|3571|resource_exhausted |
| A repeated129 |129|129|0|0|ok |
| A repeated512 |512|512|0|0|ok |

The64-syllable case stops generation after105actual generated checkpoints; subsequent query attempts retain raw and the exhausted status. It is an operational negative, not a natural quality sample. It does not establish that every natural64-syllable task fails. It does establish that long-case feasibility cannot be assumed or made to pass by shortening/removing hard rows.

Actual cgroup allowance is32GiB memory and4CPU quota. The latest free-byte snapshot is10383925248, below the10737418240-byte floor. The dedicated Go cache is regenerable but has not been deleted. Parent capacity work is needed before a formal preflight.

For the frozen dataset, define Q_s as the sum of key checkpoints over all rows in split s, H_s as the sum of retained candidates over those queries, D_s as their actual Best requests, and Z_s as serialized raw evidence bytes. Variants count here even though only primaries contribute statistical n. These quantities are still unavailable because no bank/assignment has been acquired and frozen.

| Phase | Required work to account |
| --- | --- |
| verify | prescribed20cases plus contract tests/public observer parity; no formal tasks |
| shared enumeration | Q_train+Q_dev+Q_test+Q_regression, all retained hypotheses/features, plus four actual M/R/C/A Session passes |
| training | train-primary checkpoint/candidate observations; all hierarchical pairs, four masks x1000full-batch steps; no negative sampling |
| dev | four separately fitted models x8margins =32revise passes, each with Q_dev plus mandatory/regression rows |
| final test | eight model/flow conditions, each with Q_test plus mandatory/regression rows, exactly once |
| reduction | all eight frozen streams, source/bank joins,10000synchronous component bootstrap replicates, independent Go/Python reducers |

No decode cache is shared between phases or conditions. Within a query W/render share the complete decode, and the prescribed B snapshot is retained. The probe counter excludes internal Decoder dictionary IO and baseline Session internals; those unknown internal counts must not be reported as zero. Baseline elapsed/bytes and reducer peak memory still need actual frozen-row estimates. Current reducers retain decoded evidence in memory, so compressed8GiB alone does not prove32GiB memory feasibility.

A hypothetical objective-only microbenchmark took0.030176386seconds for10000pair evaluations (all13dimensions, no task observations and no fitting). A nonbinding extrapolation for four masks x1000steps x1000000pairs is about3.35CPU hours, excluding statistics, construction and IO. At the fixed2000000-pair cap it is about twice that. This is not a runtime promise or a quality result.

Maximum acquisition permits6000main prototypes x5variants =30000rows. A loose upper bound of512checkpoints x257candidates per row is not an affordable plan; source-specific byte/time/memory totals are required. The worksheet must sum every listed pass, not the earlier one-pass6000x8x20 illustration. Capacity remains INCONCLUSIVE.
