#!/usr/bin/env python3
from pathlib import Path
import json,sys
ROOT=Path('/workspace/0c-ime');OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'internal/shiftreturn'))
from exchange import encoded,digest
request=json.load(open(OUT/'parent-accepted/adjudication-request-review05.json'))
# Parent authorized the exact taxonomy correction. No second-pass file read.
words={'蜘蛛','螞蝗','蚯蚓','蝸牛','蛞蝓','蜈蚣','馬陸','蟎蟲'}
originals=[json.loads(l) for l in (OUT/'bank-pending-batch02.jsonl').read_text().splitlines()]
corrected=[];mapping=[]
for old in originals:
 if old['intent']!='return' or '昆蟲觀察' not in old['prompt']:continue
 target=old['gold'][0]['accepted_surfaces'][0][old['gold'][0]['segments'][0]['end']:]
 if target not in words:continue
 t=json.loads(json.dumps(old));t['prompt']=t['prompt'].replace('昆蟲觀察','小型無脊椎動物觀察');t['id']=digest({k:t[k] for k in ('source_ref','intent','prompt','raw','gold')})[:24];t['prototype_id']=t['id']
 t['annotations']=[dict(annotator_id='/root/shift_return_experiment_runner_v2',intent=t['intent'],reading_verified=True,accepted=True,labels_sha256=digest({k:t[k] for k in ('intent','raw','gold')}),adjudication_ref='prequality-context-taxonomy-review05')]
 corrected.append(t);mapping.append(dict(old_id=old['id'],new_id=t['id'],old_prototype_id=old['prototype_id'],new_prototype_id=t['prototype_id'],budget_identity='same source task; no additional prototype budget',reason='parent-authorized taxonomy correction; raw/gold/intent unchanged'))
assert len(corrected)==8
for name,records in [('bank-pending-correction05.jsonl',corrected),('correction05-id-map.jsonl',mapping),('batches/review-correction-05.jsonl',[{k:t[k] for k in ('id','source_ref','prompt','raw','gold')} for t in corrected])]:
 with (OUT/name).open('xb') as f:
  for r in records:f.write(encoded(r)+b'\n')
print({'corrected':len(corrected),'original_retained':True,'second_annotation':'absent'})
