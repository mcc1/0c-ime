#!/usr/bin/env python3
"""Retain exact seen-source bytes when hash-proven; report unavailable originals."""
from pathlib import Path
import json,hashlib,subprocess
OUT=Path(__file__).resolve().parent;ROOT=Path('/workspace/0c-ime');CACHE=OUT/'sources/seen-input-copies';CACHE.mkdir()
manifest=json.load(open(OUT/'sources/seen-supplement-v3.json'))['source_files'];result=[]
def sha(b):return hashlib.sha256(b).hexdigest()
for name,want in manifest.items():
 source=Path(name);current=source.read_bytes();data=None;origin='current path'
 if sha(current)==want:data=current
 if data is None:
  candidates=[Path('/workspace/scratch/shift-return-v2/p3-errata-r1/original-counterexample')/source.name,Path('/workspace/scratch/shift-return-v2/p3-errata-r1/original-counterexample')/source.relative_to(ROOT)] if source.is_relative_to(ROOT) else []
  for p in candidates:
   if p.exists() and sha(p.read_bytes())==want:data=p.read_bytes();origin=str(p);break
 if data is None and source.name=='state_test.go':
  trial=current.split(b'\nfunc TestLockedBudgetFailurePreservesShownSurface')[0]
  if sha(trial)==want:data=trial;origin='exact-hash-proven reverse of appended errata test'
 if data is None and source.name=='report_test.go':
  trial=current.split(b'\nfunc TestTemporalIndicesUseResearchKeyOrdinal')[0]
  begin=trial.index(b'\n\tpath := filepath.Join(t.TempDir(), "unavailable-evidence.json")')
  end=trial.index(b'\n\tif report.Gates.G0.Status != "unavailable"',begin)
  trial=trial[:begin]+trial[end:]
  trial=trial.replace(b' || m.Status != "unavailable" || m.UnavailableComponents != 1 || m.Errors != m.ObservedErrors+1',b'')
  if sha(trial)==want:data=trial;origin='exact-hash-proven reverse of appended errata tests'
 row={'original':name,'expected_sha256':want,'current_sha256':sha(current),'exact_cached':data is not None,'recovery':origin}
 if data is not None:
  destination=CACHE/(want+'-'+source.name);destination.write_bytes(data);row['cached_path']=str(destination)
 result.append(row)
(OUT/'sources/seen-input-cache-manifest.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'exact_copies':sum(r['exact_cached'] for r in result),'unavailable_originals':[r for r in result if not r['exact_cached']]},indent=2))
