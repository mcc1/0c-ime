#!/usr/bin/env python3
from pathlib import Path
import sys,json,hashlib,collections
ROOT=Path('/workspace/0c-ime');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'internal/shiftreturn'))
from exchange import encoded,digest
from dictionary import public_dictionary
entries,english=public_dictionary(ROOT/'assets/data');by_surface=collections.defaultdict(set)
for s,r in entries:by_surface[s].add(r)
keys=dict(zip('ㄅㄆㄇㄈㄉㄊㄋㄌㄍㄎㄏㄐㄑㄒㄓㄔㄕㄖㄗㄘㄙㄧㄨㄩㄚㄛㄜㄝㄞㄟㄠㄡㄢㄣㄤㄥㄦˉˊˇˋ˙','1qaz2wsxedcrfv5tgbyhnujm8ik,9ol.0p;/- 6347'))
def raw_syllable(s):return ''.join(keys[c] for c in s)+(' ' if s[-1] not in 'ˊˇˋ˙' else '')
def write(path,values):
 with path.open('xb') as f:
  for v in values:f.write(encoded(v)+b'\n')
def finish(t):
 t['id']=digest({k:t[k] for k in ('source_ref','intent','prompt','raw','gold')})[:24];t['prototype_id']=t['id'];t['annotations']=[dict(annotator_id='/root/shift_return_experiment_runner_v2',intent=t['intent'],reading_verified=True,accepted=True,labels_sha256=digest({k:t[k] for k in ('intent','raw','gold')}),adjudication_ref='')];return t
def base():return dict(version='shift-return-v2',kind='bank_task',demo=False,variant_index=0,source_ref='synthetic:acquisition-v1',source_priority=1,prelude_events=[],expected_prelude='',designated_typo_spans=[],source_edits=[],context_class='none')
old=[json.loads(l) for l in (OUT/'bank-pending-batch01.jsonl').read_text().splitlines()];old_words={t['gold'][0]['accepted_surfaces'][0][t['gold'][0]['segments'][0]['end']:] for t in old if t['intent']=='return'};used_prefix={t['families'][0][7:] for t in old};seen=set(json.load(open(OUT/'sources/seen-supplement-v3.json'))['seen_prefixes'])
labels=[]
for w in (OUT/'english-labels.txt').read_text().split():
 if w in english and w not in seen and w not in used_prefix and w not in labels:labels.append(w)
assert len(labels)>=210
manual={'微風':'ㄨㄟˊ ㄈㄥ','洞穴':'ㄉㄨㄥˋ ㄒㄩㄝˋ','斷崖':'ㄉㄨㄢˋ ㄧㄞˊ','褶皺':'ㄓㄜˊ ㄓㄡˋ','藤蔓':'ㄊㄥˊ ㄇㄢˋ','企鵝':'ㄑㄧˋ ㄜˊ','水獺':'ㄕㄨㄟˇ ㄊㄚˋ','海獺':'ㄏㄞˇ ㄊㄚˋ','鱒魚':'ㄗㄨㄣ ㄩˊ','鰻魚':'ㄇㄢˊ ㄩˊ','蛤蜊':'ㄍㄜˊ ㄌㄧˊ','蝸牛':'ㄍㄨㄚ ㄋㄧㄡˊ','翅膀':'ㄔˋ ㄅㄤˇ','足跡':'ㄗㄨˊ ㄐㄧ','巢穴':'ㄔㄠˊ ㄒㄩㄝˋ','成績單':'ㄔㄥˊ ㄐㄧ ㄉㄢ','校長':'ㄒㄧㄠˋ ㄓㄤˇ','班長':'ㄅㄢ ㄓㄤˇ','學長':'ㄒㄩㄝˊ ㄓㄤˇ','研究':'ㄧㄢˊ ㄐㄧㄡˋ','洗髮精':'ㄒㄧˇ ㄈㄚˇ ㄐㄧㄥ','花椰菜':'ㄏㄨㄚ ㄧㄝˊ ㄘㄞˋ','高麗菜':'ㄍㄠ ㄌㄧˋ ㄘㄞˋ','紅蘿蔔':'ㄏㄨㄥˊ ㄌㄨㄛˊ ㄅㄛˊ','白蘿蔔':'ㄅㄞˊ ㄌㄨㄛˊ ㄅㄛˊ','金桔':'ㄐㄧㄣ ㄐㄩˊ','番石榴':'ㄈㄢ ㄕˊ ㄌㄧㄡˊ','椰子':'ㄧㄝˊ ㄗˇ','乳酪':'ㄖㄨˇ ㄌㄨㄛˋ','發酵':'ㄈㄚ ㄒㄧㄠˋ','盛飯':'ㄔㄥˊ ㄈㄢˋ','帆船':'ㄈㄢˊ ㄔㄨㄢˊ','血壓計':'ㄒㄧㄝˇ ㄧㄚ ㄐㄧˋ','包紮':'ㄅㄠ ㄗㄚ','飲水':'ㄧㄣˇ ㄕㄨㄟˇ','刻刀':'ㄎㄜˋ ㄉㄠ','色調':'ㄙㄜˋ ㄉㄧㄠˋ','墊圈':'ㄉㄧㄢˋ ㄑㄩㄢ','鑽頭':'ㄗㄨㄢˋ ㄊㄡˊ','焊錫':'ㄏㄢˋ ㄒㄧˊ','正本':'ㄓㄥˋ ㄅㄣˇ','附件':'ㄈㄨˋ ㄐㄧㄢˋ'}
pool=[];rejected=[];unused=[];ambiguities=[]
for line in (OUT/'additional-short-targets.txt').read_text().splitlines():
 domain,ws=line.split('|')
 for w in ws.split():
  if w in old_words:unused.append(dict(target=w,reason='already authored full content target'));continue
  alternatives=sorted(r for r in by_surface[w] if len(r)==len(w) and not any('˙' in x for x in r))
  if not alternatives:alternatives=sorted(r for r in by_surface[w] if len(r)==len(w))
  if not alternatives:rejected.append(dict(target=w,domain=domain,reason='no full exact word/reading verification; source proposal retained, not rendered prototype'));continue
  if len(alternatives)>1:
   if w not in manual:rejected.append(dict(target=w,domain=domain,alternatives=alternatives,reason='ambiguous reading awaits authored decision; not rendered prototype'));continue
   reading=tuple(manual[w].split());assert reading in alternatives;(ambiguities.append(dict(target=w,selected=reading,alternatives=alternatives)))
  else:reading=alternatives[0]
  pool.append((domain,w,reading))
counts=collections.Counter();tasks=[];literal_counts=collections.Counter((t['category'],t['stratum']) for t in old if t['intent']=='literal');label_i=0;serial=0
for domain,w,reading in pool:
 initial=raw_syllable(reading[0])[0];digit=initial in '012589'
 if digit and counts['digit_initial']<105:cat='digit_initial'
 else:
  possible=[c for c in ('known','unknown','uppercase','identifier','typo') if counts[c]<105 and (not digit or c in ('identifier','typo'))]
  if not possible:unused.append(dict(target=w,reason='source proposal exceeds remaining phonetic/category quota; retained without task'));continue
  cat=min(possible,key=lambda c:(counts[c],('known','unknown','uppercase','identifier','typo').index(c)))
 counts[cat]+=1;serial+=1
 if cat in ('known','uppercase'):
  prefix=labels[label_i];label_i+=1
  if cat=='uppercase':prefix=prefix.title()
 else:
  # Distinct fictitious case labels, not a real vendor or user series.
  token=hashlib.sha256(('acquire-v2-prefix:'+str(serial)).encode()).hexdigest()[:9];letters=''.join(chr(97+int(c,16)) for c in token)
  prefix='v'+letters
  if cat=='identifier':prefix=prefix[:5]+'-'+prefix[5:]
 typo=[]
 if cat=='typo':typo=[dict(begin=len(prefix),end=len(prefix)+1)];prefix+='z'
 raw=prefix+''.join(map(raw_syllable,reading));segs=[dict(kind='literal',begin=0,end=len(prefix),reading='')];at=len(prefix)
 for r in reading:
  end=at+len(raw_syllable(r));segs.append(dict(kind='chinese',begin=at,end=end,reading=r));at=end
 t=base();t.update(intent='return',category=cat,stratum='2-4',context_class='contrast',raw=raw,gold=[dict(segments=segs,accepted_surfaces=[prefix+w])],families=['prefix:'+prefix.lower(),'word:'+w,'reading:'+' '.join(reading)],designated_typo_spans=typo)
 if typo:t['prompt']=f'整理{domain}的索引，先打標籤「{prefix[:-1]}」，不慎又按了 z；保留這個錯鍵，再寫中文項目「{w}」。期望完整文字為「{prefix+w}」，不要修掉標籤或插入分隔空格。'
 else:t['prompt']=f'整理{domain}的索引，這筆索引的標籤是「{prefix}」，中文項目是「{w}」。輸入標籤後直接接中文，期望完整文字為「{prefix+w}」，不要增加分隔空格。'
 tasks.append(finish(t))
 first=prefix+raw_syllable(reading[0]);digest8=hashlib.sha256(('counterpart:'+str(serial)).encode()).hexdigest()[:8]
 if ' ' in first:choices=[('random_ascii','9-32'),('random_ascii','33-128'),('random_ascii','129-512')]
 else:choices=[(c,'9-32') for c in ('phonetic_account','account','identifier','model_version','url_path','random_ascii')]+[(c,'33-128') for c in ('url_path','random_ascii','model_version','identifier')]
 selected=next(((c,s) for c,s in choices if literal_counts[c,s]<(93 if s=='129-512' else 94)),None)
 if selected is None:rejected.append(dict(return_task_id=t['id'],reason='no natural allocated literal-counterpart category/length slot; contrast counterpart unavailable'));t['context_class']='none';continue
 lc,ls=selected
 literal_raw=first+'x'+digest8
 if lc=='url_path':literal_raw=first+'/n/'+digest8[:6]+'.txt'
 if lc=='model_version':literal_raw=first+'-rc.'+digest8
 if ls=='33-128':literal_raw+='/'+'sample-'+digest8+'-archive-record.txt' if lc=='url_path' else '-sample-'+digest8+'-archive-record'
 if ls=='129-512':literal_raw+='|'+''.join(hashlib.sha256((str(serial)+':'+str(i)).encode()).hexdigest() for i in range(3))
 assert (9<=len(literal_raw)<=32 if ls=='9-32' else 33<=len(literal_raw)<=128 if ls=='33-128' else 129<=len(literal_raw)<=512),(lc,ls,literal_raw)
 literal_counts[lc,ls]+=1
 lit=base();lit.update(intent='literal',category=lc,stratum=ls,raw=literal_raw,gold=[dict(segments=[dict(kind='literal',begin=0,end=len(literal_raw),reading='')],accepted_surfaces=[literal_raw])],families=['prefix:'+prefix.lower(),'literal:'+literal_raw])
 if lc=='random_ascii':lit['prompt']=f'測試文字匯入是否逐字保留 ASCII。樣本是 {json.dumps(literal_raw,ensure_ascii=False)}，引號不算內容，內部空格與大小寫都算；全部照抄，不轉中文。這是合成測試資料，不是密碼。'
 elif lc=='url_path':lit['prompt']=f'在檔案索引的相對路徑欄，輸入虛構路徑「{literal_raw}」。這是測試檔案名稱，斜線與句點都是路徑內容；全部保留 ASCII，不轉中文。';lit['families'].append('literal-template:n-path-v1')
 elif lc=='model_version':lit['prompt']=f'把虛構模型的候選版名稱「{literal_raw}」記入測試清單。這是模型識別名稱與 rc 建置標記，不是中文敘述；整段照抄 ASCII。';lit['families'].append('literal-template:rc-model-v1')
 elif lc in ('account','phonetic_account'):lit['prompt']=f'在離線登入畫面測試中，輸入虛構的'+('音碼' if lc=='phonetic_account' else '')+f'帳號「{literal_raw}」。這不是密碼或真實使用者資料；每個字母、數字、符號都屬帳號，完整保留 ASCII，不轉中文。'
 else:lit['prompt']=f'測試資料需要一個合成識別碼「{literal_raw}」。請將整段輸入識別碼欄，照抄 ASCII 的大小寫與符號，不把音碼形式的字串轉成中文。'
 tasks.append(finish(lit))
 if sum(counts.values())==630:break
write(OUT/'bank-pending-batch02.jsonl',tasks);write(OUT/'rejected-batch02.jsonl',rejected);write(OUT/'unused-source-proposals-batch02.jsonl',unused);write(OUT/'reading-decisions-batch02.jsonl',ambiguities)
review=[{k:t[k] for k in ('id','source_ref','prompt','raw','gold')} for t in tasks]
for i in range(0,len(review),200):write(OUT/'batches'/('review-'+str(3+i//200).zfill(2)+'.jsonl'),review[i:i+200])
write(OUT/'batch02-status.json',[{'return':dict(counts),'pending_tasks':len(tasks),'literal_quota_usage_cumulative':{c+':'+s:n for (c,s),n in literal_counts.items()},'rejected_source_proposals':len(rejected),'unmaterialized_source_proposals':len(unused),'annotations':'only real first AI; second absent','formal_quality_run':False}]);print({'return':dict(counts),'tasks':len(tasks),'rejected':len(rejected)})
