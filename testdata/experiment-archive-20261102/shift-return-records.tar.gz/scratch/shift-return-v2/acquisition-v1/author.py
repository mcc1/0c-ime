#!/usr/bin/env python3
"""Task authoring/label conversion only. Never imports a generator/scorer/model."""
from pathlib import Path
import json,sys,hashlib,shutil,collections
ROOT=Path('/workspace/0c-ime');OUT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'internal/shiftreturn'))
from exchange import encoded,digest
from dictionary import public_dictionary
entries,english=public_dictionary(ROOT/'assets/data')
pairs=set(entries);by_surface=collections.defaultdict(set)
for surface,reading in entries:by_surface[surface].add(reading)
keys=dict(zip('ㄅㄆㄇㄈㄉㄊㄋㄌㄍㄎㄏㄐㄑㄒㄓㄔㄕㄖㄗㄘㄙㄧㄨㄩㄚㄛㄜㄝㄞㄟㄠㄡㄢㄣㄤㄥㄦˉˊˇˋ˙','1qaz2wsxedcrfv5tgbyhnujm8ik,9ol.0p;/- 6347'))
def raw_syllable(s):return ''.join(keys[c] for c in s)+(' ' if s[-1] not in 'ˊˇˋ˙' else '')
def write(path,value):
 with path.open('xb') as f:f.write(encoded(value)+b'\n')
def jsonl(path,values):
 with path.open('xb') as f:
  for value in values:f.write(encoded(value)+b'\n')
def verified(surface,reading):
 # Full authored text must be covered by exact surface/reading entries; no LM.
 reachable={0}
 for start in range(len(reading)):
  if start not in reachable:continue
  for end in range(start+1,min(len(reading),start+8)+1):
   if tuple(reading[start:end]) in by_surface.get(surface[start:end],set()):reachable.add(end)
 return len(reading) in reachable and len(surface)==len(reading)
def finish(task):
 id=digest({k:task[k] for k in ('source_ref','intent','prompt','raw','gold')})[:24]
 task.update(id=id,prototype_id=id)
 task['annotations']=[{'annotator_id':'/root/shift_return_experiment_runner_v2','intent':task['intent'],'reading_verified':True,'accepted':True,'labels_sha256':digest({k:task[k] for k in ('intent','raw','gold')}),'adjudication_ref':''}]
 return task
def base():return dict(version='shift-return-v2',kind='bank_task',demo=False,variant_index=0,source_ref='synthetic:acquisition-v1',source_priority=1,prelude_events=[],expected_prelude='',designated_typo_spans=[],source_edits=[],context_class='none')
prefixes={
 'known':'acorn amber apron atlas attic basil birch bloom braid brass brook cactus canoe cedar chime cider clover coral crane daisy'.split(),
 'unknown':'navori selniva movaru keluni fovela tazumi raneko lufari vesano korumi silavo neruki ponari mavelo surina tenavo lamiru kovena farulo nelavi'.split(),
 'uppercase':'Drift Ember Fern Flute Foggy Frost Glade Grain Grove Hazel Heron Honey Iris Ivory Jasmine Kettle Lagoon Lantern Lilac Linen'.split(),
 'identifier':['asset-'+str(i) for i in range(21,41)],
 'digit_initial':'lotus maple meadow mint moss nectar nickel olive opal orchid otter pebble petal pine plum pollen pond poppy quartz quill'.split(),
 'typo':'raven reed ribbon river robin rose sage satin silver slate stone sunset thyme tulip velvet violet wren zephyr almond azure'.split()}
revisions=[];tasks=[];rejected=[];counts=collections.Counter()
for line_number,line in enumerate((OUT/'short-targets.tsv').read_text().splitlines(),1):
 cat,text,reading,context=line.split('\t');original=(text,reading,context)
 fixes={'湖泊':('湖泊','ㄏㄨˊ ㄆㄛ','地理圖冊的水域分類'),'釘書機':('釘書機','ㄉㄧㄥˋ ㄕㄨ ㄐㄧ','行政用品的工具名稱'),'瀑布':('島嶼','ㄉㄠˇ ㄩˇ','海岸調查的地形名稱'),'港灣':('知識','ㄓ ㄕˋ','學習筆記的內容分類')}
 if text in fixes:
  text,reading,context=fixes[text];revisions.append({'source_line':line_number,'original':original,'revised':[text,reading,context],'stage':'before annotation; no strategy output','reason':'correct authored reading or intended category mismatch'})
 readings=reading.split();index=counts[cat];counts[cat]+=1;prefix=prefixes[cat][index];typo=[]
 if cat=='typo':typo=[{'begin':len(prefix),'end':len(prefix)+1}];prefix+='q'
 suffix=''.join(map(raw_syllable,readings));raw=prefix+suffix;segs=[dict(kind='literal',begin=0,end=len(prefix),reading='')];at=len(prefix)
 for r in readings:
  end=at+len(raw_syllable(r));segs.append(dict(kind='chinese',begin=at,end=end,reading=r));at=end
 if not verified(text,readings):rejected.append({'source_line':line_number,'target':text,'reading':reading,'reason':'authored surface/readings not fully verified by public dictionary exact entries'});continue
 first=raw_syllable(readings[0]);category='known' if prefix.lower() in english else 'unknown'
 if any(c.isupper() for c in prefix):category='uppercase'
 if suffix[0] in '012589':category='digit_initial'
 if not prefix.isalpha():category='identifier'
 if typo:category='typo'
 if category!=cat:rejected.append({'source_line':line_number,'target':text,'reason':'category verification differs','intended_category':cat,'actual_category':category});continue
 if not any(tuple(readings[:n]) in {r for s,r in entries if len(r)==n} for n in range(2,min(8,len(readings))+1)):
  rejected.append({'source_line':line_number,'target':text,'reason':'no exact word crossing first syllable; contrast allocation unavailable'});continue
 t=base();t.update(intent='return',category=cat,stratum='2-4',context_class='contrast',raw=raw,gold=[dict(segments=segs,accepted_surfaces=[prefix+text])],families=['prefix:'+prefix.lower(),'word:'+text,'reading:'+reading],designated_typo_spans=typo)
 if typo:t['prompt']=f'在{context}，先以英文輸入標籤「{prefix[:-1]}」，接著誤按了一個 q；本任務保留該錯鍵，不修正它，再輸入中文「{text}」。期望完整文字是「{prefix+text}」。'
 else:t['prompt']=f'在{context}，輸入標籤「{prefix}」後，緊接中文「{text}」，兩段中間不插入空格。期望完整文字是「{prefix+text}」。'
 tasks.append(finish(t))
 # Explicit literal continuation; counterfactual intent, never decoder labels.
 continuation='x'+hashlib.sha256(('literal:'+str(line_number)).encode()).hexdigest()[:8]
 literal_raw=prefix+first+continuation
 lit=base();literal_cat='random_ascii' if ' ' in literal_raw else ('phonetic_account' if line_number%2 else 'identifier')
 lit.update(intent='literal',category=literal_cat,stratum='9-32',raw=literal_raw,gold=[dict(segments=[dict(kind='literal',begin=0,end=len(literal_raw),reading='')],accepted_surfaces=[literal_raw])],families=['prefix:'+prefix.lower(),'literal:'+literal_raw])
 if literal_cat=='random_ascii':lit['prompt']=f'在文字匯入測試中，逐字輸入下列 ASCII 樣本：{json.dumps(literal_raw,ensure_ascii=False)}。引號只是界定樣本，不輸入引號；保留內部空格和大小寫，整段都不要轉為中文。這是合成測試文字，不是帳號或密碼。'
 elif literal_cat=='phonetic_account':lit['prompt']=f'為測試虛構音碼帳號，輸入識別字串「{literal_raw}」。其中開頭後面的數字與字母是帳號的一部分；全部保留 ASCII，不轉中文。這不是現有使用者的真實帳號。'
 else:lit['prompt']=f'在測試資料的識別碼欄，輸入合成代碼「{literal_raw}」。整個代碼由 ASCII 字元組成，大小寫與符號照抄，不轉中文；不代表任何真實憑證。'
 if len(literal_raw)>32:lit['stratum']='33-128'
 tasks.append(finish(lit))
jsonl(OUT/'bank-pending-batch01.jsonl',tasks);jsonl(OUT/'rejected-batch01.jsonl',rejected);write(OUT/'authoring-revisions-batch01.json',revisions)
blind=[{k:t[k] for k in ('id','source_ref','prompt','intent','raw','gold')} for t in tasks]
# Include one pair from each distinct category plus multiple literal framings.
packet=[]
for cat in prefixes:
 for i,t in enumerate(tasks):
  if t['intent']=='return' and t['category']==cat:
   packet.extend(blind[i:i+2]);break
jsonl(OUT/'batches/blind-01.jsonl',packet);jsonl(OUT/'batches/blind-02.jsonl',[t for t in blind if t['id'] not in {x['id'] for x in packet}])
write(OUT/'batch01-status.json',{'pending_tasks':len(tasks),'pending_prototypes':len(tasks),'return':sum(t['intent']=='return' for t in tasks),'literal':sum(t['intent']=='literal' for t in tasks),'rejected':len(rejected),'second_annotation':'absent','formal_qualification':False,'categories':dict(collections.Counter(t['intent']+':'+t['category']+':'+t['stratum'] for t in tasks))})
print({'tasks':len(tasks),'rejected':rejected,'blind01':len(packet)})
