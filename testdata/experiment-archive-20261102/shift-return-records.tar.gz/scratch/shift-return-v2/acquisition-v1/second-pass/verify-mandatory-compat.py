#!/usr/bin/env python3
"""Read-only compat event validation; no replay, decoder, or BankTask signature."""
import hashlib,json
from pathlib import Path
B=Path('/workspace/scratch/shift-return-v2/acquisition-v1')
O=B/'second-pass'
# Reuse only our independent dictionary/key helper definitions, stopping before
# any packet reading or output writing. This is not an IME implementation.
ns={}
exec((O/'independent-review-01-02.py').read_text().split('results = []')[0],ns)
packet=B/'batches/review-mandatory-compat.jsonl'
xs=[json.loads(l) for l in packet.read_text().splitlines()]
judgments={
 'compat:mandatory-microsoft-skirt':('return','microsoft窄裙','明示中文初始模式按 Shift 後輸入英文 microsoft，再接中文窄裙；語境與輸出明確。這是已見的 Shift 英接中回歸。'),
 'compat:mandatory-prelude-wq-earn':('return','解WQ賺錢','prelude 先組出解並保留 composition，後續 Shift 英文 WQ 加中文賺錢；gold 僅涵蓋後續 raw，完整期望需加前綴解。WQ 大小寫保留；錯誤顯示解WD5萬前不是 gold。'),
 'compat:mandatory-original-593':('chinese_without_shift','窄','初始中文且全程無 Shift，593 指定窄，為原 Session 混打對照；不是 Shift 英→中回切成功任務。')}
out=[]
for x in xs:
 intent,full,reason=judgments[x['id']]
 events=x['events'];pre=x['prelude_events'];raw=x['raw'];errors=[]
 event_raw=''.join(e['key'] for e in events if e['type']=='key')
 if event_raw!=raw:errors.append('event key sequence differs from raw')
 if events[-1]!={'type':'enter'}:errors.append('missing final enter')
 shifts=[i for i,e in enumerate(events) if e['type']=='shift']
 if shifts!=([0] if intent=='return' else []):errors.append('unexpected Shift event scope')
 evidence=[]
 for alt in x['gold']:
  pos=0;prefix='';readings=[]
  for s in alt['segments']:
   a,b=s['begin'],s['end']
   if a!=pos or not a<b<=len(raw):errors.append('raw span coverage')
   pos=b
   actual=raw[a:b]
   if s['kind']=='literal':prefix+=actual
   else:
    expected=ns['raw_reading'](s['reading']);readings.append(s['reading'])
    if expected!=actual:errors.append('reading/keys mismatch')
    evidence.append({'begin':a,'end':b,'raw':actual,'reading':s['reading'],'expected_raw':expected,'verified':expected==actual})
  if pos!=len(raw):errors.append('incomplete span coverage')
  witnesses=[]
  for surface in alt['accepted_surfaces']:
   w=ns['witness'](surface[len(prefix):],readings) if surface.startswith(prefix) else None
   if w is None:errors.append('surface dictionary mismatch')
   if x['expected_prelude']+surface!=full:errors.append('complete surface/prelude mismatch')
   witnesses.append({'surface':surface,'dictionary_witness':w})
 pre_raw=''.join(e['key'] for e in pre if e['type']=='key')
 pre_evidence=None
 if x['expected_prelude']:
  expected_pre=ns['raw_reading']('ㄐㄧㄝˇ')
  w=ns['witness']('解',['ㄐㄧㄝˇ'])
  if pre_raw!=expected_pre or x['expected_prelude']!='解' or w is None:errors.append('prelude reading/surface mismatch')
  if any(e['type']!='key' for e in pre):errors.append('prelude must retain composition without enter')
  pre_evidence={'raw':pre_raw,'reading':'ㄐㄧㄝˇ','surface':'解','dictionary_witness':w,'no_enter_or_commit_event':True,'limitation':'Events express retained composition; actual runtime retention is not tested here.'}
 elif pre:errors.append('unexpected prelude events')
 out.append({'id':x['id'],'annotator_id':'/root/shift_return_blind_annotator_v1','annotation_type':'compat_specific_independent_ai_review','inferred_intent':intent,'accepted_for_compat_review':not errors,'reading_verified':not errors,'mandatory_seen_regression':True,'new_heldout_eligible':False,'formal_bank_task_annotation':False,'counts_as_shift_return_success_task':intent=='return','observed_runtime_shift_return_success':None,'complete_expected_surface':full,'reason':reason,'adjudication':errors or None,'actual_review_method':{'semantic':'Actual AI annotator independently read all three full prompts/raw/gold/prelude/events and interpreted their scope. No first annotation or author map read.','mechanical':'Separate static check of every event key, Shift positions, final enter, raw span coverage, Standard layout readings and frozen dictionary surface/prelude witnesses. No candidate/replay/model call; no runtime success inferred.'},'event_evidence':{'event_key_sequence':event_raw,'raw_matches_events':event_raw==raw,'shift_event_indices':shifts,'final_event':'enter','raw_scope':'excludes prelude and control events','prelude':pre_evidence},'reading_evidence':evidence,'surface_evidence':witnesses})
assert len(out)==3
p=O/'review-mandatory-compat.second-ai.jsonl'
with p.open('xb') as f:
 for x in out:f.write(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()+b'\n')
print(p,hashlib.sha256(p.read_bytes()).hexdigest())
for x in out:print(x['id'],x['inferred_intent'],x['accepted_for_compat_review'],x['adjudication'])
