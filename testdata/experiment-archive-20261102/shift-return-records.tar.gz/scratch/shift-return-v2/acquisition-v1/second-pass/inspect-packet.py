#!/usr/bin/env python3
"""Losslessly render all prompts using exact template + quoted slots."""
import json,re,sys
from pathlib import Path
p=Path('/workspace/scratch/shift-return-v2/acquisition-v1/batches')/sys.argv[1]
templates={}
for i,l in enumerate(p.read_text().splitlines(),1):
 x=json.loads(l); slots=[]
 def sub(m):slots.append(m.group());return '{}'
 t=re.sub('「[^」]*」|"[^"]*"',sub,x['prompt'])
 if t not in templates:
  templates[t]=len(templates)+1;print('TEMPLATE',templates[t],t)
 if len(sys.argv)>2 and not int(sys.argv[2])<=i<=int(sys.argv[3]):continue
 g=[{'surfaces':a['accepted_surfaces'],'readings':[s['reading'] for s in a['segments'] if s['kind']=='chinese']} for a in x['gold']]
 print(i,'T'+str(templates[t]),json.dumps(slots,ensure_ascii=False),repr(x['raw']),json.dumps(g,ensure_ascii=False,separators=(',',':')))
