#!/usr/bin/env python3
import hashlib,json,re,sys
from pathlib import Path
B=Path('/workspace/scratch/shift-return-v2/acquisition-v1'); n=int(sys.argv[1])
rows=[]
for k in range(1,n+1):
 for l in (B/f'batches/review-{k:02}.jsonl').read_text().splitlines():
  x=json.loads(l); x['packet']=f'review-{k:02}.jsonl';rows.append(x)
terms={}; sounds={}
for x in rows:
 m=re.search('(?:緊接中文|再輸入中文|中文項目是|再寫中文項目)「([^」]+)」',x['prompt'])
 if m:
  terms.setdefault(m.group(1),[]).append(x)
  rr=tuple(s['reading'] for s in x['gold'][0]['segments'] if s['kind']=='chinese')
  sounds.setdefault(rr,[]).append(x)
def ids(xs):return [x['id'] for x in xs]
groups=[(['螢幕','顯示器'],'電腦設備語境的同義詞'),(['樹枝','枝條'],'植物記錄語境近義，建議同family'),(['洞穴','山洞'],'地形記錄中近義的洞窟內容，建議同family'),(['蓮花','荷花'],'植物名稱同義'),(['烏賊','墨魚','花枝'],'海洋生物語境中墨魚/花枝為烏賊的常見名稱；建議同family'),(['芭樂','番石榴'],'台灣水果名稱同義'),(['香油','麻油'],'烹調語境常指芝麻油，建議連family；若嚴格區分精製與烘焙油請父端裁定'),(['梨子','水梨'],'水果語境高度近義，水梨較具體，建議連family'),(['柚子','文旦'],'水果語境文旦是柚子品種，常見名稱交疊；建議保守連family，非嚴格全同義')]
alias=[]
groups.extend([(['乳酪','起司'],'烹調備料中的同義名稱'),(['腳踏車','自行車'],'交通行程中的同義名稱'),(['貨車','卡車'],'交通工具中高度近義，建議同family'),(['羅勒','九層塔'],'九層塔為羅勒常見類型與稱呼，烹調內容高度重疊；建議保守同family，非全部品種等同'),(['黑糖','紅糖'],'糖類名稱在使用上高度重疊；加工/地域可能區分，建議保守同family'),(['烘烤','烘焙'],'料理方式語意近重複，範圍非完全相同，建議保守連family')])
groups.extend([(['指南針','羅盤'],'旅行定位工具語境中同義/近義，建議連family'),(['快走','健走'],'運動紀錄中高度近義，建議連family'),(['跑步','慢跑'],'運動紀錄中泛稱與具體形式高度交疊，建議保守同family，非嚴格同義')])
for words,reason in groups:
 present=[w for w in words if w in terms]
 if len(present)>1:
  xs=[x for w in present for x in terms[w]]
  if any(x['packet']==f'review-{n:02}.jsonl' for x in xs):alias.append({'terms':present,'task_ids':ids(xs),'reason':reason,'recommendation':'link semantic family','basis':'independent AI semantic judgment'})
current=[x for x in rows if x['packet']==f'review-{n:02}.jsonl']; pairs=[]
for a,b in zip(current[::2],current[1::2]):
 if '期望完整文字' in a['prompt']:
  seg=a['gold'][0]['segments']; prefix=a['raw'][:next(s['end'] for s in seg if s['kind']=='chinese')]
  if b['raw'].startswith(prefix):pairs.append({'task_ids':ids([a,b]),'shared_raw_prefix':prefix,'basis':'mechanical contrast pair; opposite intent, not synonym','recommendation':'link/review contrast-pair family'})
same=lambda d:[{'key':list(key) if isinstance(key,tuple) else key,'task_ids':ids(xs),'basis':'mechanical exact match'} for key,xs in d.items() if len(xs)>1 and any(x in current for x in xs)]
near=[]
for pattern,explanation in [(r'-sample-[0-9a-f]+-archive-record$','固定literal內容結構 <prefix>x<hex>-sample-<same hex>-archive-record；不是僅共用照抄研究指令，建議連同一template family'),(r'-rc\.[0-9a-f]+$','固定literal模型候選版名稱 <prefix>-rc.<hex>；建議連同建置標記內容template family'),(r'/n/[0-9a-f]+\.txt$','固定literal相對路徑內容 <prefix>/n/<hex>.txt，建議同一template family')]:
 if pattern==r'/n/[0-9a-f]+\.txt$':pattern=r'/n/[0-9a-f]+\.txt(?:/sample-[0-9a-f]+-archive-record\.txt)?$';explanation+='；追加 /sample-<hex>-archive-record.txt 的擴充版仍連同一family，避免依長度拆開'
 xs=[x for x in rows if '期望完整文字' not in x['prompt'] and re.search(pattern,x['raw'])]
 if len(xs)>1 and any(x in current for x in xs):near.append({'task_ids':ids(xs),'reason':explanation,'recommendation':'link content-template family','basis':'AI semantic judgment plus mechanical structure enumeration'})
xs=[x for x in rows if '期望完整文字' not in x['prompt'] and re.search(r'\|[0-9a-f]{100,}$',x['raw'])]
if len(xs)>1 and any(x in current for x in xs):near.append({'task_ids':ids(xs),'reason':'固定literal內容 <prefix>x<hex>|<long hex>，長十六進位payload是合成匯入測試資料；建議連同一內容template family，不可當不同自然語句','recommendation':'link content-template family','basis':'AI semantic judgment plus mechanical enumeration'})
result={'annotator_id':'/root/shift_return_blind_annotator_v1','source_packet':f'review-{n:02}.jsonl','visible_packets':f'review-01 through review-{n:02}','semantic_aliases':alias,'near_duplicates':near,'mechanical_same_term':same(terms),'mechanical_same_full_reading':same(sounds),'mechanical_contrast_pairs':pairs,'semantic_review_note':'逐筆語意判讀；目前中文內容是短標籤索引，未見長句內容模板。共用研究meta指令本身不等於相同內容句。物種/地形/設備等相關或上下位概念不自動視為同義詞。所有判讀只用已指定且已讀packet，不讀seen/split/model/首標。固定literal內容template另列，不以ASCII照抄meta指令合併。'}
p=B/f'second-pass/review-{n:02}.second-ai.aliases.json'
with p.open('x') as f:json.dump(result,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
print(p,hashlib.sha256(p.read_bytes()).hexdigest(),'aliases',len(alias),'contrast_pairs',len(pairs))
