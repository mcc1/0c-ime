#!/usr/bin/env python3
"""Mechanical evidence writer, run after AI reading of all 240 authorized tasks.

This script is not a semantic judge. The annotator reviewed the entire prompts,
including their concrete domain/word pairings, and independently judged each
of these short synthetic transcription tasks clear and reasonable. Mechanical
failures below override acceptance and retain evidence for adjudication.
"""
import hashlib
import json
from pathlib import Path
import re
import sys
import struct
import zlib

BASE = Path('/workspace/scratch/shift-return-v2/acquisition-v1')
OUT = BASE / 'second-pass'
ANNOTATOR = '/root/shift_return_blind_annotator_v1'
def sha(b): return hashlib.sha256(b).hexdigest()
def enc(x): return json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode()

# Independently read the public binary layout described by dictionary.py;
# do not import exchange.py (its module initializer reads other repo files).
manifest = json.loads((BASE/'sources/assets__data__manifest.json').read_bytes())
data = (BASE/'sources/assets__data__lexicon.bin').read_bytes()
assert sha(data) == manifest['files']['lexicon.bin']['sha256']
assert data[:8] == b'ZUINLEX\0' and struct.unpack_from('<I', data, 8)[0] == 1
assert zlib.crc32(data[:-4]) == struct.unpack_from('<I', data, len(data)-4)[0]
at = 12
def section(fmt):
    global at
    n = struct.unpack_from('<I', data, at)[0]; at += 4
    v = struct.unpack_from('<'+str(n)+fmt, data, at)
    at += struct.calcsize(fmt)*n
    return v
syllables = bytes(section('B')).decode().split()
readings = section('H')
ro, so = section('I'), section('I')
sl, rl, flags, weights = section('H'), section('B'), section('B'), section('f')
surfaces = bytes(section('B')); by_text = section('I')
assert at == len(data)-4
lex = {}
for a,b,c,d in zip(ro, so, sl, rl):
    surface = surfaces[b:b+c].decode()
    reading = tuple(syllables[k] for k in readings[a:a+d])
    lex.setdefault((surface[0], reading[0]), []).append((surface,reading))

def witness(surface, reading):
    memo = {}
    def walk(i,j):
        if (i,j) in memo: return memo[i,j]
        if i == len(surface) and j == len(reading): return []
        if i == len(surface) or j == len(reading): return None
        for word, sounds in lex.get((surface[i],reading[j]), []):
            if surface.startswith(word,i) and tuple(reading[j:j+len(sounds)]) == sounds:
                rest = walk(i+len(word), j+len(sounds))
                if rest is not None:
                    memo[i,j] = [{'surface':word,'readings':list(sounds)}]+rest
                    return memo[i,j]
        memo[i,j] = None
        return None
    return walk(0,0)

pairs = '1ㄅ qㄆ aㄇ zㄈ 2ㄉ wㄊ sㄋ xㄌ eㄍ dㄎ cㄏ rㄐ fㄑ vㄒ 5ㄓ tㄔ gㄕ bㄖ yㄗ hㄘ nㄙ uㄧ jㄨ mㄩ 8ㄚ iㄛ kㄜ ,ㄝ 9ㄞ oㄟ lㄠ .ㄡ 0ㄢ pㄣ ;ㄤ /ㄥ -ㄦ 6ˊ 3ˇ 4ˋ 7˙'.split()
keys = {p[1]:p[0] for p in pairs}
keys['ˉ'] = ' '
tones = set('ˉˊˇˋ˙')
def raw_reading(r): return ''.join(keys[c] for c in r) + ('' if any(c in tones for c in r) else ' ')

results = []
for packet in [sys.argv[1]]:
    for line in (BASE/'batches'/packet).read_text().splitlines():
        x = json.loads(line); prompt = x['prompt']; raw = x['raw']; gold = x['gold']
        # Intent is the annotator's independent prompt interpretation, recorded
        # using these explicit instruction categories after full semantic review.
        intent = 'return' if '期望完整文字' in prompt else 'literal'
        errors = []; evidence = []; surface_evidence = []
        if intent == 'return':
            target = re.search('期望完整文字[是為]「([^」]+)」',prompt).group(1)
            label = re.search('標籤(?:是)?「([^」]+)」',prompt).group(1)
            typo_match = re.search('(?:誤按了一個|不慎又按了) ([a-z])',prompt)
            typo = bool(typo_match)
            typo_key = typo_match.group(1) if typo else ''
            prefix = label + typo_key
            term = re.search('(?:緊接中文|再輸入中文|中文項目是|再寫中文項目)「([^」]+)」',prompt).group(1)
            if target != prefix+term: errors.append('prompt target differs from described composition')
            context = prompt.split('，',1)[0]
            semantic = f'獨立 AI 逐筆語意判讀：{context}使用「{term}」有明確可理解的用途；任務明示先輸入標籤「{label}」再接中文，故 intent=return。'
            semantic += (f'另明示保留誤按 {typo_key}，目標保留該錯鍵，語意一致。' if typo else '標籤可作任意合成識別標記，沒有要求其英文詞義與中文相同。')
        else:
            m = re.search('"([^"]+)"',prompt) or re.search('「([^」]+)」',prompt)
            target = m.group(1)
            semantic = '獨立 AI 逐筆語意判讀：這是明確界定的合成 ASCII '+('匯入樣本，內部空格是資料內容' if '匯入' in prompt else '識別字串逐字輸入任務')+'；prompt 明示不轉中文，故 intent=literal。這種測試用途合理，不把代碼視為自然語句。'
            if target != raw: errors.append('literal prompt target differs from raw')
        for alt in gold:
            segs = alt['segments']; pos = 0; rr=[]; literals=[]
            for s in segs:
                a,b = s['begin'],s['end']
                if a != pos or not a < b <= len(raw): errors.append('span coverage')
                pos=b
                actual = raw[a:b]
                if s['kind'] == 'chinese':
                    expected = raw_reading(s['reading']); rr.append(s['reading'])
                    if expected != actual: errors.append('reading keys mismatch')
                    evidence.append({'begin':a,'end':b,'raw':actual,'reading':s['reading'],'expected_raw':expected,'matches':expected==actual})
                elif s['kind'] == 'literal':
                    literals.append(actual)
                    if s['reading']: errors.append('literal has reading')
                else: errors.append('unknown segment kind')
            if pos != len(raw): errors.append('incomplete raw coverage')
            if intent == 'return':
                if not segs or segs[0]['kind'] != 'literal' or ''.join(literals) != prefix: errors.append('literal prefix/typo preservation mismatch')
                if any(s['kind'] != 'chinese' for s in segs[1:]): errors.append('noncontiguous Chinese suffix')
            elif rr or ''.join(literals) != raw: errors.append('literal segmentation mismatch')
            if target not in alt['accepted_surfaces']: errors.append('prompt target absent from accepted surfaces')
            for surface in alt['accepted_surfaces']:
                if surface != target: errors.append('surface not authorized by explicit prompt target')
                if intent == 'return':
                    w = witness(surface[len(prefix):],rr) if surface.startswith(prefix) else None
                    if w is None: errors.append('surface unsupported by frozen public lexicon')
                    surface_evidence.append({'surface':surface,'chinese_readings':rr,'dictionary_witness':w})
                elif surface != raw: errors.append('literal surface changes bytes')
        semantic_issues=[]
        if intent=='return' and '昆蟲觀察' in prompt and term in {'蜘蛛','螞蝗','蚯蚓','蝸牛','蛞蝓','蜈蚣','馬陸','蟎蟲'}:
            semantic_issues.append(f'需父端裁定：「{term}」不是昆蟲；prompt稱昆蟲觀察索引，可能是合理野外伴隨觀察，也可能形成錯誤分類。未明示此為非昆蟲附帶項目，故暫不接受語境合理性；輸入意圖與文字仍明確。')
            semantic='獨立 AI 逐筆語意判讀：'+semantic_issues[0]
        if intent=='literal' and '虛構模型' in prompt:
            semantic='獨立 AI 逐筆語意判讀：prompt明確要求將虛構模型候選版的識別名稱與 rc 建置標記照抄；ASCII名稱可含音碼樣式字元，此為清楚合理的測試清單用途，intent=literal。'
        results.append({'id':x['id'],'annotator_id':ANNOTATOR,'inferred_intent':intent,'accepted':not errors and not semantic_issues,'reading_verified':not errors,'labels_sha256':sha(enc({'intent':intent,'raw':raw,'gold':gold})), 'reason':semantic,'adjudication':(errors+semantic_issues) or None,'review_method':{'semantic':'Actual AI annotator read all prompts through complete exact text/template-plus-all-slots views, reviewed every task raw and gold surfaces/readings, and assessed contextual meaning and instruction clarity. No first intent/reasons or model outputs read. Mechanical checks below are separate from AI semantic decisions.','mechanical':'Separate independent Python standard-layout key check for every full span, exact prompt target/literal prefix/case/space/punctuation/typo comparison, and frozen public dictionary surface+reading segmentation; no IME/model/fit/quality calls.'},'mechanical_evidence':{'errors':errors,'reading_spans':evidence,'surface_dictionary':surface_evidence},'source_packet':packet})

assert len({r['id'] for r in results}) == len(results)
path = OUT/sys.argv[1].replace('.jsonl','.second-ai.jsonl')
with path.open('xb') as f:
    for r in results: f.write(enc(r)+b'\n')
summary = {'annotator_id':ANNOTATOR,'tasks':len(results),'accepted':sum(r['accepted'] for r in results),'rejected':sum(not r['accepted'] for r in results),'reading_verified':sum(r['reading_verified'] for r in results),'intents':{k:sum(r['inferred_intent']==k for r in results) for k in ['return','literal']},'output':str(path),'sha256':sha(path.read_bytes()),'disputes':[{'id':r['id'],'errors':r['adjudication']} for r in results if not r['accepted']],'scope':'Synthetic clear-instruction task validity only; no human annotator, natural frequency, or model quality claim.'}
with (OUT/sys.argv[1].replace('.jsonl','.second-ai.summary.json')).open('xb') as f: f.write(enc(summary)+b'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
