#!/usr/bin/env python3
"""Record separate AI semantic alias judgment and mechanical pair suggestions."""
import hashlib
import json
from pathlib import Path
import re
B = Path('/workspace/scratch/shift-return-v2/acquisition-v1')
packets = {p:[json.loads(s) for s in (B/'batches'/p).read_text().splitlines()] for p in ['review-01.jsonl','review-02.jsonl']}
for name, rows in packets.items():
    terms = {}
    readings = {}
    pairs = []
    for x in rows:
        m = re.search('(?:緊接中文|再輸入中文)「([^」]+)」',x['prompt'])
        if m:
            terms.setdefault(m.group(1),[]).append(x['id'])
            rr = tuple(s['reading'] for s in x['gold'][0]['segments'] if s['kind']=='chinese')
            readings.setdefault(rr,[]).append(x['id'])
    # These are lexical synonyms in the stated computer equipment contexts.
    aliases = []
    if '螢幕' in terms and '顯示器' in terms:
        aliases.append({'task_ids':terms['螢幕']+terms['顯示器'],'terms':['螢幕','顯示器'],'recommendation':'link semantic family','reason':'在桌面配置與維修設備語境中指同類顯示裝置；不同標籤與讀音不消除語意別名關係。','basis':'independent AI semantic judgment'})
    # The packets visibly alternate return/literal contrast tasks sharing the
    # label and first syllable keys. This is a mechanical relation, not an
    # assertion that their desired text or intent is semantically equivalent.
    for a,b in zip(rows[::2],rows[1::2]):
        if '期望完整文字' in a['prompt'] and '不轉中文' in b['prompt'] or '期望完整文字' in a['prompt'] and '不要轉為中文' in b['prompt']:
            seg = a['gold'][0]['segments']
            prefix = a['raw'][:next(s['end'] for s in seg if s['kind']=='chinese')]
            if b['raw'].startswith(prefix):
                pairs.append({'task_ids':[a['id'],b['id']],'shared_raw_prefix':prefix,'recommendation':'review/link contrast-pair family','basis':'mechanical shared label plus first full Chinese syllable key sequence; opposite prompt intent, not synonym'})
    result = {'annotator_id':'/root/shift_return_blind_annotator_v1','source_packet':name,'semantic_aliases':aliases,'near_duplicates':[], 'mechanical_same_term':[{'term':t,'task_ids':ids} for t,ids in terms.items() if len(ids)>1], 'mechanical_same_full_reading':[{'reading':list(rr),'task_ids':ids} for rr,ids in readings.items() if len(ids)>1], 'mechanical_contrast_pairs':pairs,'semantic_review_note':'已逐筆閱讀完整 prompt。未見長句內容模板、填充長句或改詞長句近重複；各任務是短標籤內容。共用輸入標籤再接中文、ASCII照抄、保留q的研究指令格式本身不判為相同內容句模板。森林/樹林/竹林、不同茶飲、不同文具或樂器是相關或上下位類別，未逕稱完全語意別名；父端仍可依預定family尺度裁定。','limitation':'僅指定兩份盲審 packet；未讀 seen/split/首標/模型結果，不聲稱跨未見資料去重。'}
    path = B/'second-pass'/name.replace('.jsonl','.second-ai.aliases.json')
    with path.open('x') as f:json.dump(result,f,ensure_ascii=False,sort_keys=True,indent=2);f.write('\n')
    print(path,hashlib.sha256(path.read_bytes()).hexdigest(), 'aliases',len(aliases),'contrast_pairs',len(pairs))
