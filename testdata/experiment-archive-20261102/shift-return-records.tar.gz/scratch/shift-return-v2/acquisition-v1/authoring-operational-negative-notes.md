# Acquisition operation negatives (not quality)

The batch02 authoring command initially aborted before any task-bank output because a requested9–32 literal URL slot produced33bytes: `vioopidkamze03/notes/46178622.txt`. This was an authoring assertion, not an IME/generator result. The authoring source was corrected to the shorter explicit `/n/` path form and re-executed; actual target/raw/stratum bounds are checked. The initial tool output remains in the conversation; this note preserves its concrete counterexample without calling it a stored raw log.

A proposed large single-character source write was rejected by the tool JavaScript parser before any shell ran (SyntaxError: Invalid or unexpected token). It produced no task bank and consumed no prototype budget. No single-character acquired tasks are claimed.

Eight rendered return prompts incorrectly called spiders/leeches/earthworms/snails/slugs/centipedes/millipedes/mites insects. Original task bank and second-pass rejections are retained. The parent-authorized correction changes only that context phrase, creates actual new canonical IDs and renewed first annotation, and awaits/requires a distinct renewed second signature. It is the same eight budget identities, never eight added prototypes.

38 short-word source proposals had no fully verified exact target or unresolved reading choice and were not rendered into prototypes. They are preserved in rejected-batch02.jsonl.96 additional source proposals were not materialized because category/phonetic quotas were filled. These are word-source proposals, not hidden quality failures; all1500 actual rendered prototypes remain in the author bank, including the8 retired identities and their revision map.
