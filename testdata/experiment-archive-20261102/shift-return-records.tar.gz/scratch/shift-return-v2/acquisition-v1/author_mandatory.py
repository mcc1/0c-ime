#!/usr/bin/env python3
from pathlib import Path
import sys,json
ROOT=Path('/workspace/0c-ime');OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'internal/shiftreturn'))
from exchange import encoded,digest,VALIDATOR
from dictionary import public_dictionary
from reduce import fixture_semantics
pairs=set(public_dictionary(ROOT/'assets/data')[0])
assert ('窄',('ㄓㄞˇ',)) in pairs and ('裙',('ㄑㄩㄣˊ',)) in pairs and ('解',('ㄐㄧㄝˇ',)) in pairs and ('賺錢',('ㄓㄨㄢˋ','ㄑㄧㄢˊ')) in pairs
specs=[dict(name='mandatory-microsoft-skirt',prompt='回歸使用者明示任務：從中文模式按 Shift，先打英文 microsoft，接著輸入中文「窄裙」，期望輸出 microsoft窄裙。microsoft 與窄裙均已在對話見過；不得當新 test。',raw='microsoft593fmp6',prefix='microsoft',surface='microsoft窄裙',parts=[('593','ㄓㄞˇ'),('fmp6','ㄑㄩㄣˊ')],prelude='',prelude_raw='',shift=True),dict(name='mandatory-prelude-wq-earn',prompt='回歸使用者明示任務：先在中文模式輸入「解」並保留 composition，按 Shift 輸入英文 WQ，再接中文「賺錢」。完整期望文字是「解WQ賺錢」，不要將先前錯誤顯示「解WD5萬前」作 gold。WQ/WD5 及此對話例均 seen。',raw='WQ5j04fu06',prefix='WQ',surface='WQ賺錢',parts=[('5j04','ㄓㄨㄢˋ'),('fu06','ㄑㄧㄢˊ')],prelude='解',prelude_raw='ru,3',shift=True),dict(name='mandatory-original-593',prompt='原混打回歸：初始中文、不按 Shift，只打 593 並提交，指定中文字是「窄」。此例供原版 Session 對照，不是自動 Shift 回中文的成功任務，亦不計新 test。',raw='593',prefix='',surface='窄',parts=[('593','ㄓㄞˇ')],prelude='',prelude_raw='',shift=False)]
fixtures=[];packets=[];authors=[]
for s in specs:
 at=0;segs=[]
 if s['prefix']:at=len(s['prefix']);segs.append(dict(kind='literal',begin=0,end=at,reading=''))
 for raw,reading in s['parts']:segs.append(dict(kind='chinese',begin=at,end=at+len(raw),reading=reading));at+=len(raw)
 f=dict(version='shift-return-v2',kind='fixture',demo=False,id='compat:'+s['name'],prototype_id=s['name'],intent='compat',category='mandatory_seen_regression',stratum='compat',context_class='none',source_ref='synthetic:mandatory-user-regression',source_priority=1,families=['mandatory-user-regression:'+s['name'],'prefix:'+s['prefix'].lower(),'word:'+s['surface'][len(s['prefix']):],'reading:'+' '.join(r for raw,r in s['parts'])],prelude_events=[dict(type='key',key=c) for c in s['prelude_raw']],expected_prelude=s['prelude'],events=([dict(type='shift')] if s['shift'] else [])+[dict(type='key',key=c) for c in s['raw']]+[dict(type='enter')],expected_raw=s['raw'],gold=[dict(segments=segs,accepted_surfaces=[s['surface']])])
 VALIDATOR.validate(f);fixture_semantics(f);fixtures.append(f)
 packet=dict(id=f['id'],source_ref=f['source_ref'],prompt=s['prompt'],raw=s['raw'],gold=f['gold'],prelude_events=f['prelude_events'],expected_prelude=s['prelude'],events=f['events'])
 packets.append(packet);authors.append(dict(id=f['id'],annotator_id='/root/shift_return_experiment_runner_v2',accepted=True,reading_verified=True,labels_sha256=digest(dict(intent='compat',raw=s['raw'],gold=f['gold'])),claim='seen compatibility only; baseline original593 must be handled by actual original Session; no quality or replay performed'))
for filename,rows in [('mandatory-compat-fixtures.jsonl',fixtures),('batches/review-mandatory-compat.jsonl',packets),('mandatory-compat-first-annotations.jsonl',authors)]:
 with (OUT/filename).open('xb') as stream:
  for row in rows:stream.write(encoded(row)+b'\n')
seen=json.load(open(OUT/'seen-sources-pending.json'))
for k,values in [('seen_prefixes',['microsoft','microsft','wq','wd5']),('seen_contents',['窄裙','ㄓㄞˇ ㄑㄩㄣˊ','賺錢','ㄓㄨㄢˋ ㄑㄧㄢˊ','解','ㄐㄧㄝˇ']),('seen_raw',['microsoft593fmp6','WQ5j04fu06','593','ru,3'])]:seen[k]=sorted(set(seen[k]+values))
(OUT/'seen-sources-pending-with-mandatory.json').write_bytes(encoded(seen)+b'\n')
print('3 actual compatibility drafts; public reading verification passed; no execution/quality.')
