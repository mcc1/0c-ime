#!/usr/bin/env python3
"""Draft structural/label/closure inputs only; no strategy enumeration."""
from pathlib import Path
import sys,json,collections,copy
ROOT=Path('/workspace/0c-ime');OUT=Path(__file__).resolve().parent;sys.path.insert(0,str(ROOT/'internal/shiftreturn'))
from exchange import encoded,SCHEMA,digest
from reduce import fixture_semantics
import jsonschema
schema=copy.deepcopy(SCHEMA);schema['$defs']['bank_task']['properties']['annotations']['minItems']=1
validator=jsonschema.Draft202012Validator(schema)
tasks=[]
for p in sorted(OUT.glob('bank-pending-batch*.jsonl')):tasks.extend(json.loads(l) for l in p.read_text().splitlines())
fixtures=[]
for t in tasks:
 validator.validate(t);assert len(t['annotations'])==1 and t['annotations'][0]['annotator_id']=='/root/shift_return_experiment_runner_v2';assert t['annotations'][0]['labels_sha256']==digest({k:t[k] for k in ('intent','raw','gold')})
 assert len(t['raw'])<=512
 f={k:t[k] for k in ('version','demo','prototype_id','intent','category','stratum','context_class','source_ref','source_priority','families','prelude_events','expected_prelude','gold')};f.update(kind='fixture',id='task:'+t['id'],expected_raw=t['raw'],events=[{'type':'shift'}]+[{'type':'key','key':c} for c in t['raw']]+[{'type':'enter'}]);fixture_semantics(f);fixtures.append(f)
assert len({t['id'] for t in tasks})==len(tasks)
path=OUT/('fixtures-draft-through-batch'+str(len(list(OUT.glob('bank-pending-batch*.jsonl')))).zfill(2)+'.jsonl')
with path.open('xb') as stream:
 for f in fixtures:stream.write(encoded(f)+b'\n')
print(json.dumps({'tasks':len(tasks),'by_quota':dict(collections.Counter(t['intent']+':'+t['category']+':'+t['stratum'] for t in tasks)),'pending_second_annotation':len(tasks),'checks':'draft schema with one annotation; frozen fixture semantics and labels; not formal bank qualification','fixtures':str(path)}))
