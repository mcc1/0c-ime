P0 exchange contract complete; quality NOT run.

Source baseline: c512578157607615ed114feba20c8a443f260a19. All source files newly created and build-tagged shiftreturneval. No production/session/old evaluator source changed.

Implemented strict reviewed-schema decoding (unknown/missing/duplicate fields and malformed variants rejected); typed exchange values; raw/event/complete-span/SpellExact gold validation; family transitive closure plus prototype and observable-collision grouping; canonical component/hash splits; primary source-priority selection; whole-component seen exclusion; exact fixture-file hash verification; create-only CLI assign/validate and fail-closed future commands.

Layering adjudication from parent: Assign projects selected return primary.context_class==contrast into contrast_eligible as a declaration only. It is not qualification proof. Formal CLI validation must later join frozen bank/dictionary and independently verify the predicate before G0/counting/fit. Mixed-primary test ensures another contrast variant cannot contaminate the selected primary metadata.

Checks (all exit 0): scoped TestSchema/TestAssignment; all package/CLI tests; scoped vet; design check_examples.py; git diff --check. checks.log contains actual output. Source hashes captured separately. Tests cover schema examples including all generator diagnostics; malformed/missing keys; duplicate IDs/JSON fields; raw/reading mismatch and gaps; deterministic shuffled assignment; seen prefix/content/readings/raw propagation; priority/stratum metadata; canonical Python hashes; observable opposite-intent collision; CLI no-overwrite and no skeleton quality evidence.

An initial malformed-key rejection test used an ineffective textual replacement because Go struct field order differed; corrected the test mutation and re-ran all checks. No method/data change resulted.

Next: P1 candidate/features/render/state using fixed resource limits and tiny source parity. Formal quality remains blocked pending P0–P3 review, source/data freezes, actual data qualification and resource worksheet/preflight. No formal fixtures, annotations or model fit created.
