P1 checkpoint; no formal quality, fit, or data run.

New implementation candidate.go/features.go/render.go/state.go and candidate_test.go/state_test.go. P0 parent-review fixes: typed record-kind compatibility now checked before unmarshalling; JSON literal backslash-u2028/u2029 preserved while actual separators match Python canonical bytes. Parent independently verified both fixes.

P1 tests: exhaustive standard 1–3 body keys x five tones; tiny prefix-only/full exact source vectors; source log/missing flags; future-independent B snapshots; literal tie; first-tone space; custom-prefix protection; 63/64/65/129/511/512/513 bytes; pre-call lex budget guard; canonical 384 uncapped ->256 kept hypotheses at512bytes; revise recovery versus fixed pending-as-literal freeze; all eleven lifecycle close/restore cases with nonempty prelude; hard-gate zero query/score; manual literal/candidate locks; Enter no-query; overflow/backspace recovery. Scoped/full tagged tests and scoped vet exit0; actual output in checks.log.

Actual decoder experiment refined the suspected zero-probability edge: with exact 窄 and scorer0, Decoder.Best returns the exact path/text with -Inf score. Correct handling keeps x窄 and sets B/W missing flags. TestRenderZeroProbabilitySourceSemantics covers this; no fabricated surface and no unsupported designation for a real path. A genuinely empty decoded surface with k>0 still fails closed unsupported/raw retained under parent authorization.

An initial cap stress test expected exhaustion, but actual work finished below250000 evaluator lex calls with384 identities and256 kept. Corrected assertion to measured canonical cap result; no budget altered. A temporary compile failure while adding FrozenDisplay field was corrected before this checkpoint. All failures were transient implementation/test evidence, no formal result discarded.

Assignment contrast flag remains a declaration only; frozen bank/dictionary qualification is pending P3, before formal G0/counting/fit. Required unsupported rows must make G0 unavailable. P2 next adds true Session baselines/application ledger and disposable-store parity. Formal source/data freeze remains owned by parent.
