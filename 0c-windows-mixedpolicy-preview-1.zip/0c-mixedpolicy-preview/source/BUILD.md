# Source and rebuild instructions

Application source: https://github.com/mcc1/0c-ime/commit/cccc2d1397a574433d8faf90a1f6f6b7d1b12c3d
The source archive is a snapshot of that exact commit. The setup helper source and tests are included beside it.

Use Go 1.26.10. In the source root, copy preview-helper.go and preview-helper_test.go to build/windows-test-preview/main.go and main_test.go.

Build ./cmd/0c-server and ./cmd/0c-update with GOOS=windows GOARCH=amd64 CGO_ENABLED=0, -trimpath and -ldflags "-s -w -X main.buildVersion=0.2.7-preview.mixedpolicy.1". Output them as build/windows-test-preview/0c-server.exe and 0c-update.exe.

Verify both SHA-256 values against engineSHA/updaterSHA in the helper. Git metadata and toolchain differences can change rebuilt binary hashes; update those constants only for your own intentionally rebuilt payloads from trusted source, never to accept an unverified download. Run go test ./build/windows-test-preview for the preparation tests. Build ./build/windows-test-preview with GOOS=windows GOARCH=amd64 CGO_ENABLED=0, -trimpath -buildvcs=false and -ldflags "-s -w" to produce the setup executable.

The helper uses internal/update verification and the normal 0c-update installation/rollback operations. Original 0.2.6 components are copied and checked on the user's machine, not redistributed in this ZIP. No Rust or Windows SDK is needed for this preview. The existing settings UI renders the additional setting from the new updater's contract; this preview retains the installed UI executable.
