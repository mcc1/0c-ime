﻿靈犀注音 Windows x64 測試包：0.2.7-preview.mixedpolicy.1

mcc1 測試組裝，非上游官方發行版。測試安裝程式、新引擎與更新工具未做 Authenticode 簽章。
原始碼：https://github.com/mcc1/0c-ime/commit/cccc2d1397a574433d8faf90a1f6f6b7d1b12c3d

適用：同一個 Windows 帳號已安裝靈犀注音 0.2.6（x64，非 ARM64）。
這是供現有安裝使用的測試更新包，不能用於全新安裝。
它校驗並重用原安裝的 TSF 外殼、設定程式、字典與模型；內附新引擎和新 0c-update，
使用專案原有的安裝及回復流程。準備階段不修改原安裝或個人詞庫。

安裝：
1. 將 ZIP 全部解壓到同一個資料夾。
2. 完成目前組字、儲存工作。
3. 用原本安裝輸入法的同一個 Windows 帳號，右鍵 0c-mixed-policy-test-setup.exe → 以系統管理員身分執行。
4. 等待顯示 Installed；儲存工作後登出 Windows、重新登入，讓應用程式接上新引擎。

切換組字傾向：
- 預設「保守」：保留作者的帳號、型號、數字及罕用字判斷。
- 積極組字：雙擊 Aggressive.cmd。
- 保守組字：雙擊 Conservative.cmd。
切換不需要系統管理員權限；變更會儲存，沒有組字時由更新工具套用。
請先在原有設定中開啟「中英混打」；本包不會擅自將混打打開。
沿用 0.2.6 設定介面時，新項目「混打組字傾向」也會列在「選字」頁，選項為「保守／積極」。
積極模式可能把英數帳號或型號轉成中文字，要保留原文時請切到英文模式。
本版不包含鄰近按鍵容錯，不會猜測並替換誤按的鍵。

建議實測：
輸入                         保守                     積極
593                          窄                       窄
microsoft593fmp6              microsoft593＋中文候選   microsoft窄＋中文候選
microsoft5993fmp6su3cl3       保留誤按前段、恢復中文   保留誤按前段、恢復中文
kevin87 / lisa0304 / gpt4     保持原文                 可能轉成中文
請也在你的常用程式測試；同音字的首選由原有引擎及模型評分，不保證每個字都正確。

回復原版：
用同一個帳號，右鍵 Rollback.cmd → 以系統管理員身分執行；完成後登出再登入。
它使用原有 rollback，保留目前個人詞庫；不會要求還原個人詞庫。
若已另外更新到其他版本，這個回復入口會拒絕執行，避免回復錯誤的安裝。

檢查版本（PowerShell）：
& "$env:LOCALAPPDATA\Zuin\bin\0c-update.exe" status
安裝與重新登入後的執行版本應為 0.2.7-preview.mixedpolicy.1。

驗證範圍：
Go 全套測試、保守模式原有帳號案例、兩種模式的差異與敏感輸入學習／推論保護、
正式字典及神經模型、設定載入與 IPC 操作、測試包準備與損毀檔案拒絕測試、Windows x64 交叉編譯。
尚未在 Windows 實機執行安裝／回復、設定介面或原生 TSF 密碼欄位測試，這些需由本包實測確認。

0c-mixed-policy-test-setup.exe SHA-256：
c8b3a9aebea29fb6bc8148c6367502e653c21ed2bcc2e1c4b5072824ac1b14d8

source/ 內附修正原始碼及組裝工具；授權見 LICENSE、THIRD_PARTY_NOTICES.txt。
